function lmk = FindSmallest(H,num)
[~, originalIndices] = sort(H);

% Number of smallest elements you want to find
numSmallest = num;

% Get the indices of the first few smallest elements
lmk = originalIndices(1:numSmallest);
end