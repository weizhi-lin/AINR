function DevMat = ComputePatchDeviationVecR(MSeg_Design,BCshape)
% ndgrid(0:0.02:1); 51*51

Npatch = length(MSeg_Design);
DevMat={};

normalAverage = zeros(Npatch,3);
for i = 1:Npatch
    normalAverage(i,:) = mean(MSeg_Design{i}.normal,1);
end 

for lk = 1:Npatch
    % define variable for notation simplicity 

    Vd = MSeg_Design{lk}.V;
    Fd = MSeg_Design{lk}.F;
    Cd = MSeg_Design{lk}.Center;

    normLmk = mean(MSeg_Design{lk}.normal,1);
    TranZ= Align2Vector([0,0,1]',normLmk'/norm(normLmk)); 
    
    Vd_rt = Vd*TranZ; % rotated lmk 
    Vd_R = Vd_rt-Vd_rt(Cd,:);

    % find the corresponding points on the rotated patch (LCS)
    Vs_R = BCshape{lk}.tmap_surface;

    % figure()
    % options.face_vertex_color = [0,0,1];
    % plot_mesh(Vs_R,MSeg_Design{lk}.F,options);hold on
    % options.face_vertex_color = [0,1,1];
    % plot_mesh(Vd_R,MSeg_Design{lk}.F,options);

    deviationV = [Vs_R(:,1),Vs_R(:,2),Vs_R(:,3)] - [Vd_R(:,1),Vd_R(:,2),Vd_R(:,3)];
        
    % directional vector of deviation at landmark
    TdeviationV = deviationV;
    
    [azimuth,elevation,r] = cart2sph(TdeviationV(:,1),TdeviationV(:,2),TdeviationV(:,3));
    if azimuth<0
        azimuth = 2*pi + azimuth;
    end
    [gazimuth,gelevation,gr] = cart2sph(Vd(Cd,1),Vd(Cd,2),Vd(Cd,3));

    % the angle between the average landmark and the line connecting O and the lmk
    u = normLmk;
    v = Vd(Cd,:);
    CosTheta = max(min(dot(u,v)/(norm(u)*norm(v)),1),-1);
    ThetaInDegrees = real(acosd(CosTheta)); % the angle between the normal of lmk and the 

 
    % the angle between the average landmark and z axis
    v = [0,0,1];
    CosTheta2 = max(min(dot(u,v)/(norm(u)*norm(v)),1),-1);
    ThetaInDegrees2 = real(acosd(CosTheta2)); % the angle between the normal of lmk and the 


    %% encode to 1*1 square parameterization 

    disk = lineardiskmap(Vd,Fd); % Linear disk map (Choi, Lui, ACOM 2018)
    % Map it to square first
    rect = Polygon2Square(disk,Fd,BCshape{lk}.lmkb_Design);
    
    % figure()
    % options.face_vertex_color = r;
    % plot_mesh([rect zeros(length(Vd),1)],Fd,options);

    glb_ct = repmat([gazimuth,gelevation,gr],length(r),1);
    lab = repmat(lk,length(r),1);
    lmk_norm=repmat(normLmk,length(r),1);
    theta_nlk = repmat(ThetaInDegrees,length(r),1);
    theta_nlk2 = repmat(ThetaInDegrees2,length(r),1);

    DevMat.Azimuth{lk} = azimuth;
    DevMat.Elevation{lk} = elevation;
    DevMat.R{lk} = r;
    DevMat.RecDesign{lk} = BCshape{lk}.rect_Design;

    % DevMat.Tbl{lk} = [BCshape{lk}.rect_Design, azimuth,elevation,r,...
    %     MSeg_Design{lk}.Cgauss,MSeg_Design{lk}.Cmean,theta_nlk,theta_nlk2,glb_ct,lmk_norm,lab];

    DevMat.Tbl{lk} = [rect, azimuth,elevation,r,...
        MSeg_Design{lk}.Cgauss,MSeg_Design{lk}.Cmean,theta_nlk,theta_nlk2,glb_ct,lmk_norm,lab];

    DevMat.df{lk} = mat2dataset(DevMat.Tbl{lk},'VarNames', ...
        {'rectU','rectV','theta','phi','r','cgauss','cmean','ptheta','pntheta', ...
        'glbtheta','glbphi','glbr','lmknx','lmkny','lmknz','patch'});


%% Map the points to grids
    Fr = scatteredInterpolant(rect(:,1),rect(:,2),r);
    Ftheta = scatteredInterpolant(rect(:,1),rect(:,2),azimuth);
    Fphi = scatteredInterpolant(rect(:,1),rect(:,2),elevation);
    % Use a finer mesh to query the interpolant and improve the resolution.

    FCmean = scatteredInterpolant(rect(:,1),rect(:,2),MSeg_Design{lk}.Cmean);
    FCgauss = scatteredInterpolant(rect(:,1),rect(:,2),MSeg_Design{lk}.Cgauss);

    [xq,yq] = ndgrid(0:0.02:1);
    grdr = Fr(xq,yq); % surf(xq,yq,vq)
    grdtheta = Ftheta(xq,yq);
    grdphi= Fphi(xq,yq);
    grdCmean = FCmean(xq,yq);
    grdCgauss = FCgauss(xq,yq);

    rectgrd_u = reshape(xq,[],1);
    rectgrd_v = reshape(yq,[],1);

    vgrdr = reshape(grdr,[],1);
    vgrdtheta = reshape(grdtheta,[],1);
    vgrdphi = reshape(grdphi,[],1);
    vgrdCmean = reshape(grdCmean,[],1);
    vgrdCgauss = reshape(grdCgauss,[],1);

    % location of patch center in polar corrdinate system 
    glb_ct = repmat([gazimuth,gelevation,gr],length(vgrdr),1);
    % patch number 
    lab = repmat(lk,length(vgrdr),1); 
    % average normal direction 
    lmk_norm=repmat(normLmk,length(vgrdr),1);
    % angle between the average normal and the beam through center 
    theta_nlk = repmat(ThetaInDegrees,length(vgrdr),1);
    % angle between the avereage normal and the z direction 
    theta_nlk2 = repmat(ThetaInDegrees2,length(vgrdr),1);

    % figure()
    % options.face_vertex_color = MSeg_Design{lk}.Cmean;
    % plot_mesh([rect zeros(length(Vd),1)],Fd,options);
    % figure()
    % surf(xq,yq,grdCmean); colormap jet; colorbar

    % 
    % DevMat.Azimuth{lk} = vgrdtheta;
    % DevMat.Elevation{lk} = vgrdphi;
    % DevMat.R{lk} = vgrdr;
    % DevMat.RecDesign{lk} = [rectgrd_u rectgrd_v];

    % DevMat.Tbl{lk} = [BCshape{lk}.rect_Design, azimuth,elevation,r,...
    %     MSeg_Design{lk}.Cgauss,MSeg_Design{lk}.Cmean,theta_nlk,theta_nlk2,glb_ct,lmk_norm,lab];

    DevMat.TblonGrid{lk} = [rectgrd_u,rectgrd_v,vgrdtheta,vgrdphi,vgrdr,...
        vgrdCgauss,vgrdCmean,theta_nlk,theta_nlk2,glb_ct,lmk_norm,lab];

    DevMat.dfonGrid{lk} = mat2dataset(DevMat.Tbl{lk},'VarNames', ...
        {'rectU','rectV','theta','phi','r','cgauss','cmean','ptheta','pntheta', ...
        'glbtheta','glbphi','glbr','lmknx','lmkny','lmknz','patch'});

end


    % figure()
    % options.face_vertex_color = [1,0,1];
    % plot_mesh(MSeg_Scan{lk}.V,MSeg_Scan{lk}.F,options); hold on 
    % options.face_vertex_color = [0,0,1];
    % plot_mesh(Vd_R,MSeg_Design{lk}.F,options); hold on 
    % options.face_vertex_color = [0,1,0];
    % plot_mesh(BCshape{lk}.tmap_surface, MSeg_Design{lk}.F,options);
    % legend('Scan','Design','Registration');
    % axis tight
    % axis on
    % hAxis = gca;
    % hAxis.XRuler.FirstCrossoverValue  = 0; % X crossover with Y axis
    % hAxis.XRuler.SecondCrossoverValue  = 0; % X crossover with Z axis
    % hAxis.YRuler.FirstCrossoverValue  = 0; % Y crossover with X axis
    % hAxis.YRuler.SecondCrossoverValue  = 0; % Y crossover with Z axis
    % hAxis.ZRuler.FirstCrossoverValue  = 0; % Z crossover with X axis
    % hAxis.ZRuler.SecondCrossoverValue = 0; % Z crossover with Y axis

end 