function M = PatchFinalize(V_seg,F_seg,seg_ct,normOcenter)

% seg_ct: index of landmark on the segment
% normOcenter: normal of the landmark on the original shape 3 X 1
% Output: data structure for each segment

[normalPd,~] = meshVertexNormals(V_seg,F_seg);
% compute the inner product of the lmk's normals

sign = dot(normOcenter,normalPd(seg_ct,:));
if sign < 0
    [F_seg] = flip_faces_orientation(F_seg);
    [normalPd,~] = meshVertexNormals(V_seg,F_seg);
end

M.V = V_seg;
M.F = F_seg;
M.Center = seg_ct;
M.normalC = normalPd(seg_ct,:);
end