function [MDesign,N] = Lmk_Segment(MD,para)
    % n_eigenvalues = 300;
    tdStart = tic;
    
    % [vertex1,faces1] = MeshRead(Mesh_Design);
    % [vertex2,faces2] = MeshRead(Mesh_Scan);
    vertex1 = MD.vertex;
    faces1 = MD.faces;
    % Cgauss1 = MD.Cgauss;
    % Cmean1 = MD.Cmean;



    [~,~,Cmin,Cmax,~,~,~]= compute_curvature(vertex1,faces1);
    % [~,Cgauss1,Cmean1,~] = ComputeWeightFunction(vertex1,faces1);
    filter = abs(Cmin)+abs(Cmax); % absolute total curvature
    lenm = MaxLength(vertex1,faces1);
    BoundaryVer = compute_boundary(faces1);

    % [~,Cgauss2,Cmean2,~] = ComputeWeightFunction(vertex2,faces2);
    % lenm2 = MaxLength(vertex2,faces2);

    
    MD.V = vertex1;
    MD.F = faces1;
    Nvertex = size(vertex1,1);

    % figure()
    % plot_mesh(vertex1,faces1); hold on 
    % plot_mesh(vertex2,faces2);shading flat; colormap white
    
    remeshN = floor(Nvertex * 0.035); % 0.025; for other shapes
    % remeshN = min(remeshN,8000);

%% Step1: Feature sensitive remeshing

    tRemeshS = tic;
    [vertexV,facesV] = FeatureRemesh(vertex1,faces1,remeshN,filter,para.currentFolder);
    tRemesh = toc(tRemeshS);
    disp(['Time of remeshing is ',num2str(tRemesh/60),'min']) 
    
    [vertexV,facesV] = MeshEnsureManifold(vertexV,facesV);
    [vertexV,facesV]= MeshProcess(vertexV,facesV);
    
    MDRm.V = vertexV;
    MDRm.F = facesV;
    
    % figure()
    % plot_mesh(MDRm.V,MDRm.F);colormap jet(256); 
    % shading faceted


%% Step2: Geodesic distance computation
    tGeodesicS = tic;
    % DS = GeodesicDistance(vertexV,facesV);
    % change to make it able to computed in windows (July29)
    DS = GeodesicDistance_Diffusion(vertexV,facesV);
    tGeodesic = toc(tGeodesicS);
    
    disp(['Computation of Geodesic Distance is done, time:',num2str(tGeodesic)]);
    
    MDRm.GeoD = DS;

%% Step3: Clustering-based segmentation
    tFinddcS = tic;
    [rho,delta,dc,p] = FindBestDesicionValue(DS,0.01,0.02,100);
    tFinddc = toc(tFinddcS);

    [C_ind,N] = ClusterCenter(rho,delta);

    disp(['Number of segments is ',num2str(N)]);

    % assign vertex to each cluster 
    MDRm.Rho = rho;
    MDRm.Delta= delta;
    MDRm.Dc = dc;
    MDRm.P4dc = p; %best percentage

    % figure()
    % label = AssignCluster(C_ind, DS);
    % options.face_vertex_color = label;
    % plot_mesh(MDRm.V,MDRm.F,options); 
    % title('Segmentation on the Remeshed Mesh')
    % colormap turbo;


%% Step5: Segment projection and reconstruction 
    
    % position of cluster center on the original mesh
    vertexC = vertexV(C_ind,:);
    [~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);
    
    % % delete the centers too close to the boundary 
    % DistMatrix = GeodesicDistanceLmk(vertex1,faces1,[IC,BoundaryVer]);
    % DistIC = DistMatrix(1:N,1:N);
    % triDist = triu(DistIC, 1);
    % DistIC_array = triDist(triDist~=0);
    % 
    % cutdist = median([quantile(DistIC_array,0.05),min(DistIC_array),10]);
    % cutdist = min([cutdist,4]);
    % DistBD = DistMatrix(1:N,(N+1):end);
    % 
    % % Create a logical matrix where elements are true if they are smaller than d
    % thresholdMatrix = (DistBD < cutdist ) & (DistBD > 0);
    % % Find the rows that contain at least one value smaller than the threshold
    % rowsWithSmallerValues = any(thresholdMatrix, 2);
    % % Get the indices of these rows
    % rows = find(rowsWithSmallerValues);
    % IC(rows) = [];
    % disp(['After removing center too close to the boundaries, Number of segments is ',num2str(length(IC))]);
    % 
    % % in case too few segments
    % if length(IC)<3
    %     [~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);
    % end
    % 
    % % % 
    % % % delete the centers too close to each others
    % % N = length(IC);
    % % cutd_ct = 5;
    % % DistMatrix = GeodesicDistanceLmk(vertex1,faces1,IC);
    % % DistIC = DistMatrix(1:N,1:N);
    % % triDist = triu(DistIC, 1);
    % % % Create a logical matrix where elements are true if they are smaller than d
    % % thresholdMatrix = (triDist < cutd_ct) & (triDist > 0);
    % % % Find the rows that contain at least one value smaller than the threshold
    % % [row, col] = find(thresholdMatrix);
    % % % Get the indices of these rows
    % % IC(row) = [];
    % % disp(['After removing center too close to each others, Number of segments is ',num2str(length(IC))]);
    % % 
    % % % in case too few segments
    % % if length(IC)<3
    % %     [~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);
    % % end



%% project the clustering result to the orignal(designed) shape

    [label1,~] = GenerateVoronoiDiagram_Geo(vertex1,faces1,IC);
    N = length(IC);
    
    % correct the label order first 
    Label = zeros(length(vertex1),1);
    for ci = 1:N
        inx = label1(IC(ci));
        Label(label1 == inx) = ci;
    end
    
    % figure()
    % options.face_vertex_color = Label;
    % plot_mesh(vertex1,faces1,options); 
    % title('Segmentation on the Remeshed Mesh')
    % colormap turbo;shading flat;
    
    % Reconstruct the segment with boundary cleanned 
    [V_seg,F_seg] = SegReconstruction(Label,vertex1,N,'boundary',lenm);

    % modify the segment to have circular geodesic boundary 
    % V_seg = {};
    % F_seg = {};
    % area = [];
    % Label_seg = {};
    CindS = [];
    % Label_Overlap = zeros(length(vertex1),1);
    % d0_seg = [];

    for ic_circ = 1:N

        % % % on the original mesh 
        % options = [];
        % [D2,~,~] = perform_fast_marching_mesh(vertex1, faces1, IC(ic_circ));

        indpre = find(Label==ic_circ);
        % DistBdry = D2(indpre);

        % ensure the regions are fully covered 
        % d0 = 1.01 * max(DistBdry); 
        % Label0 = zeros(length(D2),1);
        % Label0(D2<d0)=1;

        % [V_seg{ic_circ},F_seg{ic_circ},area(ic_circ)] = SegReconstruction_sig(Label0,vertex1,'boundary',lenm);


        [~,Cseg]=ismember(vertex1(IC(ic_circ),:),V_seg{ic_circ},'rows');


        % Label_seg{ic_circ} = Label0;
        CindS(ic_circ) = Cseg;
        % d0_seg(ic_circ) = d0;

        % Label_Overlap = Label_Overlap + Label0; 

    end

    % figure()
    % options.face_vertex_color = Label_Overlap;
    % plot_mesh(vertex1,faces1,options); 
    % title(['The number of uncovered vertices:',num2str(length(find(Label_Overlap==0)))]);
    % colormap turbo;shading flat;
    % 
    MDSeg.V= V_seg;
    MDSeg.F= F_seg;
    % MDSeg.Label_Ori = Label_seg;


%% Step 6: Segment-wise landmarking
    tlmkS = tic;
    lmk = SegGPlmk_Reg(V_seg, F_seg);
    
    Ind = {};
    for j = 1:N
        [~,index]=ismember(V_seg{j}(lmk{j},:),vertex1,'rows');
        Ind{j} = index;
    end

    lmk_all = cell2mat(Ind'); % landmarks on the whole shape
    tlmk = toc(tlmkS);
    
    MDSeg.Lmk = lmk;
    MDRm.Ct = C_ind;
    MDSeg.Ct = CindS;
    MD.Time_Remesh = tRemesh;
    MD.Time_Geo = tGeodesic;
    MD.Time_Finddc = tFinddc;
    MD.Time_Lmk = tlmk;
    MD.Ct = IC;
    % MD.d0_seg = d0_seg;
    MD.Label = Label;
    MD.Lmk = lmk_all;
    MD.CtNumber = N;

    % MD.Label_seg = Label_seg;
    % MD.Label_Overlap = Label_Overlap;
    % 
    % figure()
    % options.face_vertex_color = MD.Label;
    % plot_mesh(MD.V,MD.F,options); hold on
    % plot3(MD.V(MD.Lmk,1),MD.V(MD.Lmk,2),MD.V(MD.Lmk,3),'.r','MarkerSize',35);
    % % title([filenames{td},' #segment:',num2str(length(MD.Ct)),' #lmk:',num2str(length(MD.Lmk))]);
    % colormap jet;shading flat;
    
    TimeSeg = toc(tdStart);
    
    MDesign.MD = MD;
    MDesign.MDSeg = MDSeg;
    MDesign.MDRm = MDRm;
    MDesign.Time = TimeSeg;



    
% save(fullfile(para.currentFolder,['Results/ICSeg_',filenames{td},'.mat']), ...
%     'MD','MDSeg','MDRm','-v7.3');
end
