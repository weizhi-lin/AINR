function BCresult = PairBCdiff_seg(vertex1,faces1,vertex2,faces2,Ind_design,Ind_scan,H1,H2,K1,K2)

% construct pair-wise parameterization 
% Input: design mesh, scan mesh, landmarks
% Output: parameterized design & scan;
%         boundary landmarks on design & scan;
%         GP landmarks on design & scan;
% 7/5/2022 Weizhi Lin
% modified 7/8/2024: deviation = scan-design

% comment out for compaticble size of vectors
% [vertex1,faces1] = removeInvalidBorderFaces(vertex1,faces1);
% [vertex1,faces1] = removeMeshEars(vertex1,faces1);

lmkb = findsquareapex(vertex1,faces1)'; % find apexes for the square
rect1 = rect_conformal_parameterization(vertex1,faces1,lmkb);

% mu = beltrami_coefficient(vertex1,faces1, rect1);
% z = linear_beltrami_solver(vertex1,faces1,mu,lmkb',lmkb');
% height = max(imag(z));
% N = 201;
% M = round(N*height);
% [r,uh,vh] = tri2surf(faces1,vertex1,z,M,N);
% [rz,rz2,normal,cf,h,mu] = surface_to_geometry(r,uh,vh);


% lmkb2 = findsquareapex(vertex2,faces2)'; 
% lmkb2 = BDLmkProject_icp(vertex1,faces1,lmkb, vertex2, faces2);

lmkb2 = BDLmkProject(vertex1,lmkb, vertex2, faces2);

% figure()
% plot_mesh(vertex2,faces2); hold on
% plot3(vertex2(lmkb2,1),vertex2(lmkb2,2),vertex2(lmkb2,3),'.r','MarkerSize',10);
% shading flat; colormap white

rect2 = rect_conformal_parameterization(vertex2,faces2,lmkb2);

BCresult.lmkb_Design = lmkb;
BCresult.lmkb_Scan = lmkb2;
BCresult.rect_Design = rect1;
BCresult.rect_Scan = rect2;
BCresult.lmk_Design = Ind_design;
BCresult.lmk_Scan = Ind_scan;

%% Registration
interior_landmark = Ind_design'; % indices of the interior landmarks
interior_landmark_target = rect2(Ind_scan,1:2); % target positions of the landmarks
height = max(rect2(:,2)); % target height of the rectangle

% Compute the Teichmuller map between the rectangles using QC Iteration
[tmap,tmap_bc] = rectangular_Teichmuller_map(rect1,faces1,...
    interior_landmark,interior_landmark_target,lmkb,height);

BCresult.tmap = tmap;
BCresult.tmap_bc = tmap_bc;

% Computing the Teichmuller distance
d = 1/2*log((1+mean(abs(tmap_bc)))/(1-mean(abs(tmap_bc)))); 
fprintf('Teichmuller distnace between the teeth = %f\n',d);
BCresult.Tdist = d;

% [~,K1,H1,~] = ComputeWeightFunction(vertex1,faces1);
% [~,K2,H2,~] = ComputeWeightFunction(vertex2,faces2);

H2_interp = scatteredInterpolant(vertex2(:,1),vertex2(:,2),vertex2(:,3),H2,'linear');
K2_interp = scatteredInterpolant(vertex2(:,1),vertex2(:,2),vertex2(:,3),K2,'linear');

% Construct the interpolants
% from parameterized target to 3D shape 
Fx = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,1),'linear');
Fy = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,2),'linear');
Fz = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,3),'linear');

% Find the surface T-map
tmap_surface = zeros(length(tmap),3);
tmap_surface(:,1) = Fx(tmap(:,1),tmap(:,2));
tmap_surface(:,2) = Fy(tmap(:,1),tmap(:,2));
tmap_surface(:,3) = Fz(tmap(:,1),tmap(:,2));

% % Design-scan 
% H_diff = H1 - H2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3));
% K_diff = K1 - K2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3));

% Scan-Design
H_diff = H2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3))-H1;
K_diff = K2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3))-K1;


BCresult.tmap_surface = tmap_surface;
BCresult.Hdiff = H_diff;
BCresult.Kdiff = K_diff;
BCresult.Htmap = H2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3));
BCresult.Ktmap = K2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3));

Hprodist = sqrt(meansqr(H_diff));
Kprodist = sqrt(meansqr(K_diff));
BCresult.Hprodist = Hprodist;
BCresult.Kprodist = Kprodist;

MeanBcV = [];
for j = 1:length(tmap)
    [row,~] = find(ismember(faces1,j));
    MeanBcV(j) = mean(tmap_bc(row));
end
BCv = MeanBcV;
BCresult.tmap_meanBC = BCv;
BCresult.DV = vertex1;
BCresult.DF = faces1;
BCresult.SV = vertex2;
BCresult.SF = faces2;

BCresult.H1 = H1;
BCresult.H2 = H2;
BCresult.K1 = K1;
BCresult.K2 = K2;

end