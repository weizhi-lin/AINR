function [vertex,faces] = MeshEnsureManifold(vertex,faces)
% input should be N*3
% fill the holes in the surface 

if size(vertex,2) > size(vertex,1)
    vertex = vertex';
end

if size(faces,2) > size(faces,1)
    faces = faces';
end

% remove nonmanifold vertices and fill in the holes 

[vertex,faces] = remove_isolated_triangles(vertex,faces,true); 
[faces] = remove_duplicated_triangles(faces);
[vertex,faces] = remove_duplicated_vertices(vertex,faces);
[vertex,faces] = remove_unreferenced_vertices(vertex,faces);
[faces] = remove_non_manifold_triangles(faces);
[vertex,faces] = remove_non_manifold_vertices(vertex,faces);

try
boundaries = detect_mesh_holes_and_boundary(faces);
faces = fill_mesh_holes(vertex,faces,boundaries,'opened',200);

catch
    warning('detact mesh holes and boundary failed')
end

[b,~] = ismesh2Dmanifold(vertex,faces);
while b == 0
    [faces] = remove_non_manifold_triangles(faces);
    [vertex,faces] = remove_non_manifold_vertices(vertex,faces);
    [faces] = remove_non_manifold_triangles(faces);
    [vertex,faces] = remove_non_manifold_vertices(vertex,faces);
    boundaries = detect_mesh_holes_and_boundary(faces);
    faces = fill_mesh_holes(vertex,faces,boundaries,'opened',200);
    [b,~] = ismesh2Dmanifold(vertex,faces);
end
% [vertex,faces] = remove_non_manifold_vertices(vertex,faces);
% faces = reorient_all_faces_coherently(vertex,faces);

[vertex,faces]= trimMesh(vertex,faces);
[vertex,faces] = removeInvalidBorderFaces(vertex,faces);
[vertex,faces]= removeMeshEars(vertex,faces);
% [~,~] = ismesh2Dmanifold(vertex,faces);

% faces = remove_self_intersecting_triangles(vertex,faces);

% VERY IMPORTANT!
faces =  reorient_all_faces_coherently(vertex,faces); 
end

% vertex = vertex2;
% faces = faces2;
% V = vertex;
% T = faces;
% [V,T] = remove_non_manifold_vertices(V,T);
% boundaries = select_holes_and_boundary(V,T);
% view(-180,-90);
% 
% max_perim_sz = 200;
% T = fill_mesh_holes(V,T,boundaries,'closed',max_perim_sz);
% plot_mesh(V,T);
% view(-180,-90);

% figure()
% plot_mesh(vertex,faces)
% [b, nmnfld_edg_idx] = ismesh2Dmanifold(vertex,faces);