function lmkTran = FindCorrespondingPtRigid(vertex1,vertex2,lmk)
% lmk are on vertex1
  
vertexFixed = pointCloud(vertex1);
vertexMoved = pointCloud(vertex2);

[~,movingReg,~] = pcregistericp(vertexMoved,vertexFixed); %,'MaxIterations',10);

% initial locations of the corresponding landmarks on the scan
[~,lmkTran] = pdist2(movingReg.Location,vertex1(lmk,:),'euclidean','Smallest',1);

% 
% 
% [~,idx_ct] = pdist2(vertex2,vertex1(lmk,:),'euclidean','Smallest',1);
% 
% % point descriptor of landmarks on design
% Descriptor = ComputeGeometricDescriptor(DV_seg{ci},DF_seg{ci},lmk_Design);
% 
% % find the landmark on the scan shape
% 
% 
%         [M,MAttr] = MeshPrepareSim(SV_seg{ci},SF_seg{ci},n_eigenvalues); %Cgauss,Cmean,
% 
%         a = 0.2;
%         b = 0.4;
%         c = 0.4;
% 
%         lmkTranNew = [];
%         for kk = 1:length(lmkTran)
%             lmk = lmkTran(kk);
%             [Label_0,Dist_0,~] = RegionGrowPatch(SV_seg{ci},SF_seg{ci},lmk, MAttr,para);
%             PointsPatch = find(Label_0);
%             Descriptor_Scan = ComputeGeometricDescriptor_Pt(SV_seg{ci},SF_seg{ci},MAttr,PointsPatch);
%             DiffDist = [];
%             for kki = 1:length(PointsPatch)
%                 DiffWKS = Descriptor{kk}.WKS - Descriptor_Scan{kki}.WKS;
%                 DiffMean = Descriptor{kk}.CurveMap.NorMaxMean - Descriptor_Scan{kki}.CurveMap.NorMaxMean;
%                 DiffGauss = Descriptor{kk}.CurveMap.NorMaxGauss - Descriptor_Scan{kki}.CurveMap.NorMaxGauss;
%                 dWKS = sqrt(mean(DiffWKS.^2));
%                 dAgM = sqrt(mean(DiffMean.^2));
%                 dAgG = sqrt(mean(DiffGauss.^2));
%                 DiffDist(kki) = a*dWKS+b*dAgM+c*dAgG;
%             end
%             lmkTranNew(kk) = PointsPatch(find(min(DiffDist)));
%         end