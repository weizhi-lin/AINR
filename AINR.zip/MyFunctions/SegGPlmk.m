function [lmk,lmkC] = SegGPlmk(V_seg, F_seg,center,Nlmk,Assign)

% assign landmarks number according to the 'Assign' feature

N = size(V_seg,2);
area = [];
D = {};
AGD = [];
for i = 1:N
%     [V_seg{i},F_seg{i}] = MeshEnsureManifold(V_seg{i}',F_seg{i}');
    M{i} = Mesh('VF',V_seg{i}',F_seg{i}');
    area(i) = meshSurfaceArea(M{i}.V',M{i}.F');
    M{i}.Normalize();
    [~,~,flip] = M{i}.ComputeNormal();
    if flip
        M{i}.F = M{i}.F([1 3 2],:);
    end
    M{i}.Aux.WKS = M{i}.ComputeWKS([]);
end  

switch(Assign)
    case 'AGD'
        [V_seg{i},F_seg{i}] = MeshEnsureManifold(V_seg{i}',F_seg{i}');
        for i = 1:N
                vertex = M{i}.V';
                faces = M{i}.F';
                D{i} = GeodesicDistanceOneSource(vertex,faces,center(i));
                AGD(i) = sum(D{i})/area(i);
        end
        Asum = sum(AGD); % total area of the mesh
        ratio = AGD./Asum;
    case 'Area'
        Asum = sum(area); % total area of the mesh
        ratio = area./Asum;
end
% 
% Asum = sum(AGD); % total area of the mesh
% ratio = AGD./Asum;

Ns = ceil(ratio.*Nlmk); % round up to integer

Ns(Ns<ceil(Nlmk/N))=ceil(Nlmk/N);

% determined by threshold from portion

for i = 1:N
    [GPLmkIdx,lmkcor] = GetGPLmk(M{i},Ns(i));
    lmk{i}= GPLmkIdx;
    lmkC{i} = lmkcor;
end

end