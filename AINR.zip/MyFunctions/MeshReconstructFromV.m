function [V_seg,F_seg] = MeshReconstructFromV(vertex,lenm)
options.method = 'slow';
options.verb = 0;
% the input should be N*3
if size(vertex,2) > size(vertex,1)
    vertex = vertex';
end

[F]=MyCrustOpen(vertex);
F = double(F);
V = vertex'; %3*N
F = F';
F = perform_faces_reorientation(V,F,options); %should be 3*N
%     [V,F]= MeshProcess(V,F);
    
if nargin == 2
    [V,F] = BoundaryProcess(V',F',lenm);
end

M = Mesh('VF',V',F');
[~,~,flip] = M.ComputeNormal();
if flip
    M.F = M.F([1 3 2],:);
end

V_seg = M.V';
F_seg = M.F';


end

% [SV,SF] = clean_mesh(V',F','MinDist',0,'MinArea',0,'MinAngle',0, ...
%      'SelfIntersections','remove','SmallTriangles','remove');
% figure()
% plot_mesh(SV,SF);