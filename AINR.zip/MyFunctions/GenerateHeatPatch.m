function [V_seg,F_seg] = GenerateHeatPatch(vertex,faces,index,timeStep,limitU,lenm)
options.method = 'slow';
options.verb = 0;
[Label,~] = HeatPatch(vertex,faces,index,timeStep,limitU);
I = find(Label==1); %find index in the original file
V = vertex(I,:);
[F]=MyCrustOpen(V);
F = double(F);
V = V'; %3*N
F = F';
F = perform_faces_reorientation(V,F,options); %should be 3*N

[V,F] = BoundaryProcess(V',F',lenm);

% IMPROTANT: avoid creases 
% F =  reorient_all_faces_coherently(V,F); 

V_seg = V;
F_seg = F;
end