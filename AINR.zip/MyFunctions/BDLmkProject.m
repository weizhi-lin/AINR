% project the 4 apexes 
function lmkb2 = BDLmkProject(vertex1,lmkb, vertex2, faces2)
 % updated on July25 2024 - find via ICP
 
% boundary = meshBoundaryVertexIndices(vertex2,faces2);
boundary = compute_boundary(faces2);
boundary_v = vertex2(boundary,:);
% 
% boundary0 = compute_boundary(faces1);
% boundary_v0 = vertex2(boundary0,:);

% 
Ind_vertex = vertex1(lmkb,:);
lmkb2 = [];
for i =1:4
    t = dsearchn(boundary_v,Ind_vertex(i,:));
    b = find(ismember(vertex2,boundary_v(t,:),'rows'));
    lmkb2 = [lmkb2;b];
end

% % % updated on July25 2024 - use ICP to find the corresponding boundary
% % points
% vertexFixed = pointCloud(boundary_v0);
% vertexMoved = pointCloud(boundary_v);
% 
% [~,movingReg,~] = pcregistericp(vertexMoved,vertexFixed); %,'MaxIterations',10);
% 
% % initial locations of the corresponding landmarks on the scan
% [~,lmkb2bd] = pdist2(movingReg.Location,vertex1(lmkb,:),'euclidean','Smallest',1);
% 
% lmkb2 = find(ismember(vertex2,boundary_v(lmkb2bd,:),'rows'));

% figure()
% subplot(1,2,1)
% plot_mesh(vertex1,faces1); hold on
% plot3(vertex1(lmkb,1),vertex1(lmkb,2),vertex1(lmkb,3),'.r','MarkerSize',10);
% shading flat; colormap white
% subplot(1,2,2)
% plot_mesh(vertex2,faces2); hold on
% plot3(vertex2(lmkb2,1),vertex2(lmkb2,2),vertex2(lmkb2,3),'.r','MarkerSize',10);
% shading flat; colormap white
end