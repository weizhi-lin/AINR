function PlotMeshWCenter(vertex,faces,label,C)

options.face_vertex_color = label;
plot_mesh(vertex,faces,options); hold on
plot3(vertex(C,1),vertex(C,2),vertex(C,3),'.r');
shading faceted;
colormap jet;
end