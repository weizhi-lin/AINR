function [Dmin,DminId] = FindClosestLmk(vertex1,faces1,lmk,GPLmkIdx)
% lmk is the newly selected landmark at current iteration
% GPLmkIdx is the list of landmarks selected previously. 

% W = rescale(-abs(K_gauss_indxkeep),0.01,1);%rescale(K_gauss(indxkeep));
% % W = rescale(min(K_gauss(indxkeep),0.1),0.01,1);
% options.W = W;
options = [];
options.nb_iter_max = Inf;


% frechet average 
[D,~,~] = perform_fast_marching_mesh(vertex1,faces1,lmk,options);
DistLmk = D(GPLmkIdx);
[Dmin,DminId] = min(DistLmk);
