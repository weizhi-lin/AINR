function smoothed_values = smooth_mesh_scalar_field(vertices, faces, values, n_iter, lambda)
    % vertices: Nx3
    % faces: Mx3
    % values: Nx1 (scalar field to smooth)
    % n_iter: number of smoothing iterations
    % lambda: smoothing parameter (0 < lambda < 1, e.g., 0.2)
    
    % Build adjacency matrix
    N = size(vertices,1);
    A = sparse(N,N);
    for i = 1:size(faces,1)
        for j = 1:3
            v1 = faces(i,j);
            v2 = faces(i,mod(j,3)+1);
            A(v1,v2) = 1;
            A(v2,v1) = 1;
        end
    end
    
    % Normalize adjacency
    D = spdiags(sum(A,2),0,N,N);
    L = D - A; % Laplacian matrix
    
    smoothed_values = values;
    for k = 1:n_iter
        smoothed_values = smoothed_values - lambda * (L * smoothed_values);
    end
end
