function [D,S,Q] = PerformFastMarching_mex(G, Indices,para)
path = para.currentFolder;
compile_mex

vertex=G.V;
faces=G.F;

[D,S,Q] = perform_fast_marching_mesh(vertex, faces, Indices);


if(~isdeployed)
  cd(path);
end
end