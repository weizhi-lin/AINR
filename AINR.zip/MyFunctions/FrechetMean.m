function [lmkpW,lmkp] = FrechetMean(V2,F2,K_gauss_indxkeep,vertex1)

W = rescale(-abs(K_gauss_indxkeep),0.01,1);%rescale(K_gauss(indxkeep));
% W = rescale(min(K_gauss(indxkeep),0.1),0.01,1);
options.W = W;
options.nb_iter_max = Inf;
% options = [];
Dist = zeros(length(V2),length(V2));

% frechet average 
parfor i = 1:length(V2)
    [D,~,~] = perform_fast_marching_mesh(V2,F2,i,options);
    Dist(:,i) = D;
end

Dist2= symmetrize_min(Dist);
rowSumFull = sum(Dist2, 2);
[~,lmkp] = min(rowSumFull);

lmkpW = find(ismember(vertex1,V2(lmkp,:),'rows'));