function [minValues, colIndices] = findRowMinima(matrix)
    % findRowMinima returns the minimum values and their column indices for each row of the matrix.
    
    % Calculate the minimum values and the column indices
    [minValues, colIndices] = min(matrix, [], 2);
end
