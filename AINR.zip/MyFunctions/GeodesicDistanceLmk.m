function D_sym = GeodesicDistanceLmk(vertex1,faces1,flat_lmk)
% input dimension should be N*3

% if size(vertices,2)>size(vertices,1)
%     vertices = vertices';
% end
options = [];
options.nb_iter_max = Inf;

N = length(flat_lmk);

DS = zeros(N,N);

parfor i = 1:N
    %create a single source at vertex #1
    vertex_id = flat_lmk(i);                            
    [D,~,~] = perform_fast_marching_mesh(vertex1,faces1,vertex_id ,options);
    DS(:,i)=D(flat_lmk);
end

D_sym = (DS + DS') / 2;

end