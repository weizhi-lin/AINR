function mat_out = ensure_NxP(mat_in)
% ensure_Nx3 - Ensures the input matrix is Nx3 (N points, 3 coordinates)
% Usage:
%   mat_out = ensure_Nx3(mat_in)
%
% If mat_in is 3xN, it will be transposed to Nx3.
% If mat_in is already Nx3, it is returned unchanged.
% If neither, an error is thrown.

    if size(mat_in,2) < size(mat_in,1) 
        mat_out = mat_in;
    elseif size(mat_in,2) > size(mat_in,1)
        mat_out = mat_in';
    else
        error('Input matrix must be NxP or PxN. N>P');
    end
end