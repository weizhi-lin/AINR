function vertex2Moved = ICPregVex(vertex1,vertex2)
% register 2 patches with ICP


vertexFixed = pointCloud(vertex1);
vertexMoved = pointCloud(vertex2);

[tform,~,~] = pcregistericp(vertexMoved,vertexFixed,'MaxIterations',10);
ptCloudOut = pctransform(vertexMoved,tform);
vertex2Moved= ptCloudOut.Location;

end

% 
% 
% figure()
% plot_mesh(vertex2m,faces2); hold on
% % plot_mesh(vertex2,faces2);
% plot_mesh(vertex1,faces1);

