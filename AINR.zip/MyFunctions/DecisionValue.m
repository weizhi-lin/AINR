function [rho,delta,dc]=DecisionValue(DS,percent)
m = size(DS,1);
Ds = DS;
Dsl = Ds(:);

s=m*(m-1)/2; %the total number of distances
Dss=sortrows (Dsl', 1 );

n_c=round(percent*s);
dc=Dss(1,n_c); %find d_c

%compute the density rho for every data point
rho=zeros (m,1) ;
for i =1:m
    for j =1:m
        if i~=j && Ds(i,j) < dc
            rho(i,1)=rho(i,1)+exp(-(Ds(i,j)/dc)^2); %Guass Kenel
        else
            rho(i,1)=rho(i,1);
        end
    end
end
%computer the cut-off distance for every data point
delta=zeros(m,1);
wait=zeros(m,m); %store the distance larger than the point
q=1;
for i =1:m
    for j =1:m
        if rho(i,1)<rho(j,1)
            wait(i,q)=Ds(i,j);
            q=q+1;
        end
    end
    q=1;
end

[sizew1,sizew2]= size(wait);

for i =1: sizew1
    for j =1: sizew2
        if wait (i ,j)==0
            wait (i,j)=inf;
        end
    end
end

for i =1:m
    delta(i,1)=min(wait(i,:));
end

for i =1:m
    if delta(i,1)==inf
        delta(i,1)=max(Ds(i,:));
    end
end

end