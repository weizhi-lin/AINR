function [Label,Dist,MeanStep] = RegionGrowPatchMerge(vertex1,faces1,lmk,MAttr,distP1,distP2)
% add a identification add the end to prevent the merged patch is too
% small. 

K_gauss = MAttr.K_gauss;
K_theta = MAttr.K_theta;
C_mean= MAttr.C_mean;

N=100; % expansion steps

% weight the difussion distance based on smoothness of gaussian curvature 
options = [];
% W = rescale(-abs(C_mean),0.01,1); %rescale(K_gauss(indxkeep));
% options.W = W;
options.nb_iter_max = Inf;

[D,~,~] = perform_fast_marching_mesh(vertex1,faces1,lmk,options);

SD = sort(D);
% dstep = quantile(diff(SD),[0.9],[1]);
dstep = max(diff(SD));
d0 = SD(2); % smallest distance from the center 

MeanStep = zeros(N,5);
% gradually expend the patch and exam the statistics of the added region 
for i = 1:N
    d_i0 = d0+(i-1)*dstep; % this is for parfor
    d_i = d0+i*dstep;

    indx = find(D<=d_i & D>d_i0); % indices of the added vertices
    % indx0 = find(D<=d_i0); %indices of the current patch

    if isempty(indx)
        break;
    end

    % X0 = [K_gauss(indx0),K_theta(indx0)];
    X = [K_gauss(indx),K_theta(indx)];

    % M0 = mean(X0);
    M = mean(X);

    MeanStep(i,2:3) = M;
    MeanStep(i,1) = d_i;
    MeanStep(i,4) = max(X(:,1));
    MeanStep(i,5) = median(C_mean(indx));
end 

% figure()
% findchangepts(MeanStep(:,2),MinDistance=10,Statistic="std",MinThreshold=5);
% figure()
% findchangepts(MeanStep(:,3),MinDistance=10,Statistic="std",MinThreshold=5)
% findchangepts(MeanStep(:,4),MinDistance=10,Statistic="std",MinThreshold=5)
% findchangepts(MeanStep(:,5),MinDistance=10,Statistic="std",MinThreshold=5)


[ipt1,~] = findchangepts(MeanStep(:,2),MinDistance=10,MinThreshold=5,Statistic="std");
[ipt2,~] = findchangepts(MeanStep(:,3),MinDistance=10,MinThreshold=5,Statistic="std");
[ipt3,~] = findchangepts(MeanStep(:,4),MinDistance=10,MinThreshold=5,Statistic="std");
[ipt4,~] = findchangepts(MeanStep(:,5),MinDistance=10,MinThreshold=5,Statistic="std");

% ipt3 = ipt3-2;
% ipt3 = find(MeanStep(:,4)>MeanStep(1,4));

% if ~isempty(ipt3)
%     ipt = floor(mean([ipt1(1),ipt2(1),ipt3(1)])); %
% else
%     ipt = floor(mean([ipt1(1),ipt2(1)]));
% end

if isempty(ipt1) || isempty(ipt2) || isempty(ipt3) || isempty(ipt4) 
    ipt = min([ipt1;ipt2;ipt3]);
    if isempty(ipt)
        disp('Fail to find the boundary');
        Label = [];
        Dist = [];
        
        return;
    else
        Dist = MeanStep(ipt,1);
        Label = zeros(length(D),1);
        Label(D<=Dist) = 1;
        disp('One of attribute has 0 change point.')
        return
    end
end

% 
% if abs(ipt1(1)-ipt2(1))<5 && min([ipt1(1),ipt2(1)])<10
%     ipt =mean([ipt1(1),ipt2(1)]);
% else
%     % if two changepoints are too far away from each other 
%     dif = abs(ipt1(1)-ipt2(1))/4;
%     ipt = floor(min([ipt1(1),ipt2(1)])+dif);
% end
% % ipt = floor(mean([ipt1(1),ipt2(1)]));
% % ipt =min([ipt1(1),ipt2(1)]);
IPT = [ipt1(1),ipt2(1),ipt3(1)];

if range(IPT)>10 && min(IPT)<15 % for cases the min is too small
    if range(IPT)>50
        % if two changepoints are too far away from each other 
        dif = range(IPT)/10;
        ipt = floor(min(IPT)+dif);
    else
        dif = range(IPT)/5;
        ipt = floor(min(IPT)+dif);
    end
else
     ipt =min(IPT);
end

% ipt = floor(mean([ipt1(1),ipt2(1)]));
%% only different part from the 'RegionGrowPatch.m
% compare the raidus with the before merge 
Dist = MeanStep(ipt,1);
Label = zeros(length(D),1);
distP = min(distP1,distP2);
if Dist>=distP
    Label(D<=Dist) = 1;
else
    Label(D<=distP ) = 1;
end


end 
