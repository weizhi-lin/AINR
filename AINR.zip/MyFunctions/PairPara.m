function [rect1,rect2,lmkb,lmkb2,Ind_design,Ind_scan] = PairPara(vertex1,faces1,vertex2,faces2,Lmk_D)

% construct pair-wise parameterization 
% Input: design mesh, scan mesh, landmarks
% Output: parameterized design & scan;
%         boundary landmarks on design & scan;
%         GP landmarks on design & scan;

[vertex1,faces1] = removeInvalidBorderFaces(vertex1,faces1);
[vertex1,faces1] = removeMeshEars(vertex1,faces1);

lmkb = findsquareapex(vertex1,faces1)'; % find apexes for the square
rect1 = rect_conformal_parameterization(vertex1,faces1,lmkb);


lmkb2 = BDLmkProject(vertex1,lmkb, vertex2, faces2);
rect2 = rect_conformal_parameterization(vertex2,faces2,lmkb2);

Ind_design = Lmk_D;
Ind_vertex = vertex1(Ind_design,:);
Ind_scan = dsearchn(vertex2,Ind_vertex);


% if F==1
%     figure()
%     subplot(2,2,1)
%     plot_mesh(vertex1,faces1);view([170 0]);hold on
%     plot3(vertex1(Ind_design,1),vertex1(Ind_design,2),vertex1(Ind_design,3),'ro','MarkerFaceColor','r');
%     hold on;
%     plot3(vertex1(lmkb,1),vertex1(lmkb,2),vertex1(lmkb,3),'bo','MarkerFaceColor','b');
%     title('Design');
%     
%     subplot(2,2,2)
%     plot_mesh(vertex2,faces2); view([170 0]);hold on
%     plot3(vertex2(Ind_scan,1),vertex2(Ind_scan,2),vertex2(Ind_scan,3),'ro','MarkerFaceColor','r');
%     hold on;
%     plot3(vertex2(lmkb2,1),vertex2(lmkb2,2),vertex2(lmkb2,3),'bo','MarkerFaceColor','b');
%     colormap([0.8 1 0.8]);
%     title('Scan');
%     
%     subplot(2,2,3)
%     show_mesh(rect1,faces1);hold on;%axis([0 0.4 0.2 0.6]);
%     plot(rect1(lmkb,1),rect1(lmkb,2),'bo','MarkerFaceColor','b'); hold on;
%     plot(rect1(Ind_design,1),rect1(Ind_design,2),'ro','MarkerFaceColor','r');
%     title('Rectangular conformal parameterization of design');
%     
%     subplot(2,2,4)
%     show_mesh(rect2,faces2);hold on; %axis([0 0.4 0.2 0.6]);
%     plot(rect2(lmkb2,1),rect2(lmkb2,2),'bo','MarkerFaceColor','b'); hold on;
%     plot(rect2(Ind_scan,1),rect2(Ind_scan,2),'ro','MarkerFaceColor','r');
%     title('Rectangular conformal parameterization of scan');
%     sgtitle([num2str(j),' th shape; ', num2str(k),'th segment']);
% end 
    

end