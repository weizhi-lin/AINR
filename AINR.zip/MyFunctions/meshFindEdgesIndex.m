function indxEdges = meshFindEdgesIndex(edges,verInd)

for j = 1:length(verInd)
    idx1 = find(edges(:,1) == verInd(j));
    idx2 = find(edges(:,2) == verInd(j));
    idx = [idx1;idx2];
    idxJ{j} = idx;
end
indxEdges = unique(cell2mat(idxJ'));