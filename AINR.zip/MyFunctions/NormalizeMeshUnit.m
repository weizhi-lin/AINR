function M = NormalizeMeshUnit(M)
M.Normalize();
[~,~,flip] = M.ComputeNormal();
if flip
    M.F = M.F([1 3 2],:);
end
M.Aux.WKS = M.ComputeWKS([]);
end