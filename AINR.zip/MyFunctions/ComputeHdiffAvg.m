function [Hdiff_avg, tmap_BCv_avg, Hscan_avg] = ComputeHdiffAvg(vertex1, BC_seg, type)
    N = length(BC_seg.DV);

    % Initialize matrices to store results
    Hdiff_lab = zeros(length(vertex1), N);
    tmap_BCv_lab = zeros(length(vertex1), N);
    Hscan_lab = zeros(length(vertex1), N);

    % Determine which BCresult to use based on the type
    switch type
        case 'Original'
            BCresult = BC_seg.BCresult;
        case 'Ft'
            BCresult = BC_seg.BCresult_Ft;
        case 'WtLmk'
            BCresult = BC_seg.BCresult_WtLmk;
        otherwise
            error('Invalid type specified. Choose ''Original'', ''Ft'', or ''WtLmk''.');
    end

    % Populate the matrices with appropriate values
    for ci = 1:N
        [~, idx_test] = pdist2(vertex1, BCresult{ci}.DV, 'euclidean', 'Smallest', 1);
        Hdiff_lab(idx_test, ci) = BCresult{ci}.Hdiff;
        tmap_BCv_lab(idx_test, ci) = BCresult{ci}.tmap_meanBC;
        Hscan_lab(idx_test, ci) = BCresult{ci}.Htmap;
    end

    % Initialize arrays to hold the average of non-zero elements for each row
    Hdiff_avg = zeros(size(Hdiff_lab, 1), 1);
    tmap_BCv_avg = zeros(size(tmap_BCv_lab, 1), 1);
    Hscan_avg = zeros(size(Hscan_lab, 1), 1);

    % Loop through each row to calculate the average of non-zero elements
    for row = 1:size(Hdiff_lab, 1)
        % Logical index of non-zero elements in each row
        non_zero_Hdiff = Hdiff_lab(row, :) ~= 0;
        non_zero_tmap_BCv = tmap_BCv_lab(row, :) ~= 0;
        non_zero_Hscan = Hscan_lab(row, :) ~= 0;
        
        % Calculate the average of non-zero elements
        Hdiff_avg(row) = mean(Hdiff_lab(row, non_zero_Hdiff));
        tmap_BCv_avg(row) = mean(tmap_BCv_lab(row, non_zero_tmap_BCv));
        Hscan_avg(row) = mean(Hscan_lab(row, non_zero_Hscan));
    end


    Hdiff_avg(isnan(Hdiff_avg)) = 0;
    tmap_BCv_avg(isnan(tmap_BCv_avg)) = 0;
    Hscan_avg(isnan(Hscan_avg)) = 0;
end