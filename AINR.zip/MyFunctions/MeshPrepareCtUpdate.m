function [M,fullMatProd] = MeshPrepareCtUpdate(vertex1,faces1,Kgauss_p,beta) %Cgauss,Cmean,

%% kernel weighted by Kgauss_p

% [~,Cgauss,Cmean,~] = ComputeWeightFunction(vertex1,faces1);
% % compute the point orientation 
% ThetaOri = ComputeOrientationTheta(vertex1,faces1);
% % Voronoi areas for vertices
% [A,~] = ComputeVoronoiAreasVertex(vertex1, faces1);
[vertex1,faces1] = MeshProcessBoundary(vertex1,faces1);

if nargin < 4
    % lambda = 0;
    beta = 1;
end

if size(vertex1,1)>3
    vertex1 = vertex1';
end
if size(faces1,1)>3
    faces1 = faces1';
end

M = Mesh('VF',vertex1, faces1);

M.Normalize();
[~,~,flip] = M.ComputeNormal();
if flip
    M.F = M.F([1 3 2],:);
end
% M.Aux.WKS = M.ComputeWKS([]);

M.Centralize('ScaleArea');
[~,TriArea] = M.ComputeSurfaceArea();
M.Aux.VertArea = M.F2V'*TriArea;

% [Cgauss,Cmean] = M.ComputeCurvature();
% Lambda = M.Aux.VertArea.*(lambda*abs(Cgauss).^beta/sum(abs(Cgauss))+(1-lambda)*abs(Cmean).^beta/sum(abs(Cmean)));
Lambda = M.Aux.VertArea.*(abs(Kgauss_p).^beta/sum(abs(Kgauss_p)));


if size(M.E,1) > 2
    [I,J] = find(tril(M.E));
    M.E = ([I,J])';
end
EdgeIdxI = M.E(1,:);
EdgeIdxJ = M.E(2,:);
% bandwidth = mean(sqrt(sum((G.V(:,EdgeIdxI)-G.V(:,EdgeIdxJ)).^2)))/5; % default in paper
bandwidth = mean(sqrt(sum((M.V(:,EdgeIdxI)-M.V(:,EdgeIdxJ)).^2)))*2.5;

BNN = min(1000,M.nV); % default 500
% atria = nn_prepare(G.V');
% [idx, dist] = nn_search(G.V',atria,(1:G.nV)',BNN+1,-1,0.0);
% fullPhi = sparse(repmat(1:G.nV,1,BNN+1),idx,exp(-dist.^2/bandwidth),G.nV,G.nV);
[idx, dist] = knnsearch(M.V',M.V','K',BNN+1);
fullPhi = sparse(repmat(1:M.nV,1,BNN+1),idx,exp(-dist.^2/bandwidth),M.nV,M.nV);
fullPhi = (fullPhi+fullPhi')/2;

% PDistMat = squareform(pdist(G.V'));
% fullPhi = exp(-PDistMat.^2/bandwidth);

disp('Constructing full kernel......');
tic;
fullMatProd = fullPhi * sparse(1:M.nV,1:M.nV,Lambda,M.nV,M.nV) * fullPhi;
disp(['full kernel constructed in ' num2str(toc) ' sec.']);

KernelTrace = diag(fullMatProd);

end