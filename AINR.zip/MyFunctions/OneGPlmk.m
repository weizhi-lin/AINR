function [lmk,lmkC] = OneGPlmk(vertex1, faces1, Nlmk)
if size(vertex1,1)>3
    vertex1 = vertex1';
end
if size(faces1,1)>3
    faces1 = faces1';
end

M = Mesh('VF',vertex1, faces1);

M.Normalize();
[~,~,flip] = M.ComputeNormal();
if flip
    M.F = M.F([1 3 2],:);
end
M.Aux.WKS = M.ComputeWKS([]);

[GPLmkIdx,lmkcor] = GetGPLmk(M,Nlmk);
lmk= GPLmkIdx;
lmkC = lmkcor;

% vertex1 = vertex1';
% faces1 = faces1';

% [label1,~] = GenerateVoronoiDiagram(vertex1,faces1,lmk,para.currentFolder); %Center
% 
% figure()
% options.face_vertex_color = label1;
% plot_mesh(vertex1,faces1,options);%shading faceted;
% hold on;
% h = plot3(vertex1(lmk,1), vertex1(lmk,2), vertex1(lmk,3), 'r.');
% set(h, 'MarkerSize', 25);colormap jet
% 
% % figure()
% % % options.face_vertex_color = L.label{i};
% % plot_mesh(L.V{i},L.F{i});%shading faceted;
% % hold on;
% % h = plot3(L.V{i}(L.lmk_all{i},1), L.V{i}(L.lmk_all{i},2), L.V{i}(L.lmk_all{i},3), 'r.');
% % set(h, 'MarkerSize', 25);

end