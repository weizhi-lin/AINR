function [PolDev,CarDevT,CarDev,TranZ] = LmkDeviationVec(Vd_lmk,Vs_lmk,normLmk)
% align the normal vector with the z axis 
% find the vector from the orginal lmk to the one on the print
% rotate the normal vector of the lmk to align with z direction
% rotate the deviation vector accordingly. 

N = length(Vd_lmk);

PolDev = zeros(N,3);
CarDev = zeros(N,3);
CarDevT = zeros(N,3);
TranZ = {};

for i = 1:length(Vd_lmk)
    U = Align2Vector([0,0,1]',normLmk(i,:)'); 
    % U = Align2Vector(normLmk(i,:)',[0,0,1]'); 
    % deviation vector of landmark
    deviationV = [Vs_lmk(i,1),Vs_lmk(i,2),Vs_lmk(i,3)] - [Vd_lmk(i,1),Vd_lmk(i,2),Vd_lmk(i,3)];
    
    % directional vector of deviation at landmark
    TdeviationV = deviationV*U;

    [azimuth,elevation,r] = cart2sph(TdeviationV(1),TdeviationV(2),TdeviationV(3));
    if azimuth<0
        azimuth = 2*pi + azimuth;
    end

    PolDev(i,:) = [azimuth,elevation,r];
    CarDevT(i,:) = TdeviationV;
    CarDev(i,:) = deviationV;
    TranZ{i} = U;

end

% % deviation vector of landmark
% deviationV = [Vs(Cs,1),Vs(Cs,2),Vs(Cs,3)] - [Vd(Cd,1),Vd(Cd,2),Vd(Cd,3)];
% 
% % directional vector of deviation at landmark
% TdeviationV = deviationV*U;
% 
% figure()
% plot3(Vd(Cd,1),Vd(Cd,2),Vd(Cd,3),'.r',MarkerSize=10); hold on
% plot3(Vs(Cs,1),Vs(Cs,2),Vs(Cs,3),'.r',MarkerSize=10); hold on
% % quiver3(Vd(Cd,1),Vd(Cd,2),Vd(Cd,3),Normal_u1(si),Normal_u2(si),Normal_u3(si),1,'filled',LineWidth=0.2,LineStyle='-.'); hold on
% quiver3(Vd(Cd,1),Vd(Cd,2),Vd(Cd,3),deviationV(1),deviationV(2),deviationV(3),1,'filled',LineWidth=0.2,LineStyle='--');
% axis equal
% 
% figure()
% % plot3(Vd(Cd,1),Vd(Cd,2),Vd(Cd,3),'.r',MarkerSize=10); hold on
% % plot3(Vs(Cs,1),Vs(Cs,2),Vs(Cs,3),'.r',MarkerSize=10); hold on
% plot3(0,0,0,'.r',MarkerSize=10); hold on
% quiver3(0,0,0,TdeviationV(1),TdeviationV(2),TdeviationV(3));
% axis equal
% 
% [azimuth,elevation,r] = cart2sph(TdeviationV(1),TdeviationV(2),TdeviationV(3));
% if azimuth<0
%     azimuth = 2*pi + azimuth;
% end

