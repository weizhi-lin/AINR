function [Label,Dist,MeanStep] = RegionGrowPatchFlat(vertex1,faces1,lmk,MAttr,Cindex,ctmax,para)
% Cindex = 1: use mean curvature for distance diffusion 
% Cindex = 2: use total curvature to determine the final landmark 
% Cindex = 3: use change of gaussian curvature to determine the final landmark 

if nargin < 7
    s = 0.3;
    md = 20;
else
    s = para.s;
    md = para.md;
end

K_gauss = MAttr.K_gauss;
K_theta = MAttr.K_theta;
K_phi = MAttr.K_phi;
K_mean = MAttr.K_mean;
Phi= MAttr.phi;
% 
C_mean= MAttr.C_mean;
C_gauss= MAttr.C_gauss;

ATTR = {abs(C_mean),MAttr.C_total,abs(K_gauss),abs(K_mean)};

if nargin<6
    C = ATTR{2};
    ctmax = quantile(C,0.1);
else
    C = ATTR{Cindex};
end




% [~,~,Cmin,Cmax,~,~,~] = compute_curvature(vertex1,faces1);
% C = abs(Cmin)+abs(Cmax);

W = rescale(min(C,ctmax), .001, 1);
% W = rescale(min(abs(C_mean),.02), .001, 1);
% W = rescale(min(abs(C_gauss)/sum(abs(C_gauss)),max(abs(C_gauss))/7), .001, 1);
options.constraint_map = [];
options.W = W;

% options = [];
% options.nb_iter_max = Inf;


% N=150; % expansion steps

[D,~,~] = perform_fast_marching_mesh(vertex1,faces1,lmk,options);
% % 
% figure()
% options.face_vertex_color = mod( 20*D/max(D),1 );
% plot_mesh(vertex1,faces1, options); hold on 
% colormap jet(256);
% plot3(vertex1(lmk,1),vertex1(lmk,2),vertex1(lmk,3),'.b','MarkerSize',10); shading flat
% 

SD = sort(D);
d0 = SD(2); % smallest distance from the center 

for ii = 1:5
% dstep = quantile(diff(SD),[0.9],[1]);
dstep = (s+0.05*ii)*max(diff(SD));
N = floor(max(D(:))/dstep);

MeanStep = zeros(N,7);
% gradually expend the patch and exam the statistics of the added region 
for i = 1:N
    d_i0 = d0+(i-1)*dstep; % this is for parfor
    d_i = d0+i*dstep;

    indx = find(D<=d_i & D>d_i0); % indices of the added vertices
    % indx0 = find(D<=d_i0); %indices of the current patch

    if isempty(indx)
        break;
    end

    % X0 = [K_gauss(indx0),K_theta(indx0)];
    X = [K_theta(indx),K_phi(indx)];

    % M0 = mean(X0);
    % M = mean(X);

    % MeanStep(i,2:3) = M;
    MeanStep(i,1) = d_i;
    MeanStep(i,6) = max(X(:,1));
    MeanStep(i,4) = max(X(:,2));
    MeanStep(i,7) = range(Phi(indx));

    MeanStep(i,2) = quantile(C_mean(indx),0.9)-quantile(C_mean(indx),0.1);%median(C_mean(indx));
    
    Cmean_add = C_mean(indx);
    [~,ind_6] = max(abs(Cmean_add));
    MeanStep(i,5) = Cmean_add(ind_6);% quantile(C_mean(indx),0.95);

    MeanStep(i,3) = quantile(C_gauss(indx),0.98);

end

if length(nonzeros(MeanStep))>0.9*length(MeanStep(:))
    break;
end

end
% 
% figure()
% findchangepts(MeanStep(:,2),MinDistance=md,Statistic="rms",MinThreshold=10);
% figure()
% findchangepts(MeanStep(:,7),MinDistance=md,Statistic="std",MinThreshold=90);
% figure()
% findchangepts(MeanStep(:,3),MinDistance=30,Statistic="rms",MinThreshold=1)
% figure()
% findchangepts(MeanStep(3:end,4),MinDistance=22,Statistic="rms",MinThreshold=25)
% findchangepts(MeanStep(:,5),MinDistance=10,Statistic="rms",MinThreshold=5)

% Minimum number of samples between changepoints
% minthreshold small: larger segment
% md = 25;
[ipt1,~] = findchangepts(MeanStep(:,2),MinDistance=md,MinThreshold=5,Statistic="rms");
[ipt5,~] = findchangepts(MeanStep(:,6),MinDistance=md,MinThreshold=5,Statistic="rms");
% IQR
[ipt2,~] = findchangepts(MeanStep(:,3),MinDistance=floor(md*0.9),MinThreshold=10,Statistic="rms");
[ipt3,~] = findchangepts(MeanStep(:,4),MinDistance=md,MinThreshold=10,Statistic="rms");
% max curvature 
[ipt4,~] = findchangepts(MeanStep(:,5),MinDistance=floor(md/3),MinThreshold=5,Statistic="rms");
%10
% [ipt6,~] = findchangepts(MeanStep(:,7),MinDistance=md,Statistic="mean",MinThreshold=5);

if ~isempty(ipt4)
    if range(MeanStep(1:ipt4(1),5)) < 0.01
        ipt4(1) = [];
    end
end


conF = [ isempty(ipt1), isempty(ipt2),isempty(ipt3), isempty(ipt4), isempty(ipt5)];%,isempty(ipt6)];
iptall = {ipt1',ipt2',ipt3',ipt4',ipt5'};

if any(conF)%isempty(ipt1) || isempty(ipt2) || isempty(ipt3) || isempty(ipt4) 
    
    ipt = min([ipt1;ipt2;ipt3;ipt4;ipt5]);
    if isempty(ipt)
        % disp('Fail to find the boundary');
        Label = [];
        Dist = [];
        return;
    else
        ind_nept = find(conF==0);
        iptall = iptall(ind_nept);
        ipt_all =[];
        for i = 1:length(ind_nept)
            ipt_all = [ipt_all;iptall{i}(1)];
        end
        ipt = floor(quantile(ipt_all,0.5));
        Dist = MeanStep(ipt,1);
        Label = zeros(length(D),1);
        Label(D<=Dist) = 1;
        disp('One of attribute has 0 change point.')

        return;
    end
end



IPT = [ipt1(1),ipt2(1),ipt3(1),ipt4(1),ipt5(1)]; %ipt3(1),

if range(IPT)>10 && min(IPT)<15 % for cases the min is too small
    if range(IPT)>20
        % if two changepoints are too far away from each other 
        dif = range(IPT)/4;
        ipt = floor(max(min(IPT),10)+dif);
    else
        dif = range(IPT)/6;
        ipt = floor(min(IPT)+dif);
    end
else
     ipt = ceil(mean(IPT));
end

if range(IPT)>80 || length(find(IPT>=50))>=2 
    if min(IPT)>15
        ipt = ceil(quantile(IPT,0.8));
    else
        ipt = ceil(median(IPT));
    end
end




Dist = MeanStep(ipt,1);

Label = zeros(length(D),1);
Label(D<=Dist) = 1;
% 
% % % % % % % % 
% figure()
% options.face_vertex_color = Label; %
% plot_mesh(vertex1,faces1,options); hold on
% plot3(vertex1(lmk,1),vertex1(lmk,2),vertex1(lmk,3),'.b','MarkerSize',10);
% % plot3(vertex1(lmk_update,1),vertex1(lmk_update,2),vertex1(lmk_update,3),'.b','MarkerSize',10);
% shading flat; colormap(mymap); 


end 
