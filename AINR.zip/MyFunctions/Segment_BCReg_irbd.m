function [AdaptPatch_Ori,BC_seg,MeshSeg] = Segment_BCReg_irbd(MDesign,MS,para)
% the corresponding patch on the scan surface is found by alignment

    n_eigenvalues = 300;

    MDSeg = MDesign.MDSeg;
    MD = MDesign.MD;

    vertex1 = MD.vertex;
    faces1 = MD.faces;
    Cgauss1 = MD.Cgauss;
    Cmean1 = MD.Cmean;

    vertex2 = MS.vertex;
    faces2 = MS.faces;
    Cgauss2 = MS.Cgauss;
    Cmean2 = MS.Cmean;


    % lenm = MaxLength(vertex1,faces1);
    % BoundaryVer = compute_boundary(faces1);
    lenm2 = MaxLength(vertex2,faces2);

%% Segment-wise registraction 
    idx_ctd = MD.Ct;
    DV_seg  = MDSeg.V;
    DF_seg  = MDSeg.F;

    %% find the corresponding segment centers
    % [~,idx_ct] = pdist2(vertex2,vertex1(MD.Ct,:),'euclidean','Smallest',1);
    idx_ct = FindCorrespondingPtRigid(vertex1,vertex2,idx_ctd);

    label1 = ProjectClustering(vertex1, vertex2, MD.Label);
    [SV_seg,SF_seg] = SegReconstruction(label1,vertex2,MD.CtNumber,'boundary',lenm2);

    % compute normal direction on the whole shape 
    % attention: need to use the mesh corresponding to the center!!
    [normalD, ~] = meshVertexNormals(vertex1,faces1); 
    [normalS, ~] = meshVertexNormals(vertex2,faces2);

%% Step 2: segment-wise registration 

    tsegRegs = tic;
    BCshape = {};
    BC_seg = {};
    MeshSeg = {};
    AdaptPatch_Ori = {};
    % Process scan shapes:
    for ci = 1:MD.CtNumber
        % ensure the orientation of segments are aligned with the whole shape
        normO_D = normalD(MD.Ct(ci),:);
        % find the center index in the segment shape on design
        [~,D_segct] = pdist2(DV_seg{ci},vertex1(idx_ctd(ci),:),'euclidean','Smallest',1);
        D_seg = PatchFinalize(DV_seg{ci},DF_seg{ci},D_segct,normO_D);
        [~,lmk_Design] = pdist2(DV_seg{ci},DV_seg{ci}(MDSeg.Lmk{ci},:),'euclidean','Smallest',1);


        normO_S = normalS(idx_ct(ci),:);
        % find the center index in the segment shape on scanned
        [~,S_segct] = pdist2(SV_seg{ci},vertex2(idx_ct(ci),:),'euclidean','Smallest',1);
        S_seg = PatchFinalize(SV_seg{ci},SF_seg{ci},S_segct,normO_S);

        % process mesh for registration 
        [BC_seg.DV{ci},BC_seg.DF{ci}] = MeshEnsureManifold(D_seg.V,D_seg.F);
        [BC_seg.SV{ci},BC_seg.SF{ci}] = MeshEnsureManifold(S_seg.V,S_seg.F);

        BC_seg.DCt{ci} = D_segct;
        BC_seg.SCt{ci} = S_segct;

        [~,idx_test] = pdist2(vertex1,BC_seg.DV{ci},'euclidean','Smallest',1);
        [~,idx_tests] = pdist2(vertex2,BC_seg.SV{ci},'euclidean','Smallest',1);

        H1 = Cmean1(idx_test);
        H2 = Cmean2(idx_tests);

        K1 = Cgauss1(idx_test);
        K2 = Cgauss2(idx_tests);

        %% with landmarks 
        % find corresponding landmarks
        vertexFixed = pointCloud(DV_seg{ci});
        vertexMoved = pointCloud(SV_seg{ci});

        % point descriptor of landmarks on design
        Descriptor = ComputeGeometricDescriptor(DV_seg{ci},DF_seg{ci},lmk_Design);

        % find the landmark on the scan shape
        [~,movingReg,~] = pcregistericp(vertexMoved,vertexFixed);%,'MaxIterations',10);
        % initial locations of the corresponding landmarks on the scan
        [~,lmkTran] = pdist2(movingReg.Location,DV_seg{ci}(lmk_Design,:),'euclidean','Smallest',1);

        try

        [M,MAttr] = MeshPrepareSim(SV_seg{ci},SF_seg{ci},n_eigenvalues); %Cgauss,Cmean,

        a = 0.2;
        b = 0.4;
        c = 0.4;

        lmkTranNew = [];
        for kk = 1:length(lmkTran)
            lmk = lmkTran(kk);
            [Label_0,~,~] = RegionGrowPatch(SV_seg{ci},SF_seg{ci},lmk, MAttr,para);
            PointsPatch = find(Label_0);
            Descriptor_Scan = ComputeGeometricDescriptor_Pt(SV_seg{ci},SF_seg{ci},MAttr,PointsPatch);
            DiffDist = [];
            for kki = 1:length(PointsPatch)
                DiffWKS = Descriptor{kk}.WKS - Descriptor_Scan{kki}.WKS;
                DiffMean = Descriptor{kk}.CurveMap.NorMaxMean - Descriptor_Scan{kki}.CurveMap.NorMaxMean;
                DiffGauss = Descriptor{kk}.CurveMap.NorMaxGauss - Descriptor_Scan{kki}.CurveMap.NorMaxGauss;
                dWKS = sqrt(mean(DiffWKS.^2));
                dAgM = sqrt(mean(DiffMean.^2));
                dAgG = sqrt(mean(DiffGauss.^2));
                DiffDist(kki) = a*dWKS+b*dAgM+c*dAgG;
            end
            lmkTranNew(kk) = PointsPatch(find(min(DiffDist)));
        end

        catch
            warning('Fail to compute landmarks with corresponding landmarks')
            lmkTranNew = lmkTran;
        end

        % figure()
        % subplot(1,3,1)
        % plot_mesh(DV_seg{ci},DF_seg{ci});hold on
        % plot3(DV_seg{ci}(lmk_Design,1),DV_seg{ci}(lmk_Design,2),DV_seg{ci}(lmk_Design,3),'.r','MarkerSize',35);
        % shading flat;colormap white
        % subplot(1,3,2)
        % plot_mesh(SV_seg{ci},SF_seg{ci});hold on
        % plot3(SV_seg{ci}(lmkTran,1),SV_seg{ci}(lmkTran,2),SV_seg{ci}(lmkTran,3),'.r','MarkerSize',35);
        % shading flat;colormap white
        % title('Rigid Correspondence');
        % subplot(1,3,3)
        % plot_mesh(SV_seg{ci},SF_seg{ci});hold on
        % plot3(SV_seg{ci}(lmkTranNew,1),SV_seg{ci}(lmkTranNew,2),SV_seg{ci}(lmkTranNew,3),'.r','MarkerSize',35);
        % shading flat;colormap white
        % title('Feature Correspondence');

        BC_seg.DLmk{ci} = lmk_Design;
        BC_seg.SLmk{ci} = lmkTranNew;
        BC_seg.SLmkEd{ci} = lmkTran;

        lmk = BC_seg.DLmk{ci};

        BCresult = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTran,H1,H2,K1,K2);
        BCresult_Ft = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTranNew,H1,H2,K1,K2);

        % without landmarks
        lmk = [];
        lmkTran = [];

        BCresult_WtLmk = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTran,H1,H2,K1,K2);

        %% save results 
        BC_seg.BCresult{ci} = BCresult;
        BC_seg.BCresult_Ft{ci} = BCresult_Ft;
        BC_seg.BCresult_WtLmk{ci} = BCresult_WtLmk;

        MeshSeg{ci}.DV = DV_seg{ci};
        MeshSeg{ci}.DF = DF_seg{ci};
        MeshSeg{ci}.SV = SV_seg{ci};
        MeshSeg{ci}.SF = SF_seg{ci};
        MeshSeg{ci}.DCt = D_segct;
        MeshSeg{ci}.SCt = S_segct;

    end 

    tsegReg = toc(tsegRegs);
    % figure()
    % % lmk1 = BC_seg.BCresult{ci}.lmk_Design;
    % V1 = BC_seg.BCresult{ci}.DV;
    % F1 = BC_seg.BCresult{ci}.DF;
    % options.face_vertex_color = BC_seg.BCresult{ci}.Hdiff;
    % plot_mesh(V1,F1,options); hold on
    % % plot3(V1(lmk1,1),V1(lmk1,2),V1(lmk1,3),'.r',MarkerSize=20);
    % colormap jet
    % shading flat
    % 
    % figure()
    % subplot(1,2,1)
    % plot_mesh(BC_seg.BCresult{ci}.rect_Design,BC_seg.DF{ci});
    % subplot(1,2,2)
    % plot_mesh(BC_seg.BCresult{ci}.rect_Scan,BC_seg.SF{ci});

    % figure()
    % subplot(1,2,1)
    % V1 = BC_seg.BCresult{ci}.DV;
    % F1 = BC_seg.BCresult{ci}.DF;
    % lmkb1 = BC_seg.BCresult{ci}.lmkb_Design;
    % lmkb2 = BC_seg.BCresult{ci}.lmkb_Scan;
    % plot_mesh(V1,F1);hold on
    % plot3(V1(lmkb1,1),V1(lmkb1,2),V1(lmkb1,3),'.r');
    % subplot(1,2,2)
    % plot_mesh(BC_seg.SV{ci},BC_seg.SF{ci}); hold on
    % plot3(BC_seg.SV{ci}(lmkb2,1),BC_seg.SV{ci}(lmkb2,2),BC_seg.SV{ci}(lmkb2,3),'.r');
    % colormap jet

    %% Average the calculated deviation values at the overlapped region 
    % for each point, found all the calculated deviation values at this
    % point 

    [Hdiff,tmap_BCv,Hscan] = ComputeHdiffAvg(vertex1, BC_seg,'Original');
    [Hdiff_Ft,tmap_BCv_Ft,Hscan_Ft] = ComputeHdiffAvg(vertex1, BC_seg,'Ft');
    [Hdiff_WtLmk,tmap_BCv_WtLmk,Hscan_WtLmk] = ComputeHdiffAvg(vertex1, BC_seg,'WtLmk');

    AdaptPatch_Ori.V = vertex1;
    AdaptPatch_Ori.F = faces1;
    AdaptPatch_Ori.Hdiff = Hdiff;
    AdaptPatch_Ori.tmapBCv = tmap_BCv;
    AdaptPatch_Ori.Hscan = Hscan;

    AdaptPatch_Ori.Hdiff_Ft = Hdiff_Ft;
    AdaptPatch_Ori.tmapBCv_Ft = tmap_BCv_Ft;
    AdaptPatch_Ori.Hscan_Ft = Hscan_Ft;

    AdaptPatch_Ori.Hdiff_WtLmk = Hdiff_WtLmk;
    AdaptPatch_Ori.tmapBCv_WtLmk = tmap_BCv_WtLmk;
    AdaptPatch_Ori.Hscan_WtLmk = Hscan_WtLmk;


    % figure()
    % subplot(1,3,1)
    % options.face_vertex_color = Hdiff;% perform_saturation(Hdiff,1.5);
    % plot_mesh(vertex1,faces1,options);
    % colormap(J)
    % shading flat
    % colorbar
    % clim([quantile(Hdiff,0.05),quantile(Hdiff,0.95)]);
    % title('Rigid Correspondence');
    % subplot(1,3,2)
    % options.face_vertex_color = Hdiff_Ft; %perform_saturation(Hdiff_Ft,1.5);
    % plot_mesh(vertex1,faces1,options);
    % colormap(J)
    % shading flat
    % colorbar
    % clim([quantile(Hdiff_Ft,0.05),quantile(Hdiff_Ft,0.95)]);
    % title('Feature Correspondence');
    % subplot(1,3,3)
    % options.face_vertex_color = Hdiff_WtLmk; %perform_saturation(Hdiff_WtLmk,1.5);
    % plot_mesh(vertex1,faces1,options);
    % colormap(J)
    % clim([quantile(Hdiff_WtLmk,0.05),quantile(Hdiff_WtLmk,0.95)]);
    % shading flat
    % colorbar

    % TimeAll = toc(tdStart);
    % AdaptPatch_Ori.Time = TimeAll;
    AdaptPatch_Ori.TimeReg = tsegReg;

end

    % save(fullfile(para.currentFolder,['Results/Registration_',filenames{td},'.mat']), ...
    %     'AdaptPatch_Ori','BC_seg','MeshSeg');
% function [AdaptPatch_Ori,BC_seg,MeshSeg] = Segment_BCReg_irbd(MDesign,MS,para)
% % the corresponding patch on the scan surface is found by alignment
% 
%     n_eigenvalues = 300;
% 
%     MDSeg = MDesign.MDSeg;
%     MD = MDesign.MD;
% 
%     vertex1 = MD.vertex;
%     faces1 = MD.faces;
%     Cgauss1 = MD.Cgauss;
%     Cmean1 = MD.Cmean;
% 
%     vertex2 = MS.vertex;
%     faces2 = MS.faces;
%     Cgauss2 = MS.Cgauss;
%     Cmean2 = MS.Cmean;
% 
% 
%     % lenm = MaxLength(vertex1,faces1);
%     % BoundaryVer = compute_boundary(faces1);
%     lenm2 = MaxLength(vertex2,faces2);
% 
% %% Segment-wise registraction 
%     idx_ctd = MD.Ct;
%     DV_seg  = MDSeg.V;
%     DF_seg  = MDSeg.F;
% 
%     %% find the corresponding segment centers
%     % [~,idx_ct] = pdist2(vertex2,vertex1(MD.Ct,:),'euclidean','Smallest',1);
%     idx_ct = FindCorrespondingPtRigid(vertex1,vertex2,idx_ctd);
% 
%     label1 = ProjectClustering(vertex1, vertex2, MD.Label);
%     [SV_seg,SF_seg] = SegReconstruction(label1,vertex2,MD.CtNumber,'boundary',lenm2);
% 
%     % compute normal direction on the whole shape 
%     % attention: need to use the mesh corresponding to the center!!
%     [normalD, ~] = meshVertexNormals(vertex1,faces1); 
%     [normalS, ~] = meshVertexNormals(vertex2,faces2);
% 
% %% Step 2: segment-wise registration 
% 
%     tsegRegs = tic;
%     BCshape = {};
%     BC_seg = {};
%     MeshSeg = {};
%     AdaptPatch_Ori = {};
%     % Process scan shapes:
% 
%     for ci = 1:MD.CtNumber
% 
%         % ensure the orientation of segments are aligned with the whole shape
%         normO_D = normalD(MD.Ct(ci),:);
%         % find the center index in the segment shape on design
%         [~,D_segct] = pdist2(DV_seg{ci},vertex1(idx_ctd(ci),:),'euclidean','Smallest',1);
%         D_seg = PatchFinalize(DV_seg{ci},DF_seg{ci},D_segct,normO_D);
%         [~,lmk_Design] = pdist2(DV_seg{ci},DV_seg{ci}(MDSeg.Lmk{ci},:),'euclidean','Smallest',1);
% 
% 
%         normO_S = normalS(idx_ct(ci),:);
%         % find the center index in the segment shape on scanned
%         [~,S_segct] = pdist2(SV_seg{ci},vertex2(idx_ct(ci),:),'euclidean','Smallest',1);
%         S_seg = PatchFinalize(SV_seg{ci},SF_seg{ci},S_segct,normO_S);
% 
% 
%         % process mesh for registration 
%         [BC_seg.DV{ci},BC_seg.DF{ci}] = MeshEnsureManifold(D_seg.V,D_seg.F);
%         [BC_seg.SV{ci},BC_seg.SF{ci}] = MeshEnsureManifold(S_seg.V,S_seg.F);
% 
%         BC_seg.DCt{ci} = D_segct;
%         BC_seg.SCt{ci} = S_segct;
% 
%         [~,idx_test] = pdist2(vertex1,BC_seg.DV{ci},'euclidean','Smallest',1);
%         [~,idx_tests] = pdist2(vertex2,BC_seg.SV{ci},'euclidean','Smallest',1);
% 
%         H1 = Cmean1(idx_test);
%         H2 = Cmean2(idx_tests);
% 
%         K1 = Cgauss1(idx_test);
%         K2 = Cgauss2(idx_tests);
% 
%         %% with landmarks 
%         % find corresponding landmarks
%         vertexFixed = pointCloud(DV_seg{ci});
%         vertexMoved = pointCloud(SV_seg{ci});
% 
%         % point descriptor of landmarks on design
%         Descriptor = ComputeGeometricDescriptor(DV_seg{ci},DF_seg{ci},lmk_Design);
% 
%         % find the landmark on the scan shape
%         [~,movingReg,~] = pcregistericp(vertexMoved,vertexFixed);%,'MaxIterations',10);
%         % initial locations of the corresponding landmarks on the scan
%         [~,lmkTran] = pdist2(movingReg.Location,DV_seg{ci}(lmk_Design,:),'euclidean','Smallest',1);
%         % 
%         % try
%         % 
%         % [M,MAttr] = MeshPrepareSim(SV_seg{ci},SF_seg{ci},n_eigenvalues); %Cgauss,Cmean,
%         % 
%         % a = 0.2;
%         % b = 0.4;
%         % c = 0.4;
%         % 
%         % lmkTranNew = [];
%         % for kk = 1:length(lmkTran)
%         %     lmk = lmkTran(kk);
%         %     [Label_0,~,~] = RegionGrowPatch(SV_seg{ci},SF_seg{ci},lmk, MAttr,para);
%         %     PointsPatch = find(Label_0);
%         %     Descriptor_Scan = ComputeGeometricDescriptor_Pt(SV_seg{ci},SF_seg{ci},MAttr,PointsPatch);
%         %     DiffDist = [];
%         %     for kki = 1:length(PointsPatch)
%         %         DiffWKS = Descriptor{kk}.WKS - Descriptor_Scan{kki}.WKS;
%         %         DiffMean = Descriptor{kk}.CurveMap.NorMaxMean - Descriptor_Scan{kki}.CurveMap.NorMaxMean;
%         %         DiffGauss = Descriptor{kk}.CurveMap.NorMaxGauss - Descriptor_Scan{kki}.CurveMap.NorMaxGauss;
%         %         dWKS = sqrt(mean(DiffWKS.^2));
%         %         dAgM = sqrt(mean(DiffMean.^2));
%         %         dAgG = sqrt(mean(DiffGauss.^2));
%         %         DiffDist(kki) = a*dWKS+b*dAgM+c*dAgG;
%         %     end
%         %     lmkTranNew(kk) = PointsPatch(find(min(DiffDist)));
%         % end
%         % 
%         % catch
%         %     warning('Fail to compute landmarks with corresponding landmarks')
%         %     lmkTranNew = lmkTran;
%         % end
% 
%         % figure()
%         % subplot(1,3,1)
%         % plot_mesh(DV_seg{ci},DF_seg{ci});hold on
%         % plot3(DV_seg{ci}(lmk_Design,1),DV_seg{ci}(lmk_Design,2),DV_seg{ci}(lmk_Design,3),'.r','MarkerSize',35);
%         % shading flat;colormap white
%         % subplot(1,3,2)
%         % plot_mesh(SV_seg{ci},SF_seg{ci});hold on
%         % plot3(SV_seg{ci}(lmkTran,1),SV_seg{ci}(lmkTran,2),SV_seg{ci}(lmkTran,3),'.r','MarkerSize',35);
%         % shading flat;colormap white
%         % title('Rigid Correspondence');
%         % subplot(1,3,3)
%         % plot_mesh(SV_seg{ci},SF_seg{ci});hold on
%         % plot3(SV_seg{ci}(lmkTranNew,1),SV_seg{ci}(lmkTranNew,2),SV_seg{ci}(lmkTranNew,3),'.r','MarkerSize',35);
%         % shading flat;colormap white
%         % title('Feature Correspondence');
% 
%         BC_seg.DLmk{ci} = lmk_Design;
%         % BC_seg.SLmk{ci} = lmkTranNew;
%         BC_seg.SLmkEd{ci} = lmkTran;
% 
%         lmk = BC_seg.DLmk{ci};
% 
%         BCresult = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTran,H1,H2,K1,K2);
%         % BCresult_Ft = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTranNew,H1,H2,K1,K2);
% 
%         % without landmarks
%         lmk = [];
%         lmkTran = [];
% 
%         BCresult_WtLmk = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTran,H1,H2,K1,K2);
% 
%         %% save results 
%         BC_seg.BCresult{ci} = BCresult;
%         % BC_seg.BCresult_Ft{ci} = BCresult_Ft;
%         BC_seg.BCresult_WtLmk{ci} = BCresult_WtLmk;
% 
% 
%         MeshSeg{ci}.DV = DV_seg{ci};
%         MeshSeg{ci}.DF = DF_seg{ci};
%         MeshSeg{ci}.SV = SV_seg{ci};
%         MeshSeg{ci}.SF = SF_seg{ci};
%         MeshSeg{ci}.DCt = D_segct;
%         MeshSeg{ci}.SCt = S_segct;
% 
%     end 
% 
%     tsegReg = toc(tsegRegs);
%     % figure()
%     % % lmk1 = BC_seg.BCresult{ci}.lmk_Design;
%     % V1 = BC_seg.BCresult{ci}.DV;
%     % F1 = BC_seg.BCresult{ci}.DF;
%     % options.face_vertex_color = BC_seg.BCresult{ci}.Hdiff;
%     % plot_mesh(V1,F1,options); hold on
%     % % plot3(V1(lmk1,1),V1(lmk1,2),V1(lmk1,3),'.r',MarkerSize=20);
%     % colormap jet
%     % shading flat
%     % 
%     % figure()
%     % subplot(1,2,1)
%     % plot_mesh(BC_seg.BCresult{ci}.rect_Design,BC_seg.DF{ci});
%     % subplot(1,2,2)
%     % plot_mesh(BC_seg.BCresult{ci}.rect_Scan,BC_seg.SF{ci});
% 
%     % figure()
%     % subplot(1,2,1)
%     % V1 = BC_seg.BCresult{ci}.DV;
%     % F1 = BC_seg.BCresult{ci}.DF;
%     % lmkb1 = BC_seg.BCresult{ci}.lmkb_Design;
%     % lmkb2 = BC_seg.BCresult{ci}.lmkb_Scan;
%     % plot_mesh(V1,F1);hold on
%     % plot3(V1(lmkb1,1),V1(lmkb1,2),V1(lmkb1,3),'.r');
%     % subplot(1,2,2)
%     % plot_mesh(BC_seg.SV{ci},BC_seg.SF{ci}); hold on
%     % plot3(BC_seg.SV{ci}(lmkb2,1),BC_seg.SV{ci}(lmkb2,2),BC_seg.SV{ci}(lmkb2,3),'.r');
%     % colormap jet
% 
%     %% Average the calculated deviation values at the overlapped region 
%     % for each point, found all the calculated deviation values at this
%     % point 
% 
%     [Hdiff,tmap_BCv,Hscan] = ComputeHdiffAvg(vertex1, BC_seg,'Original');
%     % [Hdiff_Ft,tmap_BCv_Ft,Hscan_Ft] = ComputeHdiffAvg(vertex1, BC_seg,'Ft');
%     [Hdiff_WtLmk,tmap_BCv_WtLmk,Hscan_WtLmk] = ComputeHdiffAvg(vertex1, BC_seg,'WtLmk');
% 
%     AdaptPatch_Ori.V = vertex1;
%     AdaptPatch_Ori.F = faces1;
%     AdaptPatch_Ori.Hdiff = Hdiff;
%     AdaptPatch_Ori.tmapBCv = tmap_BCv;
%     AdaptPatch_Ori.Hscan = Hscan;
% 
%     % AdaptPatch_Ori.Hdiff_Ft = Hdiff_Ft;
%     % AdaptPatch_Ori.tmapBCv_Ft = tmap_BCv_Ft;
%     % AdaptPatch_Ori.Hscan_Ft = Hscan_Ft;
% 
%     AdaptPatch_Ori.Hdiff_WtLmk = Hdiff_WtLmk;
%     AdaptPatch_Ori.tmapBCv_WtLmk = tmap_BCv_WtLmk;
%     AdaptPatch_Ori.Hscan_WtLmk = Hscan_WtLmk;
% 
% 
%     % figure()
%     % subplot(1,3,1)
%     % options.face_vertex_color = Hdiff;% perform_saturation(Hdiff,1.5);
%     % plot_mesh(vertex1,faces1,options);
%     % colormap(J)
%     % shading flat
%     % colorbar
%     % clim([quantile(Hdiff,0.05),quantile(Hdiff,0.95)]);
%     % title('Rigid Correspondence');
%     % subplot(1,3,2)
%     % options.face_vertex_color = Hdiff_Ft; %perform_saturation(Hdiff_Ft,1.5);
%     % plot_mesh(vertex1,faces1,options);
%     % colormap(J)
%     % shading flat
%     % colorbar
%     % clim([quantile(Hdiff_Ft,0.05),quantile(Hdiff_Ft,0.95)]);
%     % title('Feature Correspondence');
%     % subplot(1,3,3)
%     % options.face_vertex_color = Hdiff_WtLmk; %perform_saturation(Hdiff_WtLmk,1.5);
%     % plot_mesh(vertex1,faces1,options);
%     % colormap(J)
%     % clim([quantile(Hdiff_WtLmk,0.05),quantile(Hdiff_WtLmk,0.95)]);
%     % shading flat
%     % colorbar
% 
%     % TimeAll = toc(tdStart);
%     % AdaptPatch_Ori.Time = TimeAll;
%     AdaptPatch_Ori.TimeReg = tsegReg;
% 
% end
% 
%     % save(fullfile(para.currentFolder,['Results/Registration_',filenames{td},'.mat']), ...
%     %     'AdaptPatch_Ori','BC_seg','MeshSeg');
% 
