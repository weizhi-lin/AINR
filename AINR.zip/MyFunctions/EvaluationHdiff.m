function Metric = EvaluationHdiff(Hdiff_test, Hdiff0)

% Mean Absolute Error (MAE)
MAE = mean(abs(Hdiff_test - Hdiff0));

% Mean Squared Error (MSE)
MSE = mean((Hdiff_test - Hdiff0).^2);

% Root Mean Squared Error (RMSE)
RMSE = sqrt(MSE);

%% compute accuracy based on deviations 
tol = 1e-3;

% Calculate the absolute difference
abs_diff = abs(Hdiff_test - Hdiff0);

% Identify false positives (differences greater than tolerance)
false_positives = abs_diff > tol;

% Identify true positives (differences less than or equal to tolerance)
true_positives = abs_diff <= tol;

% Count the number of false positives
num_false_positives = sum(false_positives);

% Count the number of true positives
num_true_positives = sum(true_positives);

% Total number of elements
num_elements = length(Hdiff_test);

% Calculate the false positive rate
false_positive_rate = num_false_positives / num_elements;

% Calculate the accuracy
accuracy = num_true_positives / num_elements;

% Identify false negatives (true deviations are non-zero but estimated deviations are within tolerance)
false_negatives = (Hdiff0 > tol) & (abs_diff <= tol);

% Count the number of false negatives
num_false_negatives = sum(false_negatives);

% Calculate the false negative rate
false_negative_rate = num_false_negatives / num_elements;

%% element-based computation 

% Tolerance value
tol = quantile(Hdiff0, 0.8);

% Identify elements in Hdiff0 that are larger than the tolerance
elements_above_tol = Hdiff0 > tol;

% Identify elements in Hdiff_test that are larger than the tolerance
captured_elements = Hdiff_test > tol;

% Find the intersection of these two sets with the same index
true_positives_ele = elements_above_tol & captured_elements;

% Calculate the number of elements above the tolerance in Hdiff0
num_elements_above_tol_ele = sum(elements_above_tol);

% Calculate the number of captured elements
num_true_positives_ele = sum(true_positives_ele);

% Calculate the number of false positives (estimated larger than tol, but true not)
false_positives_ele = captured_elements & ~elements_above_tol;
num_false_positives_ele = sum(false_positives_ele);

% Calculate the number of false negatives (true larger than tol, but estimated not)
false_negatives_ele = elements_above_tol & ~captured_elements;
num_false_negatives_ele = sum(false_negatives_ele);

% Calculate the False Positive Rate (FPR)
if num_elements_above_tol_ele == 0
    false_positive_rate_ele = NaN; % Avoid division by zero if no elements are above tolerance
else
    false_positive_rate_ele = num_false_positives_ele / num_elements_above_tol_ele;
end

% Calculate the False Negative Rate (FNR)
if num_elements_above_tol_ele == 0
    false_negative_rate_ele = NaN; % Avoid division by zero if no elements are above tolerance
else
    false_negative_rate_ele = num_false_negatives_ele / num_elements_above_tol_ele;
end

% Calculate the accuracy
accuracy_ele = (num_true_positives_ele + (sum(~elements_above_tol & ~captured_elements))) / length(Hdiff0);

%%
% Calculate Mean Absolute Relative Error
epsilon = 1e-15;
relative_errors = abs(Hdiff_test - Hdiff0) ./ (abs(Hdiff0) + epsilon);
mean_absolute_relative_error2 = mean(relative_errors);

numerator = sum(abs(Hdiff_test - Hdiff0));
denominator = sum(abs(Hdiff0));
mean_absolute_relative_error = numerator / denominator;

%% Store all metrics in the Metric structure
% Basic Error Metrics
Metric.MAE = MAE;
Metric.MSE = MSE;
Metric.RMSE = RMSE;
Metric.MARE = mean_absolute_relative_error;
Metric.MARE2 = mean_absolute_relative_error2;

% Deviation-based Metrics
Metric.FPR = false_positive_rate;
Metric.FNR = false_negative_rate;
Metric.Accuracy = accuracy;

% Element-based Metrics
Metric.FPR_ele = false_positive_rate_ele;
Metric.FNR_ele = false_negative_rate_ele;
Metric.Accuracy_ele = accuracy_ele;

%% Additional metrics (matching the ones at the end of the original code)
% These are added to ensure all metrics from the original code are included

% R-squared (Coefficient of Determination)
SS_tot = sum((Hdiff0 - mean(Hdiff0)).^2);
SS_res = sum((Hdiff0 - Hdiff_test).^2);
if SS_tot == 0
    Metric.R_squared = NaN;
else
    Metric.R_squared = 1 - (SS_res / SS_tot);
end

% Normalized RMSE (as percentage of data range)
data_range = max(Hdiff0) - min(Hdiff0);
if data_range == 0
    Metric.NRMSE = NaN;
else
    Metric.NRMSE = RMSE / data_range;
end

% Pearson Correlation Coefficient
Y_flat = Hdiff0;
Y_pred_flat = Hdiff_test;
covariance = mean((Y_flat - mean(Y_flat)) .* (Y_pred_flat - mean(Y_pred_flat)));
std_Y = std(Y_flat);
std_Y_pred = std(Y_pred_flat);
if std_Y == 0 || std_Y_pred == 0
    Metric.Correlation = NaN;
else
    Metric.Correlation = covariance / (std_Y * std_Y_pred);
end

% Cosine Similarity
dot_product = sum(Y_flat .* Y_pred_flat);
norm_Y = norm(Y_flat);
norm_Y_pred = norm(Y_pred_flat);
if norm_Y == 0 || norm_Y_pred == 0
    Metric.CosineSimilarity = NaN;
else
    Metric.CosineSimilarity = dot_product / (norm_Y * norm_Y_pred);
end

% Try to calculate SSIM if Image Processing Toolbox is available
try
    if license('test', 'Image_Toolbox')
        Metric.SSIM = ssim(reshape(Hdiff0, size(Hdiff0)), reshape(Hdiff_test, size(Hdiff_test)));
    else
        % Simplified SSIM calculation
        K1 = 0.01;
        K2 = 0.03;
        L = max(Hdiff0) - min(Hdiff0);
        if L == 0, L = 1; end
        
        C1 = (K1*L)^2;
        C2 = (K2*L)^2;
        
        mu_Y = mean(Hdiff0);
        mu_Y_pred = mean(Hdiff_test);
        
        sigma_Y = std(Hdiff0);
        sigma_Y_pred = std(Hdiff_test);
        
        Y_centered = Hdiff0 - mu_Y;
        Y_pred_centered = Hdiff_test - mu_Y_pred;
        sigma_Y_Y_pred = mean(Y_centered .* Y_pred_centered);
        
        luminance = (2*mu_Y*mu_Y_pred + C1) / (mu_Y^2 + mu_Y_pred^2 + C1);
        contrast = (2*sigma_Y*sigma_Y_pred + C2) / (sigma_Y^2 + sigma_Y_pred^2 + C2);
        structure = (sigma_Y_Y_pred + C2/2) / (sigma_Y * sigma_Y_pred + C2/2);
        
        Metric.SSIM = luminance * contrast * structure;
    end
catch
    warning('Could not compute SSIM');
    Metric.SSIM = NaN;
end

% Peak Signal-to-Noise Ratio
max_Y = max(Hdiff0);
if max_Y == 0 || MSE == 0
    Metric.PSNR = NaN;
else
    Metric.PSNR = 20 * log10(max_Y / sqrt(MSE));
end

% Distribution Metrics - KL Divergence
% Apply small epsilon to avoid log(0) and division by zero
Y_norm = Hdiff0 + epsilon;
Y_pred_norm = Hdiff_test + epsilon;

% Renormalize
Y_norm = Y_norm / sum(Y_norm);
Y_pred_norm = Y_pred_norm / sum(Y_pred_norm);

% Calculate KL divergence
kl_div = Y_norm .* log(Y_norm ./ Y_pred_norm);
Metric.KLDivergence = sum(kl_div);

%% Display the results
disp('----------');
% Display the results
fprintf('Mean Absolute Error (MAE): %.4f\n', Metric.MAE);
fprintf('Mean Squared Error (MSE): %.4f\n', Metric.MSE);
fprintf('Root Mean Squared Error (RMSE): %.4f\n', Metric.RMSE);
fprintf('R-squared: %.4f\n', Metric.R_squared);
fprintf('MARE: %.4f\n', Metric.MARE);
fprintf('MARE2: %.4f\n', Metric.MARE2);

disp('----- By Deviations -----');
fprintf('False Positive Rate (FPR): %.4f\n', Metric.FPR);
fprintf('False Negative Rate (FNR): %.4f\n', Metric.FNR);
fprintf('Accuracy: %.4f\n', Metric.Accuracy);

disp('----- By Element -----');
fprintf('False Positive Rate (FPR): %.4f\n', Metric.FPR_ele);
fprintf('False Negative Rate (FNR): %.4f\n', Metric.FNR_ele);
fprintf('Accuracy: %.4f\n', Metric.Accuracy_ele);

disp('----- Additional Metrics -----');
fprintf('Normalized RMSE: %.4f\n', Metric.NRMSE);
fprintf('Pearson Correlation: %.4f\n', Metric.Correlation);
fprintf('Cosine Similarity: %.4f\n', Metric.CosineSimilarity);
fprintf('SSIM: %.4f\n', Metric.SSIM);
fprintf('PSNR: %.4f\n', Metric.PSNR);
fprintf('KL Divergence: %.4f\n', Metric.KLDivergence);

end