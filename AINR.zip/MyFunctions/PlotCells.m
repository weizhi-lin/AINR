function PlotCells(D,S,Mesh)
% Plot patches on the design and scan shapes
ftsize = 15;
fttype = 'times';
mksize = 20;

[vertex1,faces1] = MeshRead(Mesh);

[~,index] = ismember(D.V,vertex1,"rows");
Label = ones(length(vertex1),1);
Label(index) = 0.1;


% figure()
% ax1 = subplot(2,4,[1 5]);
% p = subplot(2,5,[1 6]);
p = subplot(2,2,[1 3]);
options.face_vertex_color = Label;
plot_mesh(vertex1,faces1,options); hold on;
plot3(D.V(D.Center,1),D.V(D.Center,2),D.V(D.Center,3),'.r','MarkerSize',mksize); hold on;
% plot3(D.V(BCresult.lmkb_Design(1),1),D.V(BCresult.lmkb_Design(1),2),D.V(BCresult.lmkb_Design(1),3),'.y','MarkerSize',12); hold on;
% plot3(D.V(BCresult.lmkb_Design(2),1),D.V(BCresult.lmkb_Design(2),2),D.V(BCresult.lmkb_Design(2),3),'.g','MarkerSize',12); hold on;
axis tight
Plot3AxisAtOrigin(gca)
mymap = [77 100 171
    218 221 230]/255;



% figure()
% p1 = subplot(2,5,2);
p1 = subplot(2,2,2);
plot_mesh(D.V,D.F); hold on
plot3(D.V(D.Center,1),D.V(D.Center,2),D.V(D.Center,3),'.r','MarkerSize',mksize); hold on;
% plot3(D.V(BCresult.lmkb_Design(1),1),D.V(BCresult.lmkb_Design(1),2),D.V(BCresult.lmkb_Design(1),3),'bo','MarkerFaceColor','y'); hold on;
% plot3(D.V(BCresult.lmkb_Design(2),1),D.V(BCresult.lmkb_Design(2),2),D.V(BCresult.lmkb_Design(2),3),'bo','MarkerFaceColor','g'); 
title('Design','FontName',fttype,'FontSize',ftsize);
% axis tight
% Plot3AxisAtOrigin(gca)
% p2 = subplot(2,5,3);
p2 = subplot(2,2,4);
plot_mesh(S.V,S.F); hold on 
plot3(S.V(S.Center,1),S.V(S.Center,2),S.V(S.Center,3),'.r','MarkerSize',mksize); hold on;
% plot3(S.V(BCresult.lmkb_Scan(1),1),S.V(BCresult.lmkb_Scan(1),2),S.V(BCresult.lmkb_Scan(1),3),'bo','MarkerFaceColor','y'); hold on;
% plot3(S.V(BCresult.lmkb_Scan(2),1),S.V(BCresult.lmkb_Scan(2),2),S.V(BCresult.lmkb_Scan(2),3),'bo','MarkerFaceColor','g'); 

colormap(p1,[163 182 212]/255);
colormap(p2,[163 182 212]/255);
colormap(p,mymap);
title('Scan','FontName',fttype,'FontSize',ftsize);
camlight('headlight')

end 