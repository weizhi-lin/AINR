function graphmultiq(L,x,y,a,b,h,e)
% x, y column vectors for data points
[x1,y1] = meshgrid(a:h:b);
[m,n] = size(x1);
z1 = zeros(m,m);
for i = 1:m
    for j = 1:m
        z1(i,j) = feval('splmultiq',L,x,y,x1(i,j),y1(i,j),e);
    end
end
mesh(x1,y1,z1);
end

function A = matmultiq(x,y,e)
% A: interpolation matrix for multiquadric
% x,y: centers coordinates enter as column
% e: multiquadraic parameters 
N = length(x);
o = ones(1,length(x));
r = sqrt((x*o-(x*o)').^2+(y*o-(y*o)').^2);
A = multiq(r,e);
end

function p = multiq(r,e)
p = sqrt(1+(e*r).^2);
end

function L = splinemultiq(x,y,z,e)
% L: vector with weights of radial basis function
% e: multiquadrics parameters 
% x,y,z: coordinate vectors of the data points
% build interpolation matrix A 
A = matmultq(x,y,e);
%solve the system A*L = z
L = A\z;
end

function S = splmultq(L,x0,y0,x,y,e)
% x0,y0 data points in the plane
% (x,y) evalution points
N = length(x0);
x1 = x*ones(N,1);
y1 = y*ones(N,1);
S = L'*multiq(sqrt((x1-x0).^2+(y1-y0).^2),e);
end

% Main 
% choose values for a,b,h,e
% L = splinemultiq(x,y,z,e);
% graphmultiq(L,x,y,a,b,h,e);
