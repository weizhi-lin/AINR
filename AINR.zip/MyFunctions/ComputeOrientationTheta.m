function ThetaOri = ComputeOrientationTheta(vertex,face)
% compute the orientation (angle between the z axis and the normal) of each
% vertex

% v = [0,0,1];
[normalD, ~] = meshVertexNormals(vertex,face); 

ThetaOri = zeros(length(vertex),1);
for i = 1:length(vertex)
    u = normalD(i,:);
    v = [normalD(i,1),normalD(i,2),0];
    CosTheta = max(min(dot(u,v)/(norm(u)*norm(v)),1),-1);
    ThetaOri(i) = real(acosd(CosTheta)); 
end

end