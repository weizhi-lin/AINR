function [vertexV, facesV] = UniformRemesh_new(vertex, faces, remeshN)
    % Uniform remeshing of a mesh
    % Input:
    %   vertex: 3xN matrix of vertex coordinates
    %   faces: 3xM matrix of face indices
    %   remeshN: target number of vertices
    % Output:
    %   vertexV: 3xremeshN matrix of new vertex coordinates
    %   facesV: 3xK matrix of new face indices

    % Ensure correct input dimensions
    if size(vertex, 2) < size(vertex, 1)
        vertex = vertex';
    end
    if size(faces, 2) < size(faces, 1)
        faces = faces';
    end

    n = size(vertex, 2);
    m = remeshN;
    
    % Start with a random point
    landmarks = randi(n, 1);
    
    % Compute initial distance map
    [D, ~, ~] = perform_fast_marching_mesh(vertex, faces, landmarks);
    
    % Add points one by one, maximizing the minimum distance
    for i = 2:m
        % Select the farthest point from existing landmarks
        [~, new_landmark] = max(D);
        landmarks(end+1) = new_landmark;
        
        % Update distance map
        options.constraint_map = D;
        [D1, ~, ~] = perform_fast_marching_mesh(vertex, faces, landmarks, options);
        D = min(D, D1);
    end
    
    % Compute the new mesh
    [~, ~, Q] = perform_fast_marching_mesh(vertex, faces, landmarks);
    
    % Extract faces
    V = Q(faces);
    V = sort(V, 1);
    V = unique(V', 'rows')';
    d = 1 + (V(1,:)~=V(2,:)) + (V(2,:)~=V(3,:));
    I = find(d==3);
    I = sort(I);
    
    % Create new face indices
    z = zeros(n, 1);
    z(landmarks) = (1:length(landmarks))';
    facesV = z(V(:,I));
    
    % Get new vertex coordinates
    vertexV = vertex(:, landmarks);
    
    % Re-orient faces to point outward
    options.method = 'slow';
    options.verb = 0;
    facesV = perform_faces_reorientation(vertexV, facesV, options);
end