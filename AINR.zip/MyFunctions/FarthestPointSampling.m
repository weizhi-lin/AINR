function landmarks = FarthestPointSampling(vertex,faces,Nlmk,para)
currentFolder = para.currentFolder;

options.curvature_smoothing = 10;
options.verb = 0;
[~,~,~,~,~,Cgauss,~] = compute_curvature(vertex,faces,options);
% localmax=islocalmax(Cgauss);%find local maxima
% localmax_n=find(localmax,10);

m=Nlmk;
ini_n = find(Cgauss == max(Cgauss(:))); 
landmarks = ini_n;

compile_mex  %uncomment this line
[D,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks);

for i=2:m
    % select
    [~,landmarks(end+1)] = max(D);
    % update
    options.constraint_map = D;
    [D1,~,~] = perform_fast_marching_mesh(vertex, faces,landmarks,options);
    D = min(D,D1);
end

if(~isdeployed)
  cd(currentFolder);
end

end