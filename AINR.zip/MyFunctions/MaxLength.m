function [lenm,edges,lengths] = MaxLength(vertex,faces)

% compute the max length of the edges
edges = meshEdges(vertex, faces); % edge vertex indices from face array.
lengths = meshEdgeLength(vertex, edges, faces);
lenm = max(lengths);
end