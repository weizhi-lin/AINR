function [V_seg,F_seg] = PatchFinalize2(V_seg,F_seg,normOseg,normOcenter)
% seg_ct: index of landmark on the segment
% normOcenter: normal of the landmark on the original shape 3 X 1
% Function: modify the direction of normals on each segment
% Compute the attributes on each vertex
% Output: data structure for each segment

% [normalPd,~] = meshVertexNormals(V_seg,F_seg);
% compute the inner product of the lmk's normals

sign = dot(normOcenter,normOseg);

if sign < 0
    [F_seg] = flip_faces_orientation(F_seg);
    [~,~] = meshVertexNormals(V_seg,F_seg);
end

% [Lambda,Cgauss,Cmean,Ctotal] = ComputeWeightFunction(V_seg,F_seg);

% M.V = V_seg;
% M.F = F_seg;
% M.Center = seg_ct;
% M.normalC = normalPd(seg_ct,:);
% M.Cgauss = Cgauss;
% M.Cmean = Cmean;
% M.Lambda = Lambda;
% M.Ctotal = Ctotal;
% M.normal = normalPd;


end