function BCresult = PairBCdiff(vertex1,faces1,vertex2,faces2,Ind_design,Ind_scan)

% construct pair-wise parameterization 
% Input: design mesh, scan mesh, landmarks
% Output: parameterized design & scan;
%         boundary landmarks on design & scan;
%         GP landmarks on design & scan;
% 7/5/2022 Weizhi Lin
% inpute vertex and faces should be N*3

if size(vertex1,1)==3
    vertex1 = vertex1';
end

if size(vertex2,1)==3
    vertex2 = vertex2';
end

if size(faces1,1)==3
    faces1 = faces1';
end

if size(faces2,1)==3
    faces2 = faces2';
end



[vertex1,faces1] = removeInvalidBorderFaces(vertex1,faces1);
[vertex1,faces1] = removeMeshEars(vertex1,faces1);

lmkb = findsquareapex(vertex1,faces1)'; % find apexes for the square
rect1 = rect_conformal_parameterization(vertex1,faces1,lmkb);

% lmkb2 = findsquareapex(vertex2,faces2)'; 
lmkb2 = BDLmkProject(vertex1,lmkb, vertex2, faces2);
rect2 = rect_conformal_parameterization(vertex2,faces2,lmkb2);

BCresult.lmkb_Design = lmkb;
BCresult.lmkb_Scan = lmkb2;
BCresult.rect_Design = rect1;
BCresult.rect_Scan = rect2;
BCresult.lmk_Design = Ind_design;
BCresult.lmk_Scan = Ind_scan;

%% Registration
interior_landmark = Ind_design'; % indices of the interior landmarks
interior_landmark_target = rect2(Ind_scan,1:2); % target positions of the landmarks
height = max(rect2(:,2)); % target height of the rectangle

% Compute the Teichmuller map between the rectangles using QC Iteration
[tmap,tmap_bc] = rectangular_Teichmuller_map(rect1,faces1,...
    interior_landmark,interior_landmark_target,lmkb,height);

BCresult.tmap = tmap;
BCresult.tmap_bc = tmap_bc;

% Computing the Teichmuller distance
d = 1/2*log((1+mean(abs(tmap_bc)))/(1-mean(abs(tmap_bc)))); 
fprintf('Teichmuller distnace between the teeth = %f\n',d);
BCresult.Tdist = d;

[~,K1,H1,~] = ComputeWeightFunction(vertex1,faces1);
[~,K2,H2,~] = ComputeWeightFunction(vertex2,faces2);

H2_interp = scatteredInterpolant(vertex2(:,1),vertex2(:,2),vertex2(:,3),H2,'linear');
K2_interp = scatteredInterpolant(vertex2(:,1),vertex2(:,2),vertex2(:,3),K2,'linear');

% Construct the interpolants
% from parameterized target to 3D shape 
Fx = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,1),'linear');
Fy = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,2),'linear');
Fz = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,3),'linear');

% Find the surface T-map
tmap_surface = zeros(length(tmap),3);
tmap_surface(:,1) = Fx(tmap(:,1),tmap(:,2));
tmap_surface(:,2) = Fy(tmap(:,1),tmap(:,2));
tmap_surface(:,3) = Fz(tmap(:,1),tmap(:,2));

H_diff = H1 - H2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3));
K_diff = K1 - K2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3));

BCresult.tmap_surface = tmap_surface;
BCresult.Hdiff = H_diff;
BCresult.Kdiff = K_diff;

Hprodist = sqrt(meansqr(H_diff));
Kprodist = sqrt(meansqr(K_diff));
BCresult.Hprodist = Hprodist;
BCresult.Kprodist = Kprodist;

MeanBcV = [];
for j = 1:length(tmap)
    [row,~] = find(ismember(faces1,j));
    MeanBcV(j) = mean(tmap_bc(row));
end
BCv = MeanBcV;
BCresult.tmap_meanBC = BCv;
BCresult.DV = vertex1;
BCresult.DF = faces1;

% if F==1
%     figure()
%     subplot(2,2,1)
%     plot_mesh(vertex1,faces1);view([170 0]);hold on
%     plot3(vertex1(Ind_design,1),vertex1(Ind_design,2),vertex1(Ind_design,3),'ro','MarkerFaceColor','r');
%     hold on;
%     plot3(vertex1(lmkb,1),vertex1(lmkb,2),vertex1(lmkb,3),'bo','MarkerFaceColor','b');
%     title('Design');
%     
%     subplot(2,2,2)
%     plot_mesh(vertex2,faces2); view([170 0]);hold on
%     plot3(vertex2(Ind_scan,1),vertex2(Ind_scan,2),vertex2(Ind_scan,3),'ro','MarkerFaceColor','r');
%     hold on;
%     plot3(vertex2(lmkb2,1),vertex2(lmkb2,2),vertex2(lmkb2,3),'bo','MarkerFaceColor','b');
%     colormap([0.8 1 0.8]);
%     title('Scan');
%     
%     subplot(2,2,3)
%     show_mesh(rect1,faces1);hold on;%axis([0 0.4 0.2 0.6]);
%     plot(rect1(lmkb,1),rect1(lmkb,2),'bo','MarkerFaceColor','b'); hold on;
%     plot(rect1(Ind_design,1),rect1(Ind_design,2),'ro','MarkerFaceColor','r');
%     title('Rectangular conformal parameterization of design');
%     
%     subplot(2,2,4)
%     show_mesh(rect2,faces2);hold on; %axis([0 0.4 0.2 0.6]);
%     plot(rect2(lmkb2,1),rect2(lmkb2,2),'bo','MarkerFaceColor','b'); hold on;
%     plot(rect2(Ind_scan,1),rect2(Ind_scan,2),'ro','MarkerFaceColor','r');
%     title('Rectangular conformal parameterization of scan');
%     sgtitle([num2str(j),' th shape; ', num2str(k),'th segment']);
% end 
    

end