function G = MeshPrepare(G1,options,para)
% prepare mesh for cp distance computation
% for small scale mesh 

[vertex,faces] = MeshRead(G1);
[vertex] = mesh_smooth(vertex,faces,1);
[vertex,faces] = MeshProcess(vertex,faces);
G1 = Mesh('VF',vertex',faces');

[G1.Aux.Area,G1.Aux.Center] = G1.Centralize('ScaleArea');
G1.ComputeMidEdgeUniformization(options,para); % modify the graph function/fastmarching/pca
G1.Nf = G1.ComputeFaceNormals;
G1.Nv = G1.F2V'*G1.Nf';
G1.Nv = G1.Nv'*diag(1./sqrt(sum((G1.Nv').^2,1)));
G1.Aux.LB = G1.ComputeCotanLaplacian;
G = Mesh(G1);
end