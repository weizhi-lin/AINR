function [lmk,lmkC] = SegGPlmk_geo(BC_seg,Nlmk)

% assign landmarks number according to the 'Assign' feature

N = size(BC_seg.BCresult,2);
area = [];
for i = 1:N
%     [V_seg{i},F_seg{i}] = MeshEnsureManifold(V_seg{i}',F_seg{i}');
    M{i} = Mesh('VF',BC_seg.BCresult{i}.DV',BC_seg.BCresult{i}.DF');
    area(i) = meshSurfaceArea(M{i}.V',M{i}.F');
    M{i}.Normalize();
    [~,~,flip] = M{i}.ComputeNormal();
    if flip
        M{i}.F = M{i}.F([1 3 2],:);
    end
    M{i}.Aux.WKS = M{i}.ComputeWKS([]);
end  

Asum = sum(area); % total area of the mesh
ratio = area./Asum;

Ns = ceil(ratio.*Nlmk); % round up to integer

Ns(Ns<ceil(Nlmk/N))=ceil(Nlmk/N);

% determined by threshold from portion

for i = 1:N
    % Dev = BC_seg.BCresult{i}.Hdiff;
    [GPLmkIdx,lmkcor] = GetGPLmk_new(M{i},Ns(i),0.8,0.8);
    lmk{i}= GPLmkIdx;
    lmkC{i} = lmkcor;
end

end