function [landmarks,label] = GaussFPSSegmentation(vertex,faces,Nlmk,para)
currentFolder = para.currentFolder;
% inpute vertex should be 3*N
if size(vertex,2)<size(vertex,1)
    vertex = vertex';
end
if size(faces,2)<size(faces,1)
    faces = faces';
end

options.verb = 0;
[~,~,~,~,~,Cgauss,~] = compute_curvature(vertex,faces,options);


m = Nlmk;
W = rescale(Cgauss, .001, 1);
options.W = W;
ini_n = find(Cgauss == max(Cgauss(:))); 
landmarks = ini_n;

% compile_mex

[D,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks);


for i=2:m
    % select
    [~,landmarks(end+1)] = max(D);
    % update
    options.constraint_map = D;
    [D1,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks,options);
    D = min(D,D1);
end


[D,Z,Q] = perform_fast_marching_mesh(vertex, faces, landmarks);
[B,I,J] = unique(Q);
v = randperm(m)'; % without repeating elements
J = v(J);

label = J;

if(~isdeployed)
  cd(currentFolder);
end

end