function [Label,Dist,MeanStep] = RegionGrowPatch(vertex1,faces1,lmk,MAttr,para)
if nargin<5
    s = 0.9;
    md = 16;
else
    s = para.s;
    md = para.md;
end

% % illustration of the evolution 
K_gauss = MAttr.K_gauss;
K_theta = MAttr.K_theta;
K_phi = MAttr.K_phi;
C_mean= MAttr.C_mean;
C_gauss= MAttr.C_gauss;

N=100; % expansion steps

% weight the difussion distance based on smoothness of gaussian curvature 
options = [];
% W = rescale(-abs(C_mean),0.01,1); %rescale(K_gauss(indxkeep));
% options.W = W;
options.nb_iter_max = Inf;

[D,~,~] = perform_fast_marching_mesh(vertex1,faces1,lmk,options);

% figure()
% options.face_vertex_color = mod(D,1);%mod( 20*D/max(D),1 );
% plot_mesh(vertex1,faces1, options); hold on 
% colormap jet(256);
% plot3(vertex1(lmk,1),vertex1(lmk,2),vertex1(lmk,3),'.b','MarkerSize',10); shading flat

SD = sort(D);

% teeth: 0.9
dstep = s*max(diff(SD));

d0 = SD(2); % smallest distance from the center 

MeanStep = zeros(N,6);
% gradually expend the patch and exam the statistics of the added region 
for i = 1:N
    d_i0 = d0+(i-1)*dstep; % this is for parfor
    d_i = d0+i*dstep;

    indx = find(D<=d_i & D>d_i0); % indices of the added vertices
    % indx0 = find(D<=d_i0); %indices of the current patch

    if isempty(indx)
        continue;
    end

    % X0 = [K_gauss(indx0),K_theta(indx0)];
    X = [K_gauss(indx),K_theta(indx),K_phi(indx)];

    MeanStep(i,1) = d_i;
    MeanStep(i,2) = max(X(:,1));
    MeanStep(i,3) = quantile(C_mean(indx),0.9)-quantile(C_mean(indx),0.1);%median(C_mean(indx));
    MeanStep(i,4:5) = [max(X(:,2)),max(X(:,3))];%M(:,2:3);
    Cmean_add = C_mean(indx);
    [~,ind_6] = max(abs(Cmean_add));
    MeanStep(i,6) = Cmean_add(ind_6);
end 

% figure()
% findchangepts(MeanStep(:,2),MinDistance=10,Statistic="std",MinThreshold=3);
% figure()
% findchangepts(MeanStep(:,4),MinDistance=10,Statistic="std",MinThreshold=3);
% figure()
% findchangepts(MeanStep(:,3),MinDistance=10,Statistic="std",MinThreshold=20);
% figure()
% findchangepts(MeanStep(:,6),MinDistance=10,Statistic="std",MinThreshold=20);


%% For teeth
% md = 16;
% max K_gauss
[ipt1,~] = findchangepts(MeanStep(:,2),MinDistance=floor(md*0.8),MinThreshold=5,Statistic="std");
%IQR curvature
[ipt2,~] = findchangepts(MeanStep(:,3),MinDistance=floor(md*0.6),MinThreshold=10,Statistic="std");
% K_theta
[ipt3,~] = findchangepts(MeanStep(:,4),MinDistance=md,MinThreshold=5,Statistic="std");
%K_phi
[ipt4,~] = findchangepts(MeanStep(:,5),MinDistance=floor(md*0.9),MinThreshold=10,Statistic="std");
%max(curvature)
[ipt5,~] = findchangepts(MeanStep(:,6),MinDistance=floor(md*0.8),MinThreshold=10,Statistic="std");

% %% for freeform: extend the sizes
% %K_gauss
% [ipt1,~] = findchangepts(MeanStep(:,2),MinDistance=20,MinThreshold=3,Statistic="std");
% %K_theta
% [ipt2,~] = findchangepts(MeanStep(:,3),MinDistance=20,MinThreshold=3,Statistic="std");
% % max K_gauss
% [ipt3,~] = findchangepts(MeanStep(:,4),MinDistance=20,MinThreshold=3,Statistic="std");
% %IQR curvature
% [ipt4,~] = findchangepts(MeanStep(:,5),MinDistance=20,MinThreshold=3,Statistic="std");
% 

if i<5% || MeanStep(ipt5(1),6)* C_mean(lmk)<0
    disp('Detected region too small')
    Label = [];
    Dist = [];
    return
end

if isempty(ipt1) || isempty(ipt2) || isempty(ipt3) || isempty(ipt4) || isempty(ipt5) 
    ipt = min([ipt1;ipt2;ipt3;ipt4;ipt5]);
    if isempty(ipt)
        disp('Fail to find the boundary');
        Label = [];
        Dist = [];
        
        return;
    else
        Dist = MeanStep(ipt,1);
        Label = zeros(length(D),1);
        Label(D<=Dist) = 1;
        disp('One of attribute has 0 change point.')
        return
    end
end

IPT = [ipt1(1),ipt2(1),ipt3(1),ipt4(1),ipt5(1)];

if range(IPT)>10 && min(IPT)< 10 && MeanStep((min(IPT)-2),1)<1 % for cases the min is too small
    if range(IPT)>50
        % if two changepoints are too far away from each other 
        dif = range(IPT)/10;
        ipt = floor(min(IPT)+dif);
    else
        dif = range(IPT)/6;
        ipt = floor(min(IPT)+dif);
    end
else
     ipt =min(IPT);
end



% Dist = MeanStep((ipt-2),1);

Dist = MeanStep((ipt-2),1); % for comple shape like teeth, avoid irregular boundary

Label = zeros(length(D),1);
Label(D<=Dist) = 1;

end 
% % % 
% figure()
% options.face_vertex_color = Label;%mod( 20*D/max(D),1 );
% plot_mesh(vertex1,faces1, options); hold on 
% colormap(mymap);%jet(256);
% plot3(vertex1(lmk,1),vertex1(lmk,2),vertex1(lmk,3),'.b','MarkerSize',10); shading flat


% %% plots for the paper 
% p = figure;
% p.Position = [10 10 1500 300]; 
% subplot(1,3,1)
% plot(MeanStep(:,1),MeanStep(:,3),'LineWidth',2); hold on
% scatter(MeanStep(1:ipt2(1),1),MeanStep(1:ipt2(1),3),15,'r','filled'); hold on 
% lab = string((1:length(ipt2)));
% xline(MeanStep(ipt2,1),'-',lab,'LabelHorizontalAlignment','center');
% % text(MeanStep(ipt2,1),MeanStep(ipt2,3)+0.001,string(1:length(ipt2)),'FontSize',15);
% yline(0);
% ylim([0,200]);
% ylabel('max(\Delta\theta)','FontName',fttype,'FontSize',ftsize);
% xlabel('d','FontName',fttype,'FontSize',ftsize);
% title('Changes of max(\Delta\theta)','FontName',fttype,'FontSize',ftsize);
% 
% subplot(1,3,2)
% plot(MeanStep(:,1),MeanStep(:,4),'LineWidth',2); hold on
% scatter(MeanStep(1:ipt3(1),1),MeanStep(1:ipt3(1),4),15,'r','filled'); hold on 
% lab = string((1:length(ipt3)));
% xline(MeanStep(ipt3,1),'-',lab,'LabelHorizontalAlignment','center');
% % text(MeanStep(ipt3,1),MeanStep(ipt3,4)+0.001,string(1:length(ipt3)),'FontSize',15);
% yline(0);
% ylabel('max(\Delta\kappa)','FontName',fttype,'FontSize',ftsize);
% xlabel('d','FontName',fttype,'FontSize',ftsize);
% title('Changes of max(\Delta\kappa)','FontName',fttype,'FontSize',ftsize);
% 
% subplot(1,3,3)
% plot(MeanStep(:,1),MeanStep(:,5),'LineWidth',2); hold on
% scatter(MeanStep(1:ipt4(1),1),MeanStep(1:ipt4(1),5),15,'r','filled'); hold on 
% lab = string((1:length(ipt4)));
% xline(MeanStep(ipt4,1),'-',lab,'LabelHorizontalAlignment','center');
% % text(MeanStep(ipt4,1),MeanStep(ipt4,5)+0.001,string(1:length(ipt4)),'FontSize',15);
% yline(0);
% ylabel('IQR(H)','FontName',fttype,'FontSize',ftsize);
% xlabel('d','FontName',fttype,'FontSize',ftsize);
% title('Changes of IQR(H)','FontName',fttype,'FontSize',ftsize);
% 


% % plots for the paper 
% p = figure;
% p.Position = [10 10 1500 300]; 
% subplot(1,4,1)
% plot(MeanStep(:,1),MeanStep(:,3),'LineWidth',2); hold on
% scatter(MeanStep(1:ipt2(1),1),MeanStep(1:ipt2(1),3),15,'r','filled'); hold on 
% lab = string((1:length(ipt2)));
% xline(MeanStep(ipt2,1),'-',lab,'LabelHorizontalAlignment','center');
% % text(MeanStep(ipt2,1),MeanStep(ipt2,3)+0.001,string(1:length(ipt2)),'FontSize',15);
% yline(0);
% % ylim([0,200]);
% ylabel('IQR(H)','FontName',fttype,'FontSize',ftsize);
% xlabel('d','FontName',fttype,'FontSize',ftsize);
% title('Changes of max(\Delta\theta)','FontName',fttype,'FontSize',ftsize);
% 
% subplot(1,4,2)
% plot(MeanStep(:,1),MeanStep(:,4),'LineWidth',2); hold on
% scatter(MeanStep(1:ipt3(1),1),MeanStep(1:ipt3(1),4),15,'r','filled'); hold on 
% lab = string((1:length(ipt3)));
% xline(MeanStep(ipt3,1),'-',lab,'LabelHorizontalAlignment','center');
% % text(MeanStep(ipt3,1),MeanStep(ipt3,4)+0.001,string(1:length(ipt3)),'FontSize',15);
% yline(0);
% ylabel('max(\Delta\theta)','FontName',fttype,'FontSize',ftsize);
% xlabel('d','FontName',fttype,'FontSize',ftsize);
% title('Changes of max(\Delta\theta)','FontName',fttype,'FontSize',ftsize);
% 
% subplot(1,4,3)
% plot(MeanStep(:,1),MeanStep(:,5),'LineWidth',2); hold on
% scatter(MeanStep(1:ipt4(1),1),MeanStep(1:ipt4(1),5),15,'r','filled'); hold on 
% lab = string((1:length(ipt4)));
% xline(MeanStep(ipt4,1),'-',lab,'LabelHorizontalAlignment','center');
% % text(MeanStep(ipt4,1),MeanStep(ipt4,5)+0.001,string(1:length(ipt4)),'FontSize',15);
% yline(0);
% ylabel('max(\Delta\phi)','FontName',fttype,'FontSize',ftsize);
% xlabel('d','FontName',fttype,'FontSize',ftsize);
% title('Changes of max(\Delta\phi)','FontName',fttype,'FontSize',ftsize);
% 
% 
% subplot(1,4,4)
% plot(MeanStep(:,1),MeanStep(:,2),'LineWidth',2); hold on
% scatter(MeanStep(1:ipt1(1),1),MeanStep(1:ipt1(1),2),15,'r','filled'); hold on 
% lab = string((1:length(ipt1)));
% xline(MeanStep(ipt1,1),'-',lab,'LabelHorizontalAlignment','center');
% % text(MeanStep(ipt4,1),MeanStep(ipt4,5)+0.001,string(1:length(ipt4)),'FontSize',15);
% yline(0);
% ylabel('max(\Delta\kappa)','FontName',fttype,'FontSize',ftsize);
% xlabel('d','FontName',fttype,'FontSize',ftsize);
% title('Changes of max(\Delta\kappa)','FontName',fttype,'FontSize',ftsize);
% 
