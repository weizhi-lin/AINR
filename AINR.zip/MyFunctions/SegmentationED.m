function [IC,label1] = SegmentationED(vertexV,facesV,vertex1,faces1)

% Euclidean distance 
D = pdist(vertexV);
DS_E = squareform(D);

%% Step4: Clustering-based segmentation
[rho,delta,~,~] = FindBestDesicionValue(DS_E);
[C_ind,N] = ClusterCenter(rho,delta);

disp(['Number of segments is ',num2str(N)]) 
% assign vertex to each cluster 
label = AssignCluster(C_ind, DS_E);


%% Step5: Segment projection and reconstruction 
% position of cluster center on the original mesh
vertexC = vertexV(C_ind,:);
[~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);

% project the clustering result to the orignal(designed) shape
label1 = ProjectClustering(vertexV, vertex1, label);

%% Visualization 
figure()
% show the positions of cluster center on the remeshed mesh 
subplot(1,3,1)
options.face_vertex_color = label;
plot_mesh(vertexV,facesV,options);shading faceted;
colormap jet(256);
hold on;
h = plot3(vertexV(C_ind,1), vertexV(C_ind,2), vertexV(C_ind,3), 'r.');
set(h, 'MarkerSize', 25);
title(['Size of remesh: ',num2str(size(vertexV,1))]);

% clustering result on the original shape
subplot(1,3,2)
options.face_vertex_color = label1;
plot_mesh(vertex1,faces1,options);%shading faceted;
colormap jet(256);
hold on;
h = plot3(vertex1(IC,1), vertex1(IC,2), vertex1(IC,3), 'r.');
set(h, 'MarkerSize', 25);
title(['number of segments: ',num2str(N)]);

subplot(1,3,3)
scatter(rho,delta);hold on
scatter(rho(C_ind),delta(C_ind),'r');
title(['Decision Graph: ',num2str(N), ' segments']);
sgtitle('Euclidean distance');

end