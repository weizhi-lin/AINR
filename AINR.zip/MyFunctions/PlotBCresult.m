function PlotBCresult(D,S,BCresult,Mesh)
% Plot registration pipeline

ftsize = 15;
fttype = 'times';

[vertex1,faces1] = MeshRead(Mesh);

[~,index] = ismember(D.V,vertex1,"rows");
Label = ones(length(vertex1),1);
Label(index) = 0.1;

p0 = figure();
options.face_vertex_color = Label;
plot_mesh(vertex1,faces1,options); hold on;
plot3(D.V(D.Center,1),D.V(D.Center,2),D.V(D.Center,3),'.r','MarkerSize',12); hold on;
% plot3(D.V(BCresult.lmkb_Design(1),1),D.V(BCresult.lmkb_Design(1),2),D.V(BCresult.lmkb_Design(1),3),'.y','MarkerSize',12); hold on;
% plot3(D.V(BCresult.lmkb_Design(2),1),D.V(BCresult.lmkb_Design(2),2),D.V(BCresult.lmkb_Design(2),3),'.g','MarkerSize',12); hold on;
axis tight
Plot3AxisAtOrigin(gca)
mymap = [77 100 171
    218 221 230]/255;
colormap(p0,mymap);

figure()
% ax1 = subplot(2,4,[1 5]);
p = subplot(2,5,[1 6]);
options.face_vertex_color = Label;
plot_mesh(vertex1,faces1,options); hold on;
plot3(D.V(D.Center,1),D.V(D.Center,2),D.V(D.Center,3),'.r','MarkerSize',12); hold on;
plot3(D.V(BCresult.lmkb_Design(1),1),D.V(BCresult.lmkb_Design(1),2),D.V(BCresult.lmkb_Design(1),3),'.y','MarkerSize',12); hold on;
plot3(D.V(BCresult.lmkb_Design(2),1),D.V(BCresult.lmkb_Design(2),2),D.V(BCresult.lmkb_Design(2),3),'.g','MarkerSize',12); hold on;
axis tight
Plot3AxisAtOrigin(gca)
mymap = [77 100 171
    218 221 230]/255;
colormap(p,mymap);


% figure()
p1 = subplot(2,5,2);
plot_mesh(D.V,D.F); hold on
plot3(D.V(D.Center,1),D.V(D.Center,2),D.V(D.Center,3),'.r','MarkerSize',15); hold on;
plot3(D.V(BCresult.lmkb_Design(1),1),D.V(BCresult.lmkb_Design(1),2),D.V(BCresult.lmkb_Design(1),3),'bo','MarkerFaceColor','y'); hold on;
plot3(D.V(BCresult.lmkb_Design(2),1),D.V(BCresult.lmkb_Design(2),2),D.V(BCresult.lmkb_Design(2),3),'bo','MarkerFaceColor','g'); 
title('Design','FontName',fttype,'FontSize',ftsize);

p2 = subplot(2,5,3);
plot_mesh(S.V,S.F); hold on 
plot3(S.V(S.Center,1),S.V(S.Center,2),S.V(S.Center,3),'.r','MarkerSize',15); hold on;
plot3(S.V(BCresult.lmkb_Scan(1),1),S.V(BCresult.lmkb_Scan(1),2),S.V(BCresult.lmkb_Scan(1),3),'bo','MarkerFaceColor','y'); hold on;
plot3(S.V(BCresult.lmkb_Scan(2),1),S.V(BCresult.lmkb_Scan(2),2),S.V(BCresult.lmkb_Scan(2),3),'bo','MarkerFaceColor','g'); 
colormap(p1,[145 160 207]/255);
colormap(p2,[145 160 207]/255);
title('Scan','FontName',fttype,'FontSize',ftsize);

subplot(2,5,7)
show_mesh(BCresult.rect_Design,D.F);hold on;%axis([0 0.4 0.2 0.6]);
plot(BCresult.rect_Design(BCresult.lmkb_Design(1),1),BCresult.rect_Design(BCresult.lmkb_Design(1),2),'bo','MarkerFaceColor','y'); hold on;
plot(BCresult.rect_Design(BCresult.lmkb_Design(2),1),BCresult.rect_Design(BCresult.lmkb_Design(2),2),'bo','MarkerFaceColor','g'); hold on;
plot(BCresult.rect_Design(D.Center,1),BCresult.rect_Design(D.Center,2),'bo','MarkerFaceColor','r'); hold on;
title('Conformal Parameterization','FontName',fttype,'FontSize',ftsize);

subplot(2,5,8)
show_mesh(BCresult.rect_Scan,S.F);hold on;%axis([0 0.4 0.2 0.6]);
plot(BCresult.rect_Scan(BCresult.lmkb_Scan(1),1),BCresult.rect_Scan(BCresult.lmkb_Scan(1),2),'bo','MarkerFaceColor','y'); hold on;
plot(BCresult.rect_Scan(BCresult.lmkb_Scan(2),1),BCresult.rect_Scan(BCresult.lmkb_Scan(2),2),'bo','MarkerFaceColor','g'); hold on;
plot(BCresult.rect_Scan(S.Center,1),BCresult.rect_Scan(S.Center,2),'bo','MarkerFaceColor','r'); hold on;
title('Conformal Parameterization','FontName',fttype,'FontSize',ftsize);


% Deviation surfaces
rx = BCresult.tmap(:,1);
ry = BCresult.tmap(:,2);
rz1 = real(BCresult.tmap_meanBC)';
sf1 = fit([BCresult.tmap(:,1),BCresult.tmap(:,2)],real(BCresult.tmap_meanBC)','linearinterp');
sf2 = fit([BCresult.tmap(:,1),BCresult.tmap(:,2)],imag(BCresult.tmap_meanBC)','linearinterp');
sf3 = fit([BCresult.tmap(:,1),BCresult.tmap(:,2)],abs(BCresult.tmap_meanBC)','linearinterp');
sf4 = fit([BCresult.tmap(:,1),BCresult.tmap(:,2)],angle(BCresult.tmap_meanBC)','linearinterp');
% plot( sf, [BCresult.tmap(:,1),BCresult.tmap(:,2)],real(BCresult.tmap_meanBC)');

% figure()
p3 = subplot(2,5,[4 9]);
plot(sf1);hold on
scatter3(BCresult.tmap(:,1),BCresult.tmap(:,2),real(BCresult.tmap_meanBC),10,real(BCresult.tmap_meanBC),'filled');
title('Real Part','FontName',fttype,'FontSize',ftsize);

p4 = subplot(2,5,[5 10]);
plot(sf2);hold on
scatter3(BCresult.tmap(:,1),BCresult.tmap(:,2),imag(BCresult.tmap_meanBC),10,imag(BCresult.tmap_meanBC),'filled');
title('Imaginary Part','FontName',fttype,'FontSize',ftsize);
colormap(p3,"default");
colormap(p4,"default");
% axis tight

end 