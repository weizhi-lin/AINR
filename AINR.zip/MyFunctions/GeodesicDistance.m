function DS = GeodesicDistance(vertices,faces)
% input dimension should be N*3

if size(vertices,2)>size(vertices,1)
    vertices = vertices';
end

global geodesic_library;                
geodesic_library = 'geodesic_release'; 

N = size(vertices,1);

%initilize new mesh
mesh = geodesic_new_mesh(vertices,faces);   
%'exact''dijkstra');   %initialize new geodesic algorithm
algorithm = geodesic_new_algorithm(mesh,'exact');   

DS = zeros(N,N);

for i = 1:N
    %create a single source at vertex #1
    vertex_id = i;                            
    source_points = {geodesic_create_surface_point('vertex',vertex_id,vertices(vertex_id,:))};
    %propagation stage of the algorithm (the most time-consuming)
    geodesic_propagate(algorithm, source_points);   
    %create a single destination at vertex #N
    vertex_id = N;                              
    destination = geodesic_create_surface_point('vertex', vertex_id, vertices(vertex_id,:));
    %find a shortest path from source to destination
    path = geodesic_trace_back(algorithm, destination);
    %find distances to all vertices of the mesh (actual pathes are not computed)
    distances = zeros(N,1);    
    %find distances to all vertices of the mesh; 
    [~, distances] = geodesic_distance_and_source(algorithm);     
    DS(:,i)=distances;
end
geodesic_delete;

end