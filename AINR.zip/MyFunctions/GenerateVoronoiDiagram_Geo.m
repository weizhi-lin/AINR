function [J,D] = GenerateVoronoiDiagram_Geo(vertex,faces,landmarks)

% % inpute vertex should be 3*N
% if size(vertex,2)<size(vertex,1)
%     vertex = vertex';
% end
% if size(faces,2)<size(faces,1)
%     faces = faces';
% end

m = max(size(landmarks));
% cd("Toolbox/toolbox_graph"); 
% compile_mex


% [D,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks(1));
% for i=2:m
%     % select
%     % [~,landmarks(end+1)] = max(D);
%     % update
%     options.constraint_map = D;
%     [D1,~,Q] = perform_fast_marching_mesh(vertex, faces, landmarks(1:i),options);
%     D = min(D,D1);
% end
% 
% [B,I,J] = unique(Q);
% v = randperm(m)'; % without repeating elements
% J = v(J);
% 

% W = rescale(filter, .01, 1);
% options.W = W;
options = [];

[D,Z,Q] = perform_fast_marching_mesh(vertex, faces, landmarks);
[B,I,J] = unique(Q);
% commented on 07/22/2024
v = randperm(m)'; % without repeating elements
J = v(J);
% ----------



% if(~isdeployed)
%   cd(path);
% end
% 
% figure()
% options.face_vertex_color = perform_saturation(W,1.5);
% plot_mesh(vertex,faces, options); hold on
% colormap jet(256);shading flat
% h = plot3(vertex(landmarks,1), vertex(landmarks,2), vertex(landmarks,3), 'k.');
% set(h, 'MarkerSize', 35);
end