function  [M,MAttr] = MeshPrepareSim(vertex1,faces1,n_eigenvalues) %Cgauss,Cmean,

if nargin < 3
    n_eigenvalues = 300;
end

[~,Cgauss,Cmean,~] = ComputeWeightFunction(vertex1,faces1);
% compute the point orientation 
ThetaOri = ComputeOrientationTheta(vertex1,faces1);
PhiOri = ComputeOrientationPhi(vertex1,faces1);
% Voronoi areas for vertices
[A,~] = ComputeVoronoiAreasVertex(vertex1, faces1);
[normalDvex, ~] = meshVertexNormals(vertex1,faces1); 

[~,~,Cmin,Cmax,~,~,~] = compute_curvature(vertex1,faces1);
Ctotal = abs(Cmin)+abs(Cmax);

if size(vertex1,1)>3
    vertex1 = vertex1';
end
if size(faces1,1)>3
    faces1 = faces1';
end

M = Mesh('VF',vertex1, faces1);

M.Normalize();
[~,~,flip] = M.ComputeNormal();
if flip
    M.F = M.F([1 3 2],:);
end
% M.Aux.WKS = M.ComputeWKS([]);

M.Centralize('ScaleArea');
[~,TriArea] = M.ComputeSurfaceArea();
M.Aux.VertArea = M.F2V'*TriArea;

[WKS,E_mesh,PHI_mesh,L] = M.ComputeWKS([]); 

% compute LB on different scalar function on a mesh (smoothness of the
% function)

[PHI_gauss,E_gauss,K_gauss] = ComputeLBonFunction(L,Cgauss,n_eigenvalues);
[PHI_mean,E_mean,K_mean] = ComputeLBonFunction(L,Cmean,n_eigenvalues);
[PHI_theta,E_theta,K_theta] = ComputeLBonFunction(L,ThetaOri,n_eigenvalues);
[PHI_phi,E_phi,K_phi] = ComputeLBonFunction(L,PhiOri,n_eigenvalues);

% compute for landmark selection 
if size(M.E,1) > 2
    [I,J] = find(tril(M.E));
    M.E = ([I,J])';
end
EdgeIdxI = M.E(1,:);
EdgeIdxJ = M.E(2,:);
% bandwidth = mean(sqrt(sum((G.V(:,EdgeIdxI)-G.V(:,EdgeIdxJ)).^2)))/5; % default in paper
bandwidth = mean(sqrt(sum((M.V(:,EdgeIdxI)-M.V(:,EdgeIdxJ)).^2)))/2;

BNN = min(1000,M.nV); % default 500
% atria = nn_prepare(G.V');
% [idx, dist] = nn_search(G.V',atria,(1:G.nV)',BNN+1,-1,0.0);
% fullPhi = sparse(repmat(1:G.nV,1,BNN+1),idx,exp(-dist.^2/bandwidth),G.nV,G.nV);
[idx, dist] = knnsearch(M.V',M.V','K',BNN+1);
fullPhi = sparse(repmat(1:M.nV,1,BNN+1),idx,exp(-dist.^2/bandwidth),M.nV,M.nV);
fullPhi = (fullPhi+fullPhi')/2;

%% save the results

% approximated LB 
MAttr.K_gaussS = K_gauss;
MAttr.K_meanS = K_mean;
MAttr.K_thetaS = K_theta;
MAttr.K_phiS = K_phi;

MAttr.C_gauss = Cgauss;
MAttr.C_mean = Cmean;
MAttr.C_total = Ctotal;
MAttr.theta = ThetaOri;
MAttr.phi = PhiOri;

% eigenvalues
MAttr.E_gauss = E_gauss;
MAttr.E_mean = E_mean;
MAttr.E_theta = E_theta;
MAttr.E_phi = E_phi;

% eigenfucntions corresponding to the eigen values
MAttr.PHI_gauss = PHI_gauss;
MAttr.PHI_mean = PHI_mean;
MAttr.PHI_theta = PHI_theta;
MAttr.PHI_phi = PHI_phi;


MAttr.WKS = WKS;
MAttr.VoronoiVer = A;
MAttr.E_mesh = E_mesh;
MAttr.PHI_mesh = PHI_mesh; 
MAttr.fullPhi = fullPhi;

MAttr.K_gauss = L*Cgauss;
MAttr.K_mean = L*Cmean;
MAttr.K_theta = L*ThetaOri;
MAttr.K_phi = L*PhiOri;

MAttr.Normal = normalDvex;

end 