function [M,VertArea] = VertexAreaMesh(vertex1,faces1)

if size(vertex1,1)>3
    vertex1 = vertex1';
end
if size(faces1,1)>3
    faces1 = faces1';
end

M = Mesh('VF',vertex1, faces1);

M.Normalize();
[~,~,flip] = M.ComputeNormal();
if flip
    M.F = M.F([1 3 2],:);
end
% M.Aux.WKS = M.ComputeWKS([]);

M.Centralize('ScaleArea');
[~,TriArea] = M.ComputeSurfaceArea();
M.Aux.VertArea = M.F2V'*TriArea;
VertArea = M.Aux.VertArea;
end