function vertex2 = RigidTrans(vertex2,tform)
% Directly apply transformation on the vertices 

T = tform.A; % tform.A gives the 4x4 transformation matrix

% Apply the transformation using direct matrix multiplication
% Convert vertex2 to homogeneous coordinates
vertex2_hom = [vertex2, ones(size(vertex2, 1), 1)];

% Apply the transformation
vertexMovedDirect_hom = (T * vertex2_hom')';
vertex2 = vertexMovedDirect_hom(:, 1:3);

end