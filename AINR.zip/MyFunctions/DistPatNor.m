function dist = DistPatNor(P1,P2,para)

if nargin<3
    a = 0.2;
    b = 0.4;
    c = 0.4;
else
    a = para.PatchCompare_a;
    b = para.PatchCompare_b;
    c = para.PatchCompare_c;
end

CurveMap1 = P1.CurveMap;
CurveMap2 = P2.CurveMap;


WKS1 = P1.NorWKS;
WKS2 = P2.NorWKS;
dWKS = sqrt(mean((WKS1-WKS2).^2));
% WKS1 = P1.WKS(P1.Center,:);
% WKS2 = P2.WKS(P2.Center,:);
% dWKS = mean(abs(WKS1-WKS2)/abs(WKS1+WKS2));


AgMean1 = CurveMap1.NorAgMeanEx;
AgMean2 = CurveMap2.NorAgMeanEx;
dAgM = sqrt(mean((AgMean1-AgMean2).^2));
% AgMean1 = CurveMap1.AgMeanEx;
% AgMean2 = CurveMap2.AgMeanEx;
% dAgM = mean(abs(AgMean1-AgMean2)/abs(AgMean1+AgMean2));


AgGauss1 = CurveMap1.NorAgGaussEx;
AgGauss2 = CurveMap2.NorAgGaussEx;
dAgG = sqrt(mean((AgGauss1-AgGauss2).^2));
% AgGauss1 = CurveMap1.AgGaussEx;
% AgGauss2 = CurveMap2.AgGaussEx;
% dAgG = mean(abs(AgGauss1-AgGauss2)/abs(AgGauss1+AgGauss2));


dist = a*dWKS+b*dAgM+c*dAgG;
disp(['The geometric similarity (maximum absolute scaling) measurement is ',num2str(dist)]);

end