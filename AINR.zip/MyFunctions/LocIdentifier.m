function Dev_a = LocIdentifier(Dev,a22,in,tol)
% Dev: NxN, a22: NxN, in = 1(non-zero), 0(zero) region
% return Dev_a: NxN, Dev matrix where the a22 is
% nonzero
if nargin<4
    tol = 1e-4;
end
if in == 1
    [ax,ay] = find(abs(a22)>tol);
else
    [ax,ay] = find(abs(a22)<tol);
end

Dev_a = zeros(size(Dev));
for i = 1:length(ax)
    Dev_a(ax(i),ay(i)) = Dev(ax(i),ay(i));
end

end