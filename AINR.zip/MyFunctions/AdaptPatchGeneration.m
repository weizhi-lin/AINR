function [lmk_lab,Ind_patch,label_lmkv,Patch_Radius] = AdaptPatchGeneration(vertex1,faces1,lmk_all,path)

cd("Toolbox/toolbox_graph"); 
compile_mex

% find voronoi diagram 
m = max(size(lmk_all));
[Dist,~,Q] = perform_fast_marching_mesh(vertex1, faces1, lmk_all);
[~,~,label_lmkv] = unique(Q);
v = randperm(m)'; % without repeating elements
label_lmkv = v(label_lmkv);

Ind_patch = {};
lmk_lab = zeros(length(lmk_all),1);
Patch_Radius = zeros(length(lmk_all),1);
% find the average distance on each voronoi diagram 
% generate patches around landmark with radius being the average distance
for i=1:length(lmk_all)
    I = find(label_lmkv==i); %find index in the original file

    % the distance from the center to the boundary of the voroni cell
    D_v = Dist(I); 
    R_seg = quantile(D_v,0.9); % max(D_v); %mean(D_v); % average distance in the cell

    % find the center of the segment
    % [~,idx_test] = pdist2(vertex1(lmk_all,:), vertex1(I,:),'euclidean','Smallest',1);
    % lmk_lab(i) = mode(idx_test);
    % lmk_temp = zeros(length(lmk_all),1);
    lmk_temp = find(ismember(vertex1(I,:),vertex1(lmk_all,:), 'rows'));
    lmk_lab(i)= find(ismember(vertex1,vertex1(I(lmk_temp),:), 'rows'));

    [Dist_i,~,~] = perform_fast_marching_mesh(vertex1, faces1,lmk_lab(i));
    % [~,Dist_i] = GenerateVoronoiDiagram(vertex1,faces1,lmk_lab(i),para.currentFolder);
    Ind_patch{i} = find(Dist_i<R_seg);
    Patch_Radius(i) = R_seg;
end

if(~isdeployed)
  cd(path);
end

end