function [AdaptPatch_Ori,BC_seg,MeshSeg,MDesign] = SegmentWiseBCReg(MD,MS,para)
    n_eigenvalues = 300;
    tdStart = tic;
    
    % [vertex1,faces1] = MeshRead(Mesh_Design);
    % [vertex2,faces2] = MeshRead(Mesh_Scan);
    vertex1 = MD.vertex;
    faces1 = MD.faces;
    Cgauss1 = MD.Cgauss;
    Cmean1 = MD.Cmean;

    vertex2 = MS.vertex;
    faces2 = MS.faces;
    Cgauss2 = MS.Cgauss;
    Cmean2 = MS.Cmean;


    [~,~,Cmin,Cmax,~,~,~]= compute_curvature(vertex1,faces1);
    % [~,Cgauss1,Cmean1,~] = ComputeWeightFunction(vertex1,faces1);
    filter = abs(Cmin)+abs(Cmax); % absolute total curvature
    lenm = MaxLength(vertex1,faces1);
    BoundaryVer = compute_boundary(faces1);

    % [~,Cgauss2,Cmean2,~] = ComputeWeightFunction(vertex2,faces2);
    lenm2 = MaxLength(vertex2,faces2);

    
    MD.V = vertex1;
    MD.F = faces1;
    Nvertex = size(vertex1,1);

    figure()
    plot_mesh(vertex1,faces1); hold on 
    plot_mesh(vertex2,faces2);shading flat; colormap white
    
    remeshN = floor(Nvertex * 0.035); % 0.025; for other shapes
    % remeshN = min(remeshN,8000);

%% Step1: Feature sensitive remeshing

    tRemeshS = tic;
    [vertexV,facesV] = FeatureRemesh(vertex1,faces1,remeshN,filter,para.currentFolder);
    tRemesh = toc(tRemeshS);
    disp(['Time of remeshing is ',num2str(tRemesh/60),'min']) 
    
    [vertexV,facesV] = MeshEnsureManifold(vertexV,facesV);
    [vertexV,facesV]= MeshProcess(vertexV,facesV);
    
    MDRm.V = vertexV;
    MDRm.F = facesV;
    
    % figure()
    % plot_mesh(MDRm.V,MDRm.F);colormap jet(256); 
    % shading faceted


%% Step2: Geodesic distance computation
    tGeodesicS = tic;
    DS = GeodesicDistance(vertexV,facesV);
    tGeodesic = toc(tGeodesicS);
    
    disp(['Computation of Geodesic Distance is done, time:',num2str(tGeodesic)]);
    
    MDRm.GeoD = DS;

%% Step3: Clustering-based segmentation
    tFinddcS = tic;
    [rho,delta,dc,p] = FindBestDesicionValue(DS,0.01,0.02,100);
    tFinddc = toc(tFinddcS);

    [C_ind,N] = ClusterCenter(rho,delta);

    disp(['Number of segments is ',num2str(N)]);

    % assign vertex to each cluster 
    MDRm.Rho = rho;
    MDRm.Delta= delta;
    MDRm.Dc = dc;
    MDRm.P4dc = p; %best percentage

    % figure()
    % label = AssignCluster(C_ind, DS);
    % options.face_vertex_color = label;
    % plot_mesh(MDRm.V,MDRm.F,options); 
    % title('Segmentation on the Remeshed Mesh')
    % colormap turbo;


%% Step5: Segment projection and reconstruction 
    
    % position of cluster center on the original mesh
    vertexC = vertexV(C_ind,:);
    [~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);
    
    % delete the centers too close to the boundary 
    DistMatrix = GeodesicDistanceLmk(vertex1,faces1,[IC,BoundaryVer]);
    DistIC = DistMatrix(1:N,1:N);
    triDist = triu(DistIC, 1);
    DistIC_array = triDist(triDist~=0);
    
    cutdist = median([quantile(DistIC_array,0.05),min(DistIC_array),10]);
    cutdist = min([cutdist,4]);
    DistBD = DistMatrix(1:N,(N+1):end);
    
    % Create a logical matrix where elements are true if they are smaller than d
    thresholdMatrix = (DistBD < cutdist ) & (DistBD > 0);
    % Find the rows that contain at least one value smaller than the threshold
    rowsWithSmallerValues = any(thresholdMatrix, 2);
    % Get the indices of these rows
    rows = find(rowsWithSmallerValues);
    IC(rows) = [];
    disp(['After removing center too close to the boundaries, Number of segments is ',num2str(length(IC))]);
    
    % in case too few segments
    if length(IC)<3
        [~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);
    end

    % % 
    % % delete the centers too close to each others
    % N = length(IC);
    % cutd_ct = 5;
    % DistMatrix = GeodesicDistanceLmk(vertex1,faces1,IC);
    % DistIC = DistMatrix(1:N,1:N);
    % triDist = triu(DistIC, 1);
    % % Create a logical matrix where elements are true if they are smaller than d
    % thresholdMatrix = (triDist < cutd_ct) & (triDist > 0);
    % % Find the rows that contain at least one value smaller than the threshold
    % [row, col] = find(thresholdMatrix);
    % % Get the indices of these rows
    % IC(row) = [];
    % disp(['After removing center too close to each others, Number of segments is ',num2str(length(IC))]);
    % 
    % % in case too few segments
    % if length(IC)<3
    %     [~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);
    % end



%% project the clustering result to the orignal(designed) shape

    [label1,~] = GenerateVoronoiDiagram_Geo(vertex1,faces1,IC);
    N = length(IC);
    
    % correct the label order first 
    Label = zeros(length(vertex1),1);
    for ci = 1:N
        inx = label1(IC(ci));
        Label(label1 == inx) = ci;
    end
    
    % figure()
    % options.face_vertex_color = Label;
    % plot_mesh(vertex1,faces1,options); 
    % title('Segmentation on the Remeshed Mesh')
    % colormap turbo;shading flat;
    
    
    % modify the segment to have circular geodesic boundary 
    V_seg = {};
    F_seg = {};
    area = [];
    Label_seg = {};
    CindS = [];
    Label_Overlap = zeros(length(vertex1),1);
    d0_seg = [];
    
    for ic_circ = 1:N

        % % on the original mesh 
        options = [];
        [D2,~,~] = perform_fast_marching_mesh(vertex1, faces1, IC(ic_circ));
    
        indpre = find(Label==ic_circ);
        DistBdry = D2(indpre);

        % ensure the regions are fully covered 
        d0 = 1.01 * max(DistBdry); 
        Label0 = zeros(length(D2),1);
        Label0(D2<d0)=1;
    
        [V_seg{ic_circ},F_seg{ic_circ},area(ic_circ)] = SegReconstruction_sig(Label0,vertex1,'boundary',lenm);
    
            
        [~,Cseg]=ismember(vertex1(IC(ic_circ),:),V_seg{ic_circ},'rows');

            
        Label_seg{ic_circ} = Label0;
        CindS(ic_circ) = Cseg;
        d0_seg(ic_circ) = d0;
    
        Label_Overlap = Label_Overlap + Label0; 
    
    end

    figure()
    options.face_vertex_color = Label_Overlap;
    plot_mesh(vertex1,faces1,options); 
    title(['The number of uncovered vertices:',num2str(length(find(Label_Overlap==0)))]);
    colormap turbo;shading flat;
    
    MDSeg.V= V_seg;
    MDSeg.F= F_seg;
    MDSeg.Label_Ori = Label_seg;


%% Step 6: Segment-wise landmarking
    tlmkS = tic;
    lmk = SegGPlmk_Reg(V_seg, F_seg);
    
    Ind = {};
    for j = 1:N
        [~,index]=ismember(V_seg{j}(lmk{j},:),vertex1,'rows');
        Ind{j} = index;
    end

    lmk_all = cell2mat(Ind'); % landmarks on the whole shape
    tlmk = toc(tlmkS);
    
    MDSeg.Lmk = lmk;
    MDRm.Ct = C_ind;
    MDSeg.Ct = CindS;
    MD.Time_Remesh = tRemesh;
    MD.Time_Geo = tGeodesic;
    MD.Time_Finddc = tFinddc;
    MD.Time_Lmk = tlmk;
    MD.Ct = IC;
    MD.d0_seg = d0_seg;
    MD.Label = Label;
    MD.Lmk = lmk_all;
    MD.Label_seg = Label_seg;
    MD.Label_Overlap = Label_Overlap;
    
    figure()
    options.face_vertex_color = MD.Label;
    plot_mesh(MD.V,MD.F,options); hold on
    plot3(MD.V(MD.Lmk,1),MD.V(MD.Lmk,2),MD.V(MD.Lmk,3),'.r','MarkerSize',35);
    % title([filenames{td},' #segment:',num2str(length(MD.Ct)),' #lmk:',num2str(length(MD.Lmk))]);
    colormap jet;shading flat;
    
    MDesign.MD = MD;
    MDesign.MDSeg = MDSeg;
    MDesign.MDRm = MDRm;

% save(fullfile(para.currentFolder,['Results/ICSeg_',filenames{td},'.mat']), ...
%     'MD','MDSeg','MDRm','-v7.3');


%% Segment-wise registraction 
    idx_ctd = MD.Ct;
    DV_seg  = MDSeg.V;
    DF_seg  = MDSeg.F;

    %% find the corresponding segment centers
    % [~,idx_ct] = pdist2(vertex2,vertex1(MD.Ct,:),'euclidean','Smallest',1);
    idx_ct = FindCorrespondingPtRigid(vertex1,vertex2,idx_ctd);

    % figure()
    % subplot(1,2,1)
    % plot_mesh(vertex1,faces1); hold on
    % plot3(vertex1(idx_ctd,1),vertex1(idx_ctd,2),vertex1(idx_ctd,3),'.r','markersize',10);
    % shading flat;
    % subplot(1,2,2)
    % plot_mesh(vertex2,faces2); hold on
    % plot3(vertex2(idx_ct,1),vertex2(idx_ct,2),vertex2(idx_ct,3),'.r','markersize',10);
    % shading flat;


    SV_seg = {};
    SF_seg = {};
    area = [];
    Label_seg = {};
    CindS = [];
    Label_Overlap = zeros(length(vertex2),1);

    for ic_circ = 1:length(MD.Ct)

        [D2,~,~] = perform_fast_marching_mesh(vertex2, faces2, idx_ct(ic_circ));

        d0 = MD.d0_seg(ic_circ);
        Label0 = zeros(length(vertex2),1);
        Label0(D2<d0)=1;
        
        [SV_seg{ic_circ},SF_seg{ic_circ},areaS(ic_circ)] = SegReconstruction_sig(Label0, ...
            vertex2,'boundary',lenm2);

        % Cindex = find(ismember(vertex2(idx_ct(ic_circ),:),SV_seg{ic_circ},'rows'));
        [~,Cseg]=ismember(vertex2(idx_ct(ic_circ),:),SV_seg{ic_circ},'rows');

        % figure()
        % subplot(1,2,1)
        % plot_mesh(V_seg{ic_circ},F_seg{ic_circ});hold on
        % plot3(V_seg{ic_circ}(MDSeg.Ct(ic_circ),1),V_seg{ic_circ}(MDSeg.Ct(ic_circ),2), ...
        %     V_seg{ic_circ}(MDSeg.Ct(ic_circ),3),'.r','MarkerSize',10);      
        % shading flat;
        % colormap white;
        % subplot(1,2,2)
        % plot_mesh(SV_seg{ic_circ},SF_seg{ic_circ});hold on
        % plot3(SV_seg{ic_circ}(Cseg,1),SV_seg{ic_circ}(Cseg,2),SV_seg{ic_circ}(Cseg,3),'.r','MarkerSize',10);
        % shading flat;
        % colormap white;
        
        Label_seg{ic_circ} = Label0;
        CindS(ic_circ) = Cseg;

        Label_Overlap = Label_Overlap + Label0; 

    end

% figure()
% options.face_vertex_color = Label_Overlap;
% plot_mesh(vertex2,faces2,options); 
% title('Segmentation on the Remeshed Mesh')
% colormap turbo;shading flat;

 
    % compute normal direction on the whole shape 
    % attention: need to use the mesh corresponding to the center!!
    [normalD, ~] = meshVertexNormals(vertex1,faces1); 
    [normalS, ~] = meshVertexNormals(vertex2,faces2);

%% Step 2: segment-wise registration 

    tsegRegs = tic;
    BCshape = {};
    BC_seg = {};
    MeshSeg = {};
    AdaptPatch_Ori = {};
    % Process scan shapes:
    for ci = 1:length(MD.Ct)
        % ensure the orientation of segments are aligned with the whole shape
        normO_D = normalD(MD.Ct(ci),:);
        % find the center index in the segment shape on design
        [~,D_segct] = pdist2(DV_seg{ci},vertex1(idx_ctd(ci),:),'euclidean','Smallest',1);
        D_seg = PatchFinalize(DV_seg{ci},DF_seg{ci},D_segct,normO_D);
        [~,lmk_Design] = pdist2(DV_seg{ci},DV_seg{ci}(MDSeg.Lmk{ci},:),'euclidean','Smallest',1);


        normO_S = normalS(idx_ct(ci),:);
        % find the center index in the segment shape on scanned
        [~,S_segct] = pdist2(SV_seg{ci},vertex2(idx_ct(ci),:),'euclidean','Smallest',1);
        S_seg = PatchFinalize(SV_seg{ci},SF_seg{ci},S_segct,normO_S);
    
        % process mesh for registration 
        [BC_seg.DV{ci},BC_seg.DF{ci}] = MeshEnsureManifold(D_seg.V,D_seg.F);
        [BC_seg.SV{ci},BC_seg.SF{ci}] = MeshEnsureManifold(S_seg.V,S_seg.F);
    
        BC_seg.DCt{ci} = D_segct;
        BC_seg.SCt{ci} = S_segct;

        [~,idx_test] = pdist2(vertex1,BC_seg.DV{ci},'euclidean','Smallest',1);
        [~,idx_tests] = pdist2(vertex2,BC_seg.SV{ci},'euclidean','Smallest',1);
        
        H1 = Cmean1(idx_test);
        H2 = Cmean2(idx_tests);

        K1 = Cgauss1(idx_test);
        K2 = Cgauss2(idx_tests);
    
        %% with landmarks 
        % find corresponding landmarks
        vertexFixed = pointCloud(DV_seg{ci});
        vertexMoved = pointCloud(SV_seg{ci});

        % point descriptor of landmarks on design
        Descriptor = ComputeGeometricDescriptor(DV_seg{ci},DF_seg{ci},lmk_Design);

        % find the landmark on the scan shape
        [tform,movingReg,rmse_oringal] = pcregistericp(vertexMoved,vertexFixed);%,'MaxIterations',10);
        % initial locations of the corresponding landmarks on the scan
        [~,lmkTran] = pdist2(movingReg.Location,DV_seg{ci}(lmk_Design,:),'euclidean','Smallest',1);
        
        try

        [M,MAttr] = MeshPrepareSim(SV_seg{ci},SF_seg{ci},n_eigenvalues); %Cgauss,Cmean,
            
        a = 0.2;
        b = 0.4;
        c = 0.4;

        lmkTranNew = [];
        for kk = 1:length(lmkTran)
            lmk = lmkTran(kk);
            [Label_0,~,~] = RegionGrowPatch(SV_seg{ci},SF_seg{ci},lmk, MAttr,para);
            PointsPatch = find(Label_0);
            Descriptor_Scan = ComputeGeometricDescriptor_Pt(SV_seg{ci},SF_seg{ci},MAttr,PointsPatch);
            DiffDist = [];
            for kki = 1:length(PointsPatch)
                DiffWKS = Descriptor{kk}.WKS - Descriptor_Scan{kki}.WKS;
                DiffMean = Descriptor{kk}.CurveMap.NorMaxMean - Descriptor_Scan{kki}.CurveMap.NorMaxMean;
                DiffGauss = Descriptor{kk}.CurveMap.NorMaxGauss - Descriptor_Scan{kki}.CurveMap.NorMaxGauss;
                dWKS = sqrt(mean(DiffWKS.^2));
                dAgM = sqrt(mean(DiffMean.^2));
                dAgG = sqrt(mean(DiffGauss.^2));
                DiffDist(kki) = a*dWKS+b*dAgM+c*dAgG;
            end
            lmkTranNew(kk) = PointsPatch(find(min(DiffDist)));
        end

        catch
            warning('Fail to compute landmarks with corresponding landmarks')
            lmkTranNew = lmkTran;
        end

        % figure()
        % subplot(1,3,1)
        % plot_mesh(DV_seg{ci},DF_seg{ci});hold on
        % plot3(DV_seg{ci}(lmk_Design,1),DV_seg{ci}(lmk_Design,2),DV_seg{ci}(lmk_Design,3),'.r','MarkerSize',35);
        % shading flat;colormap white
        % subplot(1,3,2)
        % plot_mesh(SV_seg{ci},SF_seg{ci});hold on
        % plot3(SV_seg{ci}(lmkTran,1),SV_seg{ci}(lmkTran,2),SV_seg{ci}(lmkTran,3),'.r','MarkerSize',35);
        % shading flat;colormap white
        % title('Rigid Correspondence');
        % subplot(1,3,3)
        % plot_mesh(SV_seg{ci},SF_seg{ci});hold on
        % plot3(SV_seg{ci}(lmkTranNew,1),SV_seg{ci}(lmkTranNew,2),SV_seg{ci}(lmkTranNew,3),'.r','MarkerSize',35);
        % shading flat;colormap white
        % title('Feature Correspondence');

        BC_seg.DLmk{ci} = lmk_Design;
        BC_seg.SLmk{ci} = lmkTranNew;
        BC_seg.SLmkEd{ci} = lmkTran;
            
        lmk = BC_seg.DLmk{ci};
        lmkTran = BC_seg.SLmk{ci};

        BCresult = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTran,H1,H2,K1,K2);
        BCresult_Ft = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTranNew,H1,H2,K1,K2);

        % without landmarks
        lmk = [];
        lmkTran = [];

        BCresult_WtLmk = PairBCdiff_seg(BC_seg.DV{ci},BC_seg.DF{ci},BC_seg.SV{ci},BC_seg.SF{ci},lmk,lmkTran,H1,H2,K1,K2);

        %% save results 
        BC_seg.BCresult{ci} = BCresult;
        BC_seg.BCresult_Ft{ci} = BCresult_Ft;
        BC_seg.BCresult_WtLmk{ci} = BCresult_WtLmk;

        MeshSeg{ci}.DV = DV_seg{ci};
        MeshSeg{ci}.DF = DF_seg{ci};
        MeshSeg{ci}.SV = SV_seg{ci};
        MeshSeg{ci}.SF = SF_seg{ci};
        MeshSeg{ci}.DCt = D_segct;
        MeshSeg{ci}.SCt = S_segct;

    end 

    tsegReg = toc(tsegRegs);
    % figure()
    % % lmk1 = BC_seg.BCresult{ci}.lmk_Design;
    % V1 = BC_seg.BCresult{ci}.DV;
    % F1 = BC_seg.BCresult{ci}.DF;
    % options.face_vertex_color = BC_seg.BCresult{ci}.Hdiff;
    % plot_mesh(V1,F1,options); hold on
    % % plot3(V1(lmk1,1),V1(lmk1,2),V1(lmk1,3),'.r',MarkerSize=20);
    % colormap jet
    % shading flat
    % 
    % figure()
    % subplot(1,2,1)
    % plot_mesh(BC_seg.BCresult{ci}.rect_Design,BC_seg.DF{ci});
    % subplot(1,2,2)
    % plot_mesh(BC_seg.BCresult{ci}.rect_Scan,BC_seg.SF{ci});

    % figure()
    % subplot(1,2,1)
    % V1 = BC_seg.BCresult{ci}.DV;
    % F1 = BC_seg.BCresult{ci}.DF;
    % lmkb1 = BC_seg.BCresult{ci}.lmkb_Design;
    % lmkb2 = BC_seg.BCresult{ci}.lmkb_Scan;
    % plot_mesh(V1,F1);hold on
    % plot3(V1(lmkb1,1),V1(lmkb1,2),V1(lmkb1,3),'.r');
    % subplot(1,2,2)
    % plot_mesh(BC_seg.SV{ci},BC_seg.SF{ci}); hold on
    % plot3(BC_seg.SV{ci}(lmkb2,1),BC_seg.SV{ci}(lmkb2,2),BC_seg.SV{ci}(lmkb2,3),'.r');
    % colormap jet
    
    %% Average the calculated deviation values at the overlapped region 
    % for each point, found all the calculated deviation values at this
    % point 

    [Hdiff,tmap_BCv,Hscan] = ComputeHdiffAvg(vertex1, BC_seg,'Original');
    [Hdiff_Ft,tmap_BCv_Ft,Hscan_Ft] = ComputeHdiffAvg(vertex1, BC_seg,'Ft');
    [Hdiff_WtLmk,tmap_BCv_WtLmk,Hscan_WtLmk] = ComputeHdiffAvg(vertex1, BC_seg,'WtLmk');

    AdaptPatch_Ori.V = vertex1;
    AdaptPatch_Ori.F = faces1;
    AdaptPatch_Ori.Hdiff = Hdiff;
    AdaptPatch_Ori.tmapBCv = tmap_BCv;
    AdaptPatch_Ori.Hscan = Hscan;
        
    AdaptPatch_Ori.Hdiff_Ft = Hdiff_Ft;
    AdaptPatch_Ori.tmapBCv_Ft = tmap_BCv_Ft;
    AdaptPatch_Ori.Hscan_Ft = Hscan_Ft;

    AdaptPatch_Ori.Hdiff_WtLmk = Hdiff_WtLmk;
    AdaptPatch_Ori.tmapBCv_WtLmk = tmap_BCv_WtLmk;
    AdaptPatch_Ori.Hscan_WtLmk = Hscan_WtLmk;

    
    % figure()
    % subplot(1,3,1)
    % options.face_vertex_color = Hdiff;% perform_saturation(Hdiff,1.5);
    % plot_mesh(vertex1,faces1,options);
    % colormap(J)
    % shading flat
    % colorbar
    % clim([quantile(Hdiff,0.05),quantile(Hdiff,0.95)]);
    % title('Rigid Correspondence');
    % subplot(1,3,2)
    % options.face_vertex_color = Hdiff_Ft; %perform_saturation(Hdiff_Ft,1.5);
    % plot_mesh(vertex1,faces1,options);
    % colormap(J)
    % shading flat
    % colorbar
    % clim([quantile(Hdiff_Ft,0.05),quantile(Hdiff_Ft,0.95)]);
    % title('Feature Correspondence');
    % subplot(1,3,3)
    % options.face_vertex_color = Hdiff_WtLmk; %perform_saturation(Hdiff_WtLmk,1.5);
    % plot_mesh(vertex1,faces1,options);
    % colormap(J)
    % clim([quantile(Hdiff_WtLmk,0.05),quantile(Hdiff_WtLmk,0.95)]);
    % shading flat
    % colorbar

    TimeAll = toc(tdStart);
    AdaptPatch_Ori.Time = TimeAll;
    AdaptPatch_Ori.TimeReg = tsegReg;

end

    % save(fullfile(para.currentFolder,['Results/Registration_',filenames{td},'.mat']), ...
    %     'AdaptPatch_Ori','BC_seg','MeshSeg');
