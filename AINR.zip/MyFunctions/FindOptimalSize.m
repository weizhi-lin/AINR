function [limitU,Label] = FindOptimalSize(vertex1,faces1,lmk,ThetaOri,areas,para)
% areas = meshFaceAreas(vertex1,faces1);

if nargin < 6
    timeStep = 2;
    step = 0.00015; %0.0002
    ini = 0.005;
    N = 90;
    [~,~,Cmean,~] = ComputeWeightFunction(AdaptPatch_Ori.V,AdaptPatch_Ori.F);

    % epsilon = 0.1;
else
    timeStep = para.timeStep;
    step = para.step;
    ini = para.ini;
    Cmean = para.Cmean;
    N = para.N;
    % epsilon = para.epsilon;
end

The = [];
CurvStd = [];
CurvCount = [];
CurvMeanArray = [];
Curv = {};

parfor l = 1:N
    limitU = ini+l*step;
    [Label,~] = HeatPatch(vertex1,faces1,lmk,timeStep,limitU);

    % verInd = find(Label);
    % % indxFace = meshFindFaceIndex(faces1,verInd);
    % % PatchArea = sum(areas(indxFace));

    index = find(Label);
    theta = ThetaOri(index);
    curvMean = Cmean(index);
    PatchArea = areas(index);

    % indexd = find(Label~=Label0);
    % curvMeand = Cmean(indexd);

    % averagetheta = sum(PatchArea.*(theta/sum(theta)));

    stdtheta = std(PatchArea.*(theta));
    stdcurv = std(PatchArea.*(curvMean));
    % elementtheta = PatchArea.*(theta/sum(theta));
    % averagetheta = sum(elementtheta);

    % RangeAve = max(averagetheta) - min(averagetheta);
    % 
    The(l) = stdtheta;
    CurvStd(l) = stdcurv;
    Curv{l} = curvMean;
    CurvCount(l) = length(find(curvMean.*Cmean(lmk)<0))/length(index);
    CurvMeanArray(l) = mean(curvMean);


    % Label0 = Label;
    % % AThe(l) = RangeAve;%range(theta);
    % if l>1
    %     diffAverT = abs(averagetheta - averLastStep);
    % 
    %     if diffAverT < epsilon 
    %         break;
    %     end
    % end 
    % averLastStep =  averagetheta;
    % rangeLastStep = RangeAve;

end
% 

% adjust for smoother peak: the var strictly decrease and lead to small
% patch
DiffThe = diff(The);
DiffCurvStd = diff(CurvStd);
ki = 1;
kc = 1;
L = [];
Lc = [];
for i = 6:length(DiffThe)
    I(1) = DiffThe(i-5);
    Ic(1) = DiffCurvStd(i-5);
    I(2) = DiffThe(i-4);
    Ic(2) = DiffCurvStd(i-4);
    I(3) = DiffThe(i-3);
    Ic(3) = DiffCurvStd(i-3);
    I(4) = DiffThe(i-2);
    Ic(4) = DiffCurvStd(i-2);
    I(5) = DiffThe(i-1);
    Ic(5) = DiffCurvStd(i-1);
    if ~isempty(find(I>0))
        continue
    else 
        L(ki)=i;
        ki = ki+1;
    end

    if ~isempty(find(Ic>0))
        continue
    else 
        Lc(kc) = i;
        kc = kc+1;
    end
end

minD = min(L);
minC = min(Lc);

if ~isempty(L) && CurvMeanArray(minD)>0 && Cmean(lmk)>0% apply for positive mean curvature 
    l = minD +1;
else
    Index = find(DiffThe<0);
    [value,~] = min(The(Index+1));
    l = find(The==value);
    l = l(1);
end

if ~isempty(Lc) && Cmean(lmk)<0 
    [~,lcurv] = min(CurvStd);
    lcurv = max(lcurv,min(Lc)+1);
else
    Index = find(DiffCurvStd<0);
    [value,~] = min(CurvStd(Index+1));
    lcurv = find(CurvStd==value);
    lcurv = lcurv(1);
end

lfinal = max(lcurv,l);
% % 
% figure()
% % plot(The);hold on 
% plot(CurvStd);hold on 
% xline(l);


limitU = ini+lfinal*step;
[Label,~] = HeatPatch(vertex1,faces1,lmk,timeStep,limitU);
