function label = AssignCluster(C_ind, DS)
Dc = DS(:,C_ind);
[~, minIndices] = min(Dc,[],2);
label = minIndices;
end