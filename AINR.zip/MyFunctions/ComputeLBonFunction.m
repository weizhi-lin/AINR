function [PHI,E,K] = ComputeLBonFunction(L,C,n_eigenvalues)

C  = C/sum(C);
CM = sparse(1:length(C), 1:length(C), C); % weight on nodes
% solve generalized eigenvalue problem
options.disp = 0;
[PHI,E] = eigs(L,CM,n_eigenvalues,-1e-5,options);
E = diag(E);
E=abs(real(E));
[E,idx] = sort(E);
PHI = PHI(:,idx);
PHI=real(PHI);
K = PHI*E; 
end

% Cgauss  = Cgauss/sum(Cgauss);
% CgaussM = sparse(1:length(Cgauss), 1:length(Cgauss), Cgauss);
% % solve generalized eigenvalue problem
% options.disp = 0;
% [PHI,E] = eigs(L,CgaussM,n_eigenvalues,-1e-5,options);
% E = diag(E);
% E=abs(real(E));
% [E,idx] = sort(E);
% PHI = PHI(:,idx);
% PHI=real(PHI);