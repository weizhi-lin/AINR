function DBC = DaviesBouldinSeg(AdaptPatch)
%% Davies-Bouldin Criterion
K = length(AdaptPatch);
MD = zeros(K,1);
D = zeros(K,1);

for i = 1:length(AdaptPatch)
    % % unit deviation of each vertex 
    % ind = find(ismember(vertex1,AdaptPatch{i}.V,'row'));
    % patHdiff = (AdaptPatch{i}.Hdiff).*VertArea(ind);
    % patcharea = meshSurfaceArea(AdaptPatch{i}.V, AdaptPatch{i}.F);

    MD(i) = mean(AdaptPatch{i}.Hdiff);
    %average distance between each point in the ith cluster and the centroid of the ith cluster. 
    D(i) = mean(pdist2(AdaptPatch{i}.Hdiff,MD(i))); 
end
Dpair = pdist(MD); % pair-wise distance among patch centroid
Dpairmatrix = squareform(Dpair);


Dij = zeros(K,K);
for i = 1:length(AdaptPatch)
    for j = (i+1):length(AdaptPatch)
        Dij(i,j) = (D(i)+D(j))/Dpairmatrix(i,j);
    end
end

Dcompare = Dij + Dij';
DBC = sum(max(Dcompare))/length(AdaptPatch);
end