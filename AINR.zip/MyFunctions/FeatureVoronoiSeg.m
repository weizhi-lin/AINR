function [J,D,landmarks]  = FeatureVoronoiSeg(vertex,faces,Nlmk,Attri,ctmax)
% Clustering the vertices and form voronoi segments based on geometric
% attributes 
% Nov. 24, 2023 Weizhi Lin

% currentFolder = para.currentFolder;
% inpute vertex should be 3*N
if size(vertex,2)<size(vertex,1)
    vertex = vertex';
end
if size(faces,2)<size(faces,1)
    faces = faces';
end

% options.verb = 0;
% % [~,~,~,~,~,Cgauss,~] = compute_curvature(vertex,faces,options);
% [Lambda,Cgauss,Cmean,Ctotal] = ComputeWeightFunction(vertex',faces');

m = Nlmk;
% W = rescale(filter, .001, 1);
W = rescale(min(Attri,ctmax), .001, 1);
options.W = W;
ini_n = find(Attri == max(Attri(:))); 
landmarks = ini_n;

% compile_mex

[D,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks);


for i=2:m
    % select
    [~,landmarks(end+1)] = max(D);
    % update
    options.constraint_map = D;
    [D1,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks,options);
    D = min(D,D1);
end


[D,Z,Q] = perform_fast_marching_mesh(vertex, faces, landmarks);
[B,I,J] = unique(Q);
v = randperm(m)'; % without repeating elements
J = v(J);

% if(~isdeployed)
%   cd(path);
% end

end