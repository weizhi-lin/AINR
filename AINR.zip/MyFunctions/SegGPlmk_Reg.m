function [lmk,lmkC] = SegGPlmk_Reg(V_seg, F_seg)

% assign landmarks number according to the 'Assign' feature

N = size(V_seg,2);
cutdist = 3;
area = [];
Cgauss_iqr = [];
Cmean_iqr = [];
Cgauss = {};
Cmean = {};

for i = 1:N
%     [V_seg{i},F_seg{i}] = MeshEnsureManifold(V_seg{i}',F_seg{i}');
    M{i} = Mesh('VF',V_seg{i}',F_seg{i}');
    area(i) = meshSurfaceArea(M{i}.V',M{i}.F');
    [Cgauss{i},Cmean{i}] = M{i}.ComputeCurvature();

    Cgauss_iqr(i) = iqr(Cgauss{i}/max(Cgauss{i}));
    Cmean_iqr(i) = iqr(Cmean{i}/max(Cmean{i}));

    M{i}.Normalize();
    [~,~,flip] = M{i}.ComputeNormal();
    if flip
        M{i}.F = M{i}.F([1 3 2],:);
    end
    M{i}.Aux.WKS = M{i}.ComputeWKS([]);
end  

Asum = sum(area); % total area of the mesh
% ratio = area./Asum;
% Ns = ceil(ratio.*Nlmk); % round up to integer

Ns = floor(0.03*area);
% Ns(Ns<ceil(Nlmk/N))=ceil(Nlmk/N);
for i = 1:N
    if Cmean_iqr(i)<0.1 && Cgauss_iqr(i)<0.01
        Ns(i) = 1;
    else
        % Ns(i) = floor(median([floor(0.035*area(i)),2,3,floor(0.045*area(i))]));
        % Ns(i) = max(Ns(i),3);
        % Ns(i) = min(Ns(i),3);
                
        Ns(i) = floor(median([floor(0.035*area(i)),5,3,floor(0.045*area(i))]));
        if Ns(i) > 6
            Ns(i) = 6;
        end
        if Ns(i) < 3
            Ns(i) = 3;
        end
    end
end
        
% determined by threshold from portion
for i = 1:N
    
    [GPLmkIdx,lmkcor] = GetGPLmk_Reg(M{i},Ns(i));
    % lmk{i}= GPLmkIdx;
    % lmkC{i} = lmkcor;

    try

    % for segment i, remove landmarks too close to the boundary
    BoundaryVer = compute_boundary(F_seg{i});
    DistMatrix = GeodesicDistanceLmk(V_seg{i},F_seg{i},[GPLmkIdx,BoundaryVer]);

    % Create a logical matrix where elements are true if they are smaller than d
    LN = Ns(i);
    DistBD = DistMatrix(1:LN,(LN+1):end);
    thresholdMatrix = (DistBD < cutdist ) & (DistBD > 0);
    % Find the rows that contain at least one value smaller than the threshold
    rowsWithSmallerValues = any(thresholdMatrix, 2);
    % Get the indices of these rows
    rows = find(rowsWithSmallerValues);
    GPLmkIdx(rows) = [];
    lmkcor(rows,:) = [];

    DistMatrix = GeodesicDistanceLmk(V_seg{i},F_seg{i},GPLmkIdx);
    DistIC = DistMatrix(1:length(GPLmkIdx),1:length(GPLmkIdx));
    triDist = triu(DistIC, 1);
    thresholdMatrix = (triDist < cutdist+0.5) & (triDist > 0);
    [row, ~] = find(thresholdMatrix);
    % Get the indices of these rows
    GPLmkIdx(row) = [];
    lmkcor(row,:) = [];
    catch
        warning('Error reducing the number of landmarks');
    end


    lmk{i}= GPLmkIdx;
    lmkC{i} = lmkcor;

end

end