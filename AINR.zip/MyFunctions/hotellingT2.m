function [T2, p] = hotellingT2(X1, X2)
    % X1 and X2 are matrices where rows are observations and columns are variables
    
    % Calculate means
    mean1 = mean(X1);
    mean2 = mean(X2);

    % Calculate pooled covariance matrix
    n1 = size(X1, 1);
    n2 = size(X2, 1);
    S1 = cov(X1);
    S2 = cov(X2);
    Sp = ((n1-1)*S1 + (n2-1)*S2) / (n1 + n2 - 2);

    % Calculate Hotelling's T2 statistic
    diff_mean = mean1 - mean2;
    T2 = (n1*n2)/(n1+n2) * diff_mean * inv(Sp) * diff_mean';

    % Calculate F-statistic
    p = (n1+n2-2) - size(X1, 2) + 1;
    q = (n1+n2-2) * size(X1, 2);
    F = T2 * (p*q) / ((n1+n2-2)*size(X1, 2));

    % Calculate p-value
    p = 1 - fcdf(F, size(X1, 2), p*q/size(X1, 2));
end
