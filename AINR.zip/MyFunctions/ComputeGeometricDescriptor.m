function Descriptor = ComputeGeometricDescriptor(V,F,Lmk,dscale,N,n_eigenvalues)
%% prepare for finding the point-to-point corrspondence


if nargin<4
    N=15; % expansion steps
    dscale = 1;
    n_eigenvalues = 100;
end

[M,MAttr] = MeshPrepareSim(V,F,n_eigenvalues);
    
C_mean= MAttr.C_mean;
C_gauss= MAttr.C_gauss;

K_mean = MAttr.K_mean;
K_gauss = MAttr.K_gauss;

vertex1 = V;
faces1 = F;

Descriptor = {};

for lmki = 1:length(Lmk)
    lmk = Lmk(lmki);
% weight the difussion distance based on smoothness of gaussian curvature 
options = [];
% W = rescale(-abs(C_mean),0.01,1); %rescale(K_gauss(indxkeep));
% options.W = W;
options.nb_iter_max = Inf;

[D,~,~] = perform_fast_marching_mesh(vertex1,faces1,lmk,options);

% figure()
% options.face_vertex_color = mod(D,1);%mod( 20*D/max(D),1 );
% plot_mesh(vertex1,faces1, options); hold on 
% colormap jet(256);
% plot3(vertex1(lmk,1),vertex1(lmk,2),vertex1(lmk,3),'.b','MarkerSize',10); shading flat

SD = sort(D);
% dstep = quantile(diff(SD),[0.9],[1]);
dstep = dscale * (max(D)/N);
d0 = SD(2); % smallest distance from the center 

MeanStep = zeros(N,7);
% gradually expend the patch and exam the statistics of the added region 
for i = 1:N
    d_i0 = d0+(i-1)*dstep; % this is for parfor
    d_i = d0+i*dstep;

    indx = find(D<=d_i & D>d_i0); % indices of the added vertices
    % indx0 = find(D<=d_i0); %indices of the current patch

    if isempty(indx)
        break;
    end

    MeanStep(i,1) = d_i;
    % MeanStep(i,2) = quantile(C_mean(indx),0.9)-quantile(C_mean(indx),0.1);%median(C_mean(indx));
    % MeanStep(i,3) = quantile(C_gauss(indx),0.9)-quantile(C_gauss(indx),0.1);
    MeanStep(i,2) = mean(C_mean(indx));
    MeanStep(i,3) = mean(C_gauss(indx));

    Cmean_add = C_mean(indx);
    [~,ind_6] = max(abs(Cmean_add));
    MeanStep(i,4) = Cmean_add(ind_6);
    Cgauss_add = C_gauss(indx);
    [~,ind_7] = max(abs(Cgauss_add));
    MeanStep(i,5) =Cgauss_add(ind_7);

    MeanStep(i,6) = mean(K_mean(indx));
    MeanStep(i,7) = mean(K_gauss(indx));

end 

CurveMap.AgMean = MeanStep(:,2);
CurveMap.AgGauss = MeanStep(:,3);
CurveMap.MaxMean = MeanStep(:,4);
CurveMap.MaxGauss = MeanStep(:,5);
CurveMap.AgKMean = MeanStep(:,6);
CurveMap.AgKGauss = MeanStep(:,7);

x = 1:N; 
xq = linspace(1,N,100); %1:0.14:15;
CurveMap.AgMeanEx = interp1(x,CurveMap.AgMean,xq,'spline'); %''spline'
CurveMap.AgGaussEx = interp1(x,CurveMap.AgGauss,xq,'spline');
CurveMap.AgKMeanEx = interp1(x,CurveMap.AgKMean,xq,'spline');
CurveMap.AgKGaussEx = interp1(x,CurveMap.AgKGauss,xq,'spline');


%% maximun absolute scaling 
CurveMap.NorAgMean = MeanStep(:,2)/max(abs(MeanStep(:,2)));
CurveMap.NorAgGauss = MeanStep(:,3)/max(abs(MeanStep(:,3)));
CurveMap.NorMaxMean = MeanStep(:,4)/max(abs(MeanStep(:,4)));
CurveMap.NorMaxGauss = MeanStep(:,5)/max(abs(MeanStep(:,5)));
CurveMap.NorAgKMean = MeanStep(:,6)/max(abs(MeanStep(:,6)));
CurveMap.NorAgKGauss = MeanStep(:,7)/max(abs(MeanStep(:,7)));


x = 1:N; 
xq = linspace(1,N,100); %1:0.14:15;
% v = AdaptPatchALL{i}.CurveMap.NorAgMean;
CurveMap.NorAgMeanEx = interp1(x,CurveMap.NorAgMean,xq,'spline'); %''spline'
CurveMap.NorAgGaussEx = interp1(x,CurveMap.NorAgGauss,xq,'spline');
CurveMap.NorAgKMeanEx = interp1(x,CurveMap.NorAgKMean,xq,'spline');
CurveMap.NorAgKGaussEx = interp1(x,CurveMap.NorAgKGauss,xq,'spline');

Descriptor{lmki}.Lmk_i = lmk;
Descriptor{lmki}.CurveMap = CurveMap;
Descriptor{lmki}.WKS = MAttr.WKS(lmk,:);

end