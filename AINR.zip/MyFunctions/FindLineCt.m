function Ct = FindLineCt(A,B)
degree = 60;
AB = B-A;
theta = deg2rad(degree);
R = [cos(theta) -sin(theta); sin(theta) cos(theta)];
Ct = A + AB*R';


% X = [A;B;C; A];
% plot(X(:, 1), X(:, 2));
% axis equal