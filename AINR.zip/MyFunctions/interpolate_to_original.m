function [deviation_original] = interpolate_to_original(vertex_original, vertex_remeshed, faces_remeshed, deviation_remeshed)
    % vertex_original: Nx3 vertices of original mesh
    % vertex_remeshed: Mx3 vertices of remeshed mesh
    % faces_remeshed: Px3 faces of remeshed mesh
    % deviation_remeshed: Mx1 deviation values on remeshed mesh
    % Output: deviation_original: Nx1 interpolated deviation values
    
    % Ensure correct dimensions
    if size(vertex_original, 2) ~= 3
        vertex_original = vertex_original';
    end
    if size(vertex_remeshed, 2) ~= 3
        vertex_remeshed = vertex_remeshed';
    end
    
    N = size(vertex_original, 1);
    deviation_original = zeros(N, 1);
    
    % For each vertex in original mesh
    for i = 1:N
        v = vertex_original(i, :);
        
        % Find the closest triangle in remeshed mesh
        [closest_triangle, bary_coords] = find_closest_triangle(v, vertex_remeshed, faces_remeshed);
        
        % Get deviation values of the triangle vertices
        d1 = deviation_remeshed(faces_remeshed(closest_triangle, 1));
        d2 = deviation_remeshed(faces_remeshed(closest_triangle, 2));
        d3 = deviation_remeshed(faces_remeshed(closest_triangle, 3));
        
        % Interpolate deviation using barycentric coordinates
        deviation_original(i) = bary_coords(1)*d1 + bary_coords(2)*d2 + bary_coords(3)*d3;
    end
end

function [triangle_idx, bary_coords] = find_closest_triangle(v, vertices, faces)
    % Find the closest triangle to point v using barycentric coordinates
    % v: 1x3 point coordinates
    % vertices: Nx3 vertex coordinates
    % faces: Mx3 face indices
    % Returns: triangle index and barycentric coordinates
    
    num_triangles = size(faces, 1);
    min_dist = inf;
    triangle_idx = 1;
    bary_coords = [0, 0, 0];
    
    for i = 1:num_triangles
        % Get triangle vertices
        v1 = vertices(faces(i, 1), :);
        v2 = vertices(faces(i, 2), :);
        v3 = vertices(faces(i, 3), :);
        
        % Compute barycentric coordinates and distance
        [bary, dist] = point_to_triangle_barycentric(v, v1, v2, v3);
        
        if dist < min_dist
            min_dist = dist;
            triangle_idx = i;
            bary_coords = bary;
        end
    end
end

function [bary, dist] = point_to_triangle_barycentric(p, v1, v2, v3)
    % Compute barycentric coordinates of point p in triangle (v1,v2,v3)
    % p: 1x3 point coordinates
    % v1, v2, v3: 1x3 triangle vertex coordinates
    % Returns: barycentric coordinates and distance to triangle
    
    % Compute vectors
    v0 = v2 - v1;
    v1_vec = v3 - v1;
    v2_vec = p - v1;
    
    % Compute dot products
    d00 = dot(v0, v0);
    d01 = dot(v0, v1_vec);
    d11 = dot(v1_vec, v1_vec);
    d20 = dot(v2_vec, v0);
    d21 = dot(v2_vec, v1_vec);
    
    % Compute barycentric coordinates
    denom = d00 * d11 - d01 * d01;
    v = (d11 * d20 - d01 * d21) / denom;
    w = (d00 * d21 - d01 * d20) / denom;
    u = 1 - v - w;
    
    bary = [u, v, w];
    
    % Project point onto triangle plane
    proj = v1 + v0*v + v1_vec*w;
    dist = norm(p - proj);
end