function lmk = FindLmkonDev(H,num1,num2)
[~, originalIndicesmin] = sort(H,'descend');


% Get the indices of the first few smallest elements
lmk1 = originalIndicesmin(1:num1);

[~, originalIndicesmax] = sort(H,'ascend');

% Get the indices of the first few smallest elements
lmk2 = originalIndicesmax(1:num2);

lmk = [lmk1;lmk2];

end