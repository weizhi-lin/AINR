function M = PatchGeneratorFPS(vertex1,faces1,Nlmk,para)
% generate patches with GP landmarks as centers 

%% GP landmarking 
[lmk1,label1] = GaussFPSSegmentation(vertex1,faces1,Nlmk,para);

%% Patch Generating 
lenm = MaxLength(vertex1,faces1);
[V_seg,F_seg] = SegReconstruction(label1,vertex1,Nlmk,'boundary',lenm);   

% retrieve center index on each segment
CindS = []; 
for j = 1:Nlmk
    [~,index]=ismember(vertex1(lmk1,:),V_seg{j},'rows');
    CindS(j) = index(index~=0);
end

%% Save results 
M = {};
M.Whole.V = vertex1;
M.Whole.F = faces1;
% M.Whole.lmk_all = lmk_all; % landmark index in the whole shape 
M.Whole.label = label1;
M.Whole.Center = lmk1;

M.Seg.V = V_seg;
M.Seg.F = F_seg;
% M.Seg.lmk = lmk; % landmark index on each segment 
M.Seg.Center = CindS; % center index on each segment
end