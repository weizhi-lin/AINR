function [rect1,rect2,lmkb,lmkb2] = PairParaWtLmk(vertex1,faces1,vertex2,faces2)

% construct pair-wise parameterization 
% Input: design mesh, scan mesh, landmarks
% Output: parameterized design & scan;
%         boundary landmarks on design & scan;
%         GP landmarks on design & scan;

[vertex1,faces1] = removeInvalidBorderFaces(vertex1,faces1);
[vertex1,faces1] = removeMeshEars(vertex1,faces1);

lmkb = findsquareapex(vertex1,faces1)'; % find apexes for the square
rect1 = rect_conformal_parameterization(vertex1,faces1,lmkb);


lmkb2 = BDLmkProject(vertex1,lmkb, vertex2, faces2);
rect2 = rect_conformal_parameterization(vertex2,faces2,lmkb2);

end