function [VorArea] = ComputeVoronoiArea_mex(G,Indices,para)
%COMPUTEVORONOIAREA Summary of this function goes here
%   Detailed explanation goes here
path = para.currentFolder;
% compile_mex

vertex=G.V;
faces=G.F;
[~,~,Q] = perform_fast_marching_mesh(vertex, faces, Indices);
VorArea = zeros(size(Indices));
for i=1:length(VorArea)
    VorArea(i) = sum(G.Aux.VertArea(Q == Indices(i)));
end

% if(~isdeployed)
%   cd(path);
% end

end
