function lmkpW = FrechetMeanPoints(lmk1,lmk2,vertex1,faces1,K_gauss)

W = rescale(-abs(K_gauss),0.01,1);%rescale(K_gauss(indxkeep));
% W = rescale(min(K_gauss(indxkeep),0.1),0.01,1);
options.W = W;
options.nb_iter_max = Inf;
% options = [];
Dist = zeros(length(vertex1),2);

lmk = [lmk1,lmk2];
% frechet average 
for k = 1:2
    [D,~,~] = perform_fast_marching_mesh(vertex1,faces1,lmk(k),options);
    Dist(:,k) = D;
end
rowSumFull = sum(Dist, 2);
Dist2points = (Dist(lmk(1),2)+Dist(lmk(2),1))/2;

condition = Dist < Dist2points; % Define the condition
rows = find(all(condition, 2)); % Find row indices where the condition is true for all columns

% if these two lmks are too close just randomly select one
if length(rows)<5
    lmkpW = lmk1;
else
    indxC = setdiff(1:length(vertex1),rows);
    [VC, FC] = removeMeshVertices(vertex1,faces1, indxC); % label = 1 
            
    DistR = zeros(length(VC),length(VC));
    
    options = [];
    % W = rescale(-abs(K_gauss(rows)),0.01,1);%rescale(K_gauss(indxkeep));
    % % W = rescale(min(K_gauss(indxkeep),0.1),0.01,1);
    % options.W = W;
    options.nb_iter_max = Inf;
    
    % frechet average 
    parfor i = 1:length(VC)
        [D,~,~] = perform_fast_marching_mesh(VC,FC,i,options);
        DistR(:,i) = D;
    end
    
    Dist2= symmetrize_min(DistR);
    rowSumFull = sum(Dist2, 2);
    [~,lmkp] = min(rowSumFull);
    
    lmkpW = find(ismember(vertex1,VC(lmkp,:),'rows'));
end


    % figure()
    % options.face_vertex_color = Label;
    % plot_mesh(VC,FC,options);hold on
    % plot3(vertex1([lmk],1),vertex1([lmk],2),vertex1([lmk],3),'.r',MarkerSize=20);
    % plot3(vertex1([lmkpW],1),vertex1([lmkpW],2),vertex1([lmkpW],3),'.b',MarkerSize=20);
    % shading flat; colormap cool;