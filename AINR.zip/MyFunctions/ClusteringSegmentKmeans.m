function [ index ] = ClusteringSegmentKmeans(X,k)
%MY_KMEANS input: the number k of clusters and
%                 N*3 data vector X
%         output: N*1 vector index representint the cluster ID of the corresponding data vector.
    number_of_points = size(X,1);
    %initialize centers of each clusters as k random sample points of the input data
    centers = X(randsample(1:number_of_points,k),:);
    temp_center = X(randsample(1:number_of_points,k),:);
    if (temp_center == centers)
        temp_center = X(randsample(1:number_of_points,k),:);
    end 
    %recurse until there is no changes of each cluster center.
    while(temp_center ~= centers)
        centers = temp_center;
        %E-step assignment each point to its nearest center
        for i = 1:number_of_points
            [minimum, idx]= min(sum((repmat(X(i,:),k,1)-centers).^2')');
            index(i,1) = idx;
        end
        % M-step recalculate the center for each cluster
        for i = 1:k
               [rows,cols] =find(index == i);
               temp_center(i,:) = mean(X(rows,:));
        end
    end
end