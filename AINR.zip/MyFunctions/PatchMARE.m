function [sp,mare_dev,abs_error,Habserror,areasV] = PatchMARE(V,F,Hdiff,Hscan,H)
%% surface fitting errors on patches 
areas = meshFaceAreas(V,F);
areasV = zeros(length(V),1);

% target: find the faces around each vertex 
for i = 1:length(V)
    % find the faces around vertex 
    idx1 = find(F(:,1) == i);
    idx2 = find(F(:,2) == i);
    idx3 = find(F(:,3) == i);
    idx =  unique([idx1;idx2;idx3]);
    areasV(i) = sum(areas(idx));
end

Disk = lineardiskmap(V,F);
lmkb = findsquareapex(V,F)'; 
DiskPara = Polygon2Square(Disk,F,lmkb);

% options.boundary = 'square';
% DiskPara = compute_parameterization(AdaptPatchM{k}.V,AdaptPatchM{k}.F,options)'; 
% DiskPara = lineardiskmap(AdaptPatchM{k}.V,AdaptPatchM{k}.F);
x1 = DiskPara(:,1);
y1 = DiskPara(:,2);
z1 = Hdiff;
[X1, Y1] = meshgrid(linspace(min(x1), max(x1), 100), ...
    linspace(min(y1), max(y1), 100));
% Interpolate Z-coordinate using griddata
Z1 = griddata(x1, y1, z1, X1, Y1, 'natural');

% figure()
% surf(X1,Y1,Z1); colormap jet; shading flat; colorbar;

x2 = linspace(min(x1), max(x1), 100);
y2 = linspace(min(y1), max(y1), 100);

knotsx = augknt(linspace(x2(1), x2(end), 4), 3);
knotsy = augknt(linspace(y2(1), y2(end), 4), 3);
sp =  spap2({knotsx,knotsy},[3 3], {x2,y2},Z1);

% figure()
% fnplt(sp);hold on
% surf(x2,y2,Z1');
avals = fnval(sp,{x2,y2});
abs_error = abs((Z1-avals)./Z1); % matrix 
mare_dev = sum(abs_error(:))/length(abs_error(:));

% compare with the curvature on scan 
for i = 1:length(x1)
    Hdiff_predict(i) = fnval(sp,{x1(i),y1(i)});
    Hpredict(i) = H(i)+Hdiff_predict(i);
    Habserror(i) = abs(Hscan(i)-Hpredict(i))*areasV(i);
end

end

% figure()
% surf(X1,Y1,reshape(avals,100,[])); hold on
% plot3(x1,y1,z1,'wo','markerfacecolor','k');

% xy = [x1,y1]';
% vals = z1';
% st = tpaps(xy,vals); 
% avals = fnval(st,xy);
% avalsz = fnval(st,[X1(:),Y1(:)]');
% figure()
% surf(X1,Y1,reshape(avalsz,100,[])); hold on
% surf(X1,Y1,Z1); 
% % figure()
% % fnplt(st), hold on
% % plot3(xy(1,:),xy(2,:),vals,'wo','markerfacecolor','k');
% 
% 
% abs_error = abs(abs(avalsz-Z1(:))./Z1(:));
% mare_dev = sum(abs_error(:))/length(abs_error(:));
