function dist = DistPat(P1,P2,para)

if nargin<3
    a = 0.2;
    b = 0.4;
    c = 0.4;
else
    a = para.PatchCompare_a;
    b = para.PatchCompare_b;
    c = para.PatchCompare_c;
end

CurveMap1 = P1.CurveMap;
CurveMap2 = P2.CurveMap;


WKS1 = P1.WKS(P1.Center,:);
WKS2 = P2.WKS(P2.Center,:);
dWKS = sqrt(mean((WKS1-WKS2).^2));

AgMean1 = normalize(CurveMap1.AgMean);
AgMean2 = normalize(CurveMap2.AgMean);
dAgM = sqrt(mean((AgMean1-AgMean2).^2));

AgGauss1 = normalize(CurveMap1.AgGauss);
AgGauss2 = normalize(CurveMap2.AgGauss);
dAgG = sqrt(mean((AgGauss1-AgGauss2).^2));

dist = a*dWKS+b*dAgM+c*dAgG;

end