function isolatedLocations = findIsolatedLocations(matrix)
    % Pad the matrix with zeros on all sides
    paddedMatrix = padarray(matrix, [1, 1], 0, 'both');
    
    % Initialize an empty array to hold the locations of the isolated values
    isolatedLocations = [];
    
    % Iterate through the original matrix dimensions
    for i = 2:size(paddedMatrix, 1) - 1
        for j = 2:size(paddedMatrix, 2) - 1
            % Check if the current element is non-zero and surrounded by zeros
            if paddedMatrix(i, j) ~= 0 && ...
               paddedMatrix(i-1, j) == 0 && ...
               paddedMatrix(i+1, j) == 0 && ...
               paddedMatrix(i, j-1) == 0 && ...
               paddedMatrix(i, j+1) == 0 && ...
                paddedMatrix(i-1, j-1) == 0 && ...
                paddedMatrix(i-1, j+1) == 0 && ...
                paddedMatrix(i+1, j-1) == 0 && ...
                paddedMatrix(i+1, j+1) == 0 
                % Add the location of the isolated value to the list
                % Adjust indices to match the original matrix
                isolatedLocations = [isolatedLocations; i-1, j-1];
            end
        end
    end
end
