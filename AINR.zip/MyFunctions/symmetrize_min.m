function D_sym = symmetrize_min(D)
    D_sym = min(D, D');
end

% % Example
% D = [
%     0, 3, 5;
%     4, 0, 2;
%     6, 1, 0;
% ];
% 
% D_symmetrized = symmetrize_min(D);
% disp(D_symmetrized);