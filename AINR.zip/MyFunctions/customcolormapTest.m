function cmap = customcolormapTest(p, colors)
    % Custom colormap based on specified points and color codes.
    %
    % Inputs:
    %   p - A vector of points in the range [0, 1] where each color is placed.
    %   colors - A cell array of hex color strings.
    %
    % Output:
    %   cmap - An n-by-3 matrix representing the colormap.

    % Number of colors in the output colormap
    n = 256;

    % Convert hex colors to RGB
    rgbColors = zeros(length(colors), 3);
    for i = 1:length(colors)
        rgbColors(i, :) = hex2rgb(colors{i});
    end

    % Map the input points p to the range of the output colormap indices
    positions = round(p * (n - 1)) + 1;

    % Prepare the query points for interpolation
    queryPoints = 1:n;

    % Interpolate red, green, and blue components separately
    red = interp1(positions, rgbColors(:,1), queryPoints, 'pchip');
    green = interp1(positions, rgbColors(:,2), queryPoints, 'pchip');
    blue = interp1(positions, rgbColors(:,3), queryPoints, 'pchip');

    % Combine the interpolated components and clip to [0,1] range
    cmap = [red', green', blue'];
    cmap(cmap < 0) = 0;
    cmap(cmap > 1) = 1;
end

function rgb = hex2rgb(hex)
    % Convert hex color string to RGB triplet
    hex = strrep(hex, '#', '');
    rgb = [hex2dec(hex(1:2)), hex2dec(hex(3:4)), hex2dec(hex(5:6))] / 255;
end

% % Example usage
% p = linspace(0, 1, 11);
% colors = {'#68011d','#b5172f','#d75f4e','#f7a580','#fedbc9','#f5f9f3', ...
%           '#d5e2f0','#93c5dc','#4295c1','#2265ad','#062e61'};
% J = customcolormap(p, colors);
% colormap(J);
