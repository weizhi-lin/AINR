function [map,map_mu] = ConstructTmap(v,f,point,target,corner,height,mu)

TR = TriRep(f,v(:,1),v(:,2));
B = freeBoundary(TR);
edge = edge_division(B,corner);
temp_edge = edge;
temp_corner = [corner;corner(1)];
for i = 1:4
    for j = 1:4
        if sum(ismember(temp_corner(i:i+1),edge{j})) == 4
            temp_edge{i} = edge{j};
        end
    end
end

vertical = [[edge{4};edge{2}],[zeros(length(edge{4}),1);ones(length(edge{2}),1)]];
horizontal = [[edge{1};edge{3}],[zeros(length(edge{1}),1);height*ones(length(edge{3}),1)]];

if ~isempty(point)
    constraint_x = [vertical;point,target(:,1)]; % landmarks on source (x-axis) should mapped to lmks on target 2D domain
    constraint_y = [horizontal;point,target(:,2)];
else
    constraint_x = vertical;
    constraint_y = horizontal;
end

map = map_reconstruct(v,f,mu,constraint_x,constraint_y);

map_mu = beltrami_coefficient(v,f,map);

end
