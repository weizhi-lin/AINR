%% find the 4 apexes of an open surface
% for parameterizing to a square

function lmkb=findsquareapex(vertex,face)


if size(vertex,2)>size(vertex,1)
    vertex = vertex';
end
if size(face,2)>size(face,1)
    face = face';
end

% compute the boundary
% boundary = meshBoundaryVertexIndices(vertex,face);
boundary = compute_boundary(face);

% compute the position of the boundary vertex
nbound = length(boundary);
xy_boundary = zeros(nbound,2);
% compute total length
d = 0;
ii = boundary(end); % last index
for i=boundary
    d = d + norme( vertex(i,:)-vertex(ii,:) );
    ii = i;
end

% vertices along the boundary
vb = vertex(boundary,:);
% compute the length of the boundary
sel = [2:nbound 1];
D = cumsum( sqrt( sum( (vb(sel,:)-vb).^2, 2 ) ) );
d = D(end);
% curvilinear abscice
t = (D-D(1))/d; 
t = t(:);

t = t*4;
lmkb = [];
[tmp,I] = min(abs(t-1)); 
t(I) = 1;
lmkb = [lmkb;I];
[tmp,I] = min(abs(t-2)); 
t(I) = 2;
lmkb = [lmkb;I];
[tmp,I] = min(abs(t-3)); 
t(I) = 3;
lmkb = [lmkb;I];
lmkb = [lmkb;1];

lmkb= boundary(:,lmkb);

end