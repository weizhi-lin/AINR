function [DevMat,DevMatTbl,DevShape] = SquareDevOnGridsInfo(MeshBC,lab,shapelab)

loc = median(MeshBC.MDseg.V);
[azimuth,elevation,r] = cart2sph(loc(1),loc(2),loc(3));

disk = lineardiskmap(MeshBC.MDseg.V,MeshBC.MDseg.F); 
% Linear disk map (Choi, Lui, ACOM 2018)
% Map it to square first
rect = Polygon2Square(disk,MeshBC.MDseg.F,MeshBC.BCresult.lmkb_Design);

%Map the points to grids
HdiffOnGrid = scatteredInterpolant(rect(:,1),rect(:,2),MeshBC.BCresult.Hdiff);
% Use a finer mesh to query the interpolant and improve the resolution.
FCmean = scatteredInterpolant(rect(:,1),rect(:,2),MeshBC.MDseg.H);
FCgauss = scatteredInterpolant(rect(:,1),rect(:,2),MeshBC.MDseg.K);


[xq,yq] = ndgrid(0:0.02:1);
grdHdiff = HdiffOnGrid(xq,yq); % surf(xq,yq,vq)

DevShape.xq = xq;
DevShape.yq = yq;
DevShape.zq = grdHdiff;

grdCmean = FCmean(xq,yq);
grdCgauss = FCgauss(xq,yq);
rectgrd_u = reshape(xq,[],1);
rectgrd_v = reshape(yq,[],1);
vgrdHdiff = reshape(grdHdiff,[],1);
vgrdCmean = reshape(grdCmean,[],1);
vgrdCgauss = reshape(grdCgauss,[],1);

shapelab = repmat(shapelab,length(vgrdHdiff),1);
lab = repmat(lab,length(vgrdHdiff),1);
azimuth = repmat(azimuth,length(vgrdHdiff),1);
elevation = repmat(elevation,length(vgrdHdiff),1);
r = repmat(r,length(vgrdHdiff),1);

Center = mean(MeshBC.MDseg.V);
cx = repmat(Center(1),length(vgrdHdiff),1);
cy = repmat(Center(2),length(vgrdHdiff),1);
cz = repmat(Center(3),length(vgrdHdiff),1);
Type = repmat(MeshBC.Type,length(vgrdHdiff),1);

NormalC = MeshBC.MDseg.meanNorm;
nx = repmat(NormalC(1),length(vgrdHdiff),1);
ny = repmat(NormalC(2),length(vgrdHdiff),1);
nz = repmat(NormalC(3),length(vgrdHdiff),1);

DevMat= [rectgrd_u,rectgrd_v,vgrdHdiff,vgrdCgauss,vgrdCmean,...
    nx,ny,nz,...
    cx,cy,cz,...
    azimuth,elevation,r,...
    Type,lab,shapelab];

DevMatTbl = array2table(DevMat,'VariableNames', ...
    {'rectU','rectV','Hdiff','cgauss','cmean', ...
    'NormX','NormY','NormZ',...
    'CenterX','CenterY','CenterZ',...
    'Pazimuth','Pelevation','Pr', ...
    'Type','Patch','Shape'});
end