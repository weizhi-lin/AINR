function result = exp_basis_fun(x, loc, d)
    result = exp(-(x - loc)^2 / d);
end