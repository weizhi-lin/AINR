function DevMat = ComputePatchDeviationVec(TranZ,MSeg_Design,BCshape,normLmk)

% for BC calculated without rotation 
% need to rotate the patch frist to calculate the deviation 


Npatch = length(MSeg_Design);
DevMat={};

for lk = 1:Npatch
    % define variable for notation simplicity 
    Vd = MSeg_Design{lk}.V;
    % Fd = MSeg_Design{lk}.F;
    Cd = MSeg_Design{lk}.Center;
    % 
    % Vs = MSeg_Scan{lk}.V;
    % Fs = MSeg_Scan{lk}.F;
    % Cs = MSeg_Scan{lk}.Center;

    % find the corresponding points on the rotated patches 
    Vs_R = BCshape{lk}.tmap_surface;
    
    deviationV = [Vs_R(:,1),Vs_R(:,2),Vs_R(:,3)] - [Vd(:,1),Vd(:,2),Vd(:,3)];
        
    % directional vector of deviation at landmark
    TdeviationV = deviationV*TranZ{lk};
    
    [azimuth,elevation,r] = cart2sph(TdeviationV(:,1),TdeviationV(:,2),TdeviationV(:,3));
    if azimuth<0
        azimuth = 2*pi + azimuth;
    end
    [gazimuth,gelevation,gr] = cart2sph(Vd(Cd,1),Vd(Cd,2),Vd(Cd,3));

    u = normLmk(lk,:);
    v = Vd(lk,:);
    CosTheta = max(min(dot(u,v)/(norm(u)*norm(v)),1),-1);
    ThetaInDegrees = real(acosd(CosTheta));

    glb_ct = repmat([gazimuth,gelevation,gr],length(r),1);
    lab = repmat(lk,length(r),1);
    lmk_norm=repmat(normLmk(lk,:),length(r),1);
    theta_nlk = repmat(ThetaInDegrees,length(r),1);

    DevMat.Azimuth{lk} = azimuth;
    DevMat.Elevation{lk} = elevation;
    DevMat.R{lk} = r;
    DevMat.RecDesign{lk} = BCshape{lk}.rect_Design;
    DevMat.Tbl{lk} = [BCshape{lk}.rect_Design, azimuth,elevation,r,...
        MSeg_Design{lk}.Cgauss,MSeg_Design{lk}.Cmean,theta_nlk,glb_ct,lmk_norm,lab];
    DevMat.df{lk} = mat2dataset(DevMat.Tbl{lk},'VarNames', ...
        {'rectU','rectV','theta','phi','r','cgauss','cmean','ptheta', ...
        'glbtheta','glbphi','glbr','lmknx','lmkny','lmknz','patch'});
end


end 