% define weigthed distance 
function D2 = weightdist(XI,XJ)  
%NANEUCDIST Euclidean distance ignoring coordinates with NaNs
n = size(XI,2);
weight =  1:n;
sqdx = weight.*(XI-XJ).^2;
D2squared = sum(sqdx,2); % Correction for missing coordinates
D2 = sqrt(D2squared);
end
