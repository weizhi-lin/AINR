function PlotBCresult_cells(Dseg,Cells,Mesh)
% Plot the cell on the whole shape

ftsize = 15;
fttype = 'times';

[vertex1,faces1] = MeshRead(Mesh);
Label = ones(length(vertex1),1);

for i = Cells
    [~,index] = ismember(Dseg{i}.V,vertex1,"rows");
    Label(index) = 0.1;
end

p0 = figure();
options.face_vertex_color = Label;
plot_mesh(vertex1,faces1,options); hold on;
for i = Cells
    plot3(Dseg{i}.V(Dseg{i}.Center,1),Dseg{i}.V(Dseg{i}.Center,2),Dseg{i}.V(Dseg{i}.Center,3),'.r','MarkerSize',12); hold on;
end
axis tight
Plot3AxisAtOrigin(gca)
mymap = [77 100 171
    218 221 230]/255;
colormap(p0,mymap);
end