function [VertSampInd] = GeodesicFarthestPointSampling_new(G,SampNumb,InitialSamples,para)
%FARTHESTPOINTSAMPLING Summary of this function goes here
%   Detailed explanation goes here
path = para.currentFolder;

if nargin<2
    SampNumb = G.nV;
end
if nargin<3
    rng('shuffle');
    InitialSamples = randi(G.nV,1,1);
else
    if size(InitialSamples,1)>size(InitialSamples,2)
        InitialSamples = InitialSamples';
    end
end

% ProcessedSampNumb = length(InitialSamples);
% VertSampInd = [InitialSamples, zeros(1,SampNumb-ProcessedSampNumb)];
% for k=(ProcessedSampNumb+1):SampNumb
%     progressbar(k,SampNumb,20);
%     [~,VertSampInd(k)] = max(PerformFastMarching_mex(G,VertSampInd(1:(k-1)),para));
% end
m = SampNumb;

landmarks = InitialSamples;
vertex = G.V;
faces = G.F;
l = length(landmarks);
% compile_mex  %uncomment this line
[D,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks);

for i=(l+1):m
    % select
    [~,landmarks(end+1)] = max(D);
    % update
    options.constraint_map = D;
    [D1,~,~] = perform_fast_marching_mesh(vertex, faces,landmarks,options);
    D = min(D,D1);
end
VertSampInd = landmarks;

% if(~isdeployed)
%   cd(path);
% end

end