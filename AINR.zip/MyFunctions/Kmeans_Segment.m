function MDesign = Kmeans_Segment(MD,N)

    tdStart = tic;

    vertex1 = MD.vertex;
    faces1 = MD.faces;
    % same number of clusters 

    % [~,~,Cmin,Cmax,~,~,~]= compute_curvature(vertex1,faces1);
    % [~,Cgauss1,Cmean1,~] = ComputeWeightFunction(vertex1,faces1);
    % filter = abs(Cmin)+abs(Cmax); % absolute total curvature
    lenm = MaxLength(vertex1,faces1);
    % BoundaryVer = compute_boundary(faces1);

    LabelKmeans = ClusteringSegmentKmeans(vertex1,N);

    % Reconstruct the segment with boundary cleanned 
    [V_seg_km,F_seg_km] = SegReconstruction(LabelKmeans,vertex1,N,'boundary',lenm);

    lmk_km = SegGPlmk_Reg(V_seg_km, F_seg_km);

    Ind = {};
    IC = [];
    for j = 1:N
        [~,index]=ismember(V_seg_km{j}(lmk_km{j},:),vertex1,'rows');
        Ind{j} = index;
        if ~isempty(index)
            IC(j) = index(1);
        else
            IC(j) = ismember(V_seg_km{j}(1,:),vertex1,'rows');
        end
    end
    lmk_all_km = cell2mat(Ind'); % landmarks on the whole shape


    MDSeg.V= V_seg_km;
    MDSeg.F= F_seg_km;
    MDSeg.Lmk = lmk_km;
    MD.Lmk = lmk_all_km;
    MD.Label = LabelKmeans;
    MD.CtNumber = N;
    MD.Ct = IC;

    TimeSeg = toc(tdStart);

    MDesign.MD = MD;
    MDesign.MDSeg = MDSeg;
    MDesign.Time = TimeSeg;

end

    