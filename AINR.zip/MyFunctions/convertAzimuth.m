function converted_angle = convertAzimuth(angle)
    if angle < 0
        converted_angle = angle + 2*pi;
    else
        converted_angle = angle;
    end
end
