function DevMap = DevMap1D(M,dscale,N)

if nargin<2
    N=15; % expansion steps
    dscale = 1;
end

Hdiff= M.Hdiff;
K_Hdiff = M.K_Hdiff;

vertex1 = M.V;
faces1 = M.F;
lmk = M.Center;


% weight the difussion distance based on smoothness of gaussian curvature 
options = [];
% W = rescale(-abs(C_mean),0.01,1); %rescale(K_gauss(indxkeep));
% options.W = W;
options.nb_iter_max = Inf;

[D,~,~] = perform_fast_marching_mesh(vertex1,faces1,lmk,options);

% figure()
% options.face_vertex_color = mod(D,1);%mod( 20*D/max(D),1 );
% plot_mesh(vertex1,faces1, options); hold on 
% colormap jet(256);
% plot3(vertex1(lmk,1),vertex1(lmk,2),vertex1(lmk,3),'.b','MarkerSize',10); shading flat

SD = sort(D);
% dstep = quantile(diff(SD),[0.9],[1]);
dstep = dscale * (max(D)/N);
d0 = SD(2); % smallest distance from the center 

MeanStep = zeros(N,5);
% gradually expend the patch and exam the statistics of the added region 
for i = 1:N
    d_i0 = d0+(i-1)*dstep; % this is for parfor
    d_i = d0+i*dstep;

    indx = find(D<=d_i & D>d_i0); % indices of the added vertices
    % indx0 = find(D<=d_i0); %indices of the current patch

    if isempty(indx)
        break;
    end

    MeanStep(i,1) = d_i;
    % MeanStep(i,2) = quantile(C_mean(indx),0.9)-quantile(C_mean(indx),0.1);%median(C_mean(indx));
    % MeanStep(i,3) = quantile(C_gauss(indx),0.9)-quantile(C_gauss(indx),0.1);
    MeanStep(i,2) = mean(Hdiff(indx));

    Hdiff_add = Hdiff(indx);
    [~,ind] = max(abs(Hdiff_add));
    MeanStep(i,3) = Hdiff_add(ind);

    MeanStep(i,4) = mean(K_Hdiff(indx));

    K_Hdiff_add = K_Hdiff(indx);
    [~,ind] = max(abs(K_Hdiff_add));
    MeanStep(i,5) = K_Hdiff_add(ind);

end 

DevMap.AgHdiff = MeanStep(:,2);
DevMap.MaxHdiff = MeanStep(:,3);
DevMap.AgKHdiff = MeanStep(:,4);
DevMap.MaxKHdiff = MeanStep(:,5);


DevMap.NorAgHdiff = MeanStep(:,2)/max(abs(MeanStep(:,2)));
DevMap.NorMaxHdiff = MeanStep(:,3)/max(abs(MeanStep(:,3)));
DevMap.NorAgKHdiff = MeanStep(:,4)/max(abs(MeanStep(:,4)));
DevMap.NorMaxKHdiff = MeanStep(:,5)/max(abs(MeanStep(:,5)));



x = 1:N; 
xq = linspace(1,N,100); %1:0.14:15;
% v = AdaptPatchALL{i}.CurveMap.NorAgMean;
DevMap.NorAgHdiffEx = interp1(x,DevMap.NorAgHdiff,xq,'spline');% spline
DevMap.NorMaxHdiffEx = interp1(x,DevMap.NorMaxHdiff,xq,'spline');
DevMap.NorAgKHdiffEx = interp1(x,DevMap.NorAgKHdiff,xq,'spline');
DevMap.NorMaxKHdiffEx = interp1(x,DevMap.NorMaxKHdiff,xq,'spline');




