% remove the landmarks on the boundary
function lmkb2 = BDLmkClean(vertex1,faces1,lmkb)
% boundary = meshBoundaryVertexIndices(vertex2,faces2);
boundary = compute_boundary(faces1);
boundary_v = vertex1(boundary,:);

[ind_bd1,ind_bd] = ismember(vertex1(lmkb,:),boundary_v ,'rows');

lmkb(:,find(ind_bd1)) = [];
lmkb2 = lmkb;

%
end