function [RotatedMesh,Info] = ExtractCovariate(V,F,Ct)

normalPatch = meshVertexNormals(V,F);
normalAverage = mean(normalPatch,1);

TranZ= Align2Vector([0,0,1]',normalAverage'/norm(normalAverage)); 
% rotate the design patch and the scan patch 
vertex_Seg_rD = V * TranZ;

% move the lmk to the center
Vd_R = vertex_Seg_rD-vertex_Seg_rD(Ct,:);

RotatedMesh.V = Vd_R;
RotatedMesh.F = F;

[glbtheta,glbphi,glbr] = cart2sph(V(Ct,1),V(Ct,2),V(Ct,3));

% the angle between the average normal and the line connecting O and the lmk
u = normalAverage;
v = V(Ct,:);
CosTheta = max(min(dot(u,v)/(norm(u)*norm(v)),1),-1);
P0theta = real(acosd(CosTheta)); % the angle between the normal and the 0-lmk ray

 
% the angle between the average landmark and z axis
v = [0,0,1];
CosTheta2 = max(min(dot(u,v)/(norm(u)*norm(v)),1),-1);
PZtheta = real(acosd(CosTheta2)); % the angle between the normal of lmk and the 

Info.glbtheta = glbtheta;
Info.glbphi = glbphi;
Info.glbr = glbr;
Info.P0theta = P0theta;
Info.PZtheta = PZtheta;

end

% 
% V = AdaptPatchM{i}.V;
% F = AdaptPatchM{i}.F;
% Ct = AdaptPatchM{i}.Center;
% figure()
% plot_mesh(Vd_R,F);
% axis on