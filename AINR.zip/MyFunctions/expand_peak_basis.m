function X = expand_peak_basis(x, bf, n_knots,d, internal_knots)
% bsplineBasis: Construct k Bspline Basis with n gridded with spline degree sd
% Input Variable: 
% n: length of signal or number of pixels 
% k: number of knots, k = n, sd must be zero, then I matrix
% sd: spline degree, sd = 0, then constant function
% bd: how many basis in boundary. 


    if nargin < 3
        n_knots = 10;
    end

    if nargin < 4
        d = 1;
    end
    if nargin < 5
        internal_knots = 0;
    end

    n_knots = n_knots + 2 * internal_knots;
    locs = linspace(min(x), max(x), n_knots);
    
    if internal_knots
        locs = locs(2:end-1);
    end
    
    X = zeros(length(x), length(locs));
    
    for i = 1:length(x)
        for j = 1:length(locs)
            X(i, j) = bf(x(i), locs(j), d);
        end
    end
end

