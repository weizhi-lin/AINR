function [tmap,tmap_surface] = Tmap_bc(v,f,rect2,vertex2,mu,corner)
% given beltrami coefficients construct the mapped mesh (2D and 3D)

height = max(rect2(:,2)); % target shape's parameterization's boundary
TR = TriRep(f,v(:,1),v(:,2));
B = freeBoundary(TR);
edge = edge_division(B,corner);
temp_edge = edge;
temp_corner = [corner;corner(1)];
for i = 1:4
    for j = 1:4
        if sum(ismember(temp_corner(i:i+1),edge{j})) == 4
            temp_edge{i} = edge{j};
        end
    end
end

vertical = [[edge{4};edge{2}],[zeros(length(edge{4}),1);ones(length(edge{2}),1)]];
horizontal = [[edge{1};edge{3}],[zeros(length(edge{1}),1);height*ones(length(edge{3}),1)]];

constraint_x = vertical;
constraint_y = horizontal;

tmap = map_reconstruct(v,f,mu,constraint_x,constraint_y);


% Computing the Teichmuller distance
% d = 1/2*log((1+mean(abs(tmap_bc)))/(1-mean(abs(tmap_bc)))); 
% fprintf('Teichmuller distnace between the teeth = %f\n',d);

% Construct the interpolants
Fx = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,1),'linear');
Fy = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,2),'linear');
Fz = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,3),'linear');

% Find the surface T-map
tmap_surface = zeros(length(tmap),3);
tmap_surface(:,1) = Fx(tmap(:,1),tmap(:,2));
tmap_surface(:,2) = Fy(tmap(:,1),tmap(:,2));
tmap_surface(:,3) = Fz(tmap(:,1),tmap(:,2));

end

