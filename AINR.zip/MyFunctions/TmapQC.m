function [tmap,tmap_bc,tmap_surface,d,H_diff,K_diff,H1,K1] = TmapQC(rect1,rect2, ...
    vertex2,faces1,lmkb,Ind_design,Ind_scan)
% Calculate the pair-wise bc coeffeicients and the registrated surface 

%% Registration
interior_landmark = Ind_design'; % indices of the interior landmarks
interior_landmark_target = rect2(Ind_scan,1:2); % target positions of the landmarks
height = max(rect2(:,2)); % target height of the rectangle

% Compute the Teichmuller map between the rectangles using QC Iteration
[tmap,tmap_bc] = rectangular_Teichmuller_map(rect1,faces1,...
    interior_landmark,interior_landmark_target,lmkb,height);

% Computing the Teichmuller distance
d = 1/2*log((1+mean(abs(tmap_bc)))/(1-mean(abs(tmap_bc)))); 
fprintf('Teichmuller distnace between the teeth = %f\n',d);

% Construct the interpolants
Fx = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,1),'linear');
Fy = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,2),'linear');
Fz = scatteredInterpolant(rect2(:,1),rect2(:,2),vertex2(:,3),'linear');


[~,K1,H1,~] = ComputeWeightFunction(vertex1,faces1);
% 
% FV2.vertices = vertex2; FV2.faces = faces2;
% [H2,K2] = patchcurvature(FV2,true);
[~,K2,H2,~] = ComputeWeightFunction(vertex2,faces2);

H2_interp = scatteredInterpolant(vertex2(:,1),vertex2(:,2),vertex2(:,3),H2,'linear');
K2_interp = scatteredInterpolant(vertex2(:,1),vertex2(:,2),vertex2(:,3),K2,'linear');

% Find the surface T-map
tmap_surface = zeros(length(tmap),3);
tmap_surface(:,1) = Fx(tmap(:,1),tmap(:,2));
tmap_surface(:,2) = Fy(tmap(:,1),tmap(:,2));
tmap_surface(:,3) = Fz(tmap(:,1),tmap(:,2));
% Find the curvature difference
H_diff = H1 - H2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3));
K_diff = K1 - K2_interp(tmap_surface(:,1),tmap_surface(:,2),tmap_surface(:,3));
end