function [V_seg,F_seg,area] = SegReconstruction_sig(label,vertex,var,lenm)


options.method = 'slow';
options.verb = 0;
% V_seg = {};
% F_seg = {};
% area = [];
% the input should be N*3
if size(vertex,2) > size(vertex,1)
    vertex = vertex';
end

I = find(label); %find index in the original file
    V = vertex(I,:);
    [F]=MyCrustOpen(V);
    F = double(F);
    V = V'; %3*N
    F = F';
    F = perform_faces_reorientation(V,F,options); %should be 3*N
%     [V,F]= MeshProcess(V,F);
    
    switch(var)
        case 'orignal'
            [V,F]= MeshProcess(V',F');
        case 'boundary'
            [V,F] = BoundaryProcess(V',F',lenm);
%             [V,F]= MeshProcess(V,F);
%             [V,F] = BoundaryProcess(V,F,lenm); % boundary
    end

    M = Mesh('VF',V',F');
    [~,~,flip] = M.ComputeNormal();
    if flip
        M.F = M.F([1 3 2],:);
    end
%     
%     [V,F] = remove_non_manifold_vertices(V,F);
%     boundaries = select_holes_and_boundary(V,F);
%     F = fill_mesh_holes(V,F,boundaries,'opened',200);

%     V_seg{i} = V;
%     F_seg{i} = F;
    V_seg = M.V';
    F_seg = M.F';
    area = meshSurfaceArea(M.V',M.F');

end



% [SV,SF] = clean_mesh(V',F','MinDist',0,'MinArea',0,'MinAngle',0, ...
%      'SelfIntersections','remove','SmallTriangles','remove');
% figure()
% plot_mesh(SV,SF);