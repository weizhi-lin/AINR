function [Label,u] = HeatPatch(vertex,faces,index,timeStep,limitU)
% Generate the patch of time step t where the heat diffused > limitU 
% check dimensitionality: should be 3*#
if size(vertex,2) < size(vertex,1)
    X = vertex';
    F = faces';
else
    X = vertex;
    F = faces;
end

n = size(X,2); % vertex number 
m = size(F,2); % faces number 

%% Gradient, Divergence and Laplacian on Surfaces
% use piecewise linear finite element to compute the gradient operators

% Callback to get the coordinates of all the vertex of index i = 1,2,3 in all faces
XF = @(i)X(:,F(i,:));
% un-normalized normal through the formula e_i ^ e_j
Na = cross( XF(2)-XF(1), XF(3)-XF(1) );

% Compute the area of each face as half the norm of the cross product.
amplitude = @(X)sqrt( sum( X.^2 ) );
A = amplitude(Na)/2;

% Compute the set of unit-norm normals to each face.
normalize = @(X)X ./ repmat(amplitude(X), [3 1]);
N = normalize(Na);

% Populate the sparse entries of the matrices for the operator implementing 
I = []; J = []; V = []; % indexes to build the sparse matrices
for i=1:3
    % opposite edge e_i indexes
    s = mod(i,3)+1;
    t = mod(i+1,3)+1;
    % vector N_f^e_i
    wi = cross(XF(t)-XF(s),N);
    % update the index listing
    I = [I, 1:m];
    J = [J, F(i,:)];
    V = [V, wi];
end
% Sparse matrix with entries 
dA = spdiags(1./(2*A(:)),0,m,m);

% compute gradient 
GradMat = {};
for k=1:3
    GradMat{k} = dA*sparse(I,J,V(k,:),m,n);
end
Grad = @(u)[GradMat{1}*u, GradMat{2}*u, GradMat{3}*u]';

% Compute divergence matrices as transposed of grad for the face area inner product.
dAf = spdiags(2*A(:),0,m,m);
DivMat = {GradMat{1}'*dAf, GradMat{2}'*dAf, GradMat{3}'*dAf};

% Div operator.
Div = @(q)DivMat{1}*q(1,:)' + DivMat{2}*q(2,:)' + DivMat{3}*q(3,:)';

% Laplacian operator as the composition of grad and div.
Delta = DivMat{1}*GradMat{1} + DivMat{2}*GradMat{2} + DivMat{3}*GradMat{3};

% Cotan of an angle between two vectors.
cota = @(a,b)cot( acos( dot(normalize(a),normalize(b)) ) );

% Compute cotan weights Laplacian.
I = []; J = []; V = []; % indexes to build the sparse matrices
Ia = []; Va = []; % area of vertices
for i=1:3
    % opposite edge e_i indexes
    s = mod(i,3)+1;
    t = mod(i+1,3)+1;
    % adjacent edge
    ctheta = cota(XF(s)-XF(i), XF(t)-XF(i));
    % ctheta = max(ctheta, 1e-2); % avoid degeneracy
    % update the index listing
    I = [I, F(s,:), F(t,:)];
    J = [J, F(t,:), F(s,:)];
    V = [V, ctheta, ctheta];
    % update the diagonal with area of face around vertices
    Ia = [Ia, F(i,:)];
    Va = [Va, A];
end
% Aread diagonal matrix
Ac = sparse(Ia,Ia,Va,n,n);
% Cotan weights
Wc = sparse(I,J,V,n,n);
% Laplacian with cotan weights.
DeltaCot = spdiags(full(sum(Wc))', 0, n,n) - Wc;

t = timeStep;

% heat diffusion solution
delta = zeros(n,1);
delta(index) = 1;
u = (Ac+t*Delta)\delta;

% find points within certain range
% Index = u>quantile(u,0.985);
Index = u > limitU;
Label = zeros(size(u));
Label(Index) = 1;
end


