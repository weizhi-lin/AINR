function G2 = ICPreg(G1,G2)
% register 2 patches with ICP

[vertex1,faces1] = MeshRead(G1);
[vertex2,faces2] = MeshRead(G2);

vertexFixed = pointCloud(vertex1);
vertexMoved = pointCloud(vertex2);

[tform,~,~] = pcregistericp(vertexMoved,vertexFixed);%,'MaxIterations',10);
ptCloudOut = pctransform(vertexMoved,tform);
vertex2m = ptCloudOut.Location;
% G2 = Mesh('VF',vertex2m',faces2');

G2.V = vertex2m;

end

% 
% 
% figure()
% plot_mesh(vertex2m,faces2); hold on
% % plot_mesh(vertex2,faces2);
% plot_mesh(vertex1,faces1);

