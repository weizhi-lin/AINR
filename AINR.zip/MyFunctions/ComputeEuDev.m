function [pt2ptDist, pt2planeDist,idx] = ComputeEuDev(vertex1,vertex2)

sourcePC = pointCloud(vertex1);
targetPC = pointCloud(vertex2);


% Ensure they are registered
% sourcePC = pctransform(sourcePC, tform); % If you have a transformation tform

% Point-to-point distances
sourcePoints = sourcePC.Location;
targetPoints = targetPC.Location;

% Find the nearest neighbors in the target point cloud
[idx, D] = knnsearch(targetPoints, sourcePoints);
% signedDistances = targetPoints(idx, :) - sourcePoints;
pt2ptDist = D;

% D contains the point-to-point distances
% figure()
% options.face_vertex_color = D;
% plot_mesh(vertex1,faces1,options);
% colormap(J);
% shading flat; colorbar

% Point-to-plane distances
% Compute normals of the target point cloud
normals = pcnormals(targetPC);

% Calculate point-to-plane distances
pt2planeDist = zeros(size(sourcePoints, 1), 1);

for i = 1:size(sourcePoints, 1)
    nearestPoint = targetPoints(idx(i), :);
    normal = normals(idx(i), :);
    point = sourcePoints(i, :);
    pt2planeDist(i) = dot((point - nearestPoint), normal) / norm(normal); % No absolute value
end


% % pt2planeDist contains the point-to-plane distances
% figure()
% options.face_vertex_color = pt2planeDist;
% plot_mesh(vertex1,faces1,options);
% colormap(J);
% shading flat; colorbar