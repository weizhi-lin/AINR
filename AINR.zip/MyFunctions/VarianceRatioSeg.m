function VRCK = VarianceRatioSeg(Mesh,AdaptPatch)
vertex1 = Mesh.V;
faces1 = Mesh.F;
Hdiff = Mesh.Hdiff;
[~,VertArea] = VertexAreaMesh(vertex1,faces1);

S = meshSurfaceArea(vertex1,faces1);
Mshape = sum(Hdiff.*VertArea)/S;

SSB = 0; SSW = 0;
for i = 1:length(AdaptPatch)
    % Ni = length(AdaptPatch{i}.V);

    % mean deviation on pathces
    ind = find(ismember(vertex1,AdaptPatch{i}.V,'row'));
    patcharea = meshSurfaceArea(AdaptPatch{i}.V, AdaptPatch{i}.F);

    % unit deviation 
    patHdiff = (AdaptPatch{i}.Hdiff).*VertArea(ind);

    % average deviation on patch 
    mean_p = sum(patHdiff)/patcharea;

    SSB = patcharea*pdist2(Mshape,mean_p) + SSB;
    SSW = sum(pdist2(patHdiff,mean_p)) +SSW;
end

% K = length(AdaptPatchM);
% N = length(AdaptPatch_Ori.V);
% VRCK = (SSB*(N-K))/(SSW*(K-1));
VRCK = SSB/SSW;

end