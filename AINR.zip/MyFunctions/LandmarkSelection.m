function [vertex1,faces1,vertexV,facesV,V_seg,F_seg,lmk,lmk_all,T,rho,delta,dc,p,DS,C_ind,IC,label1,CindS] = LandmarkSelection(data_folder,data_file1,para)
Nlmk = para.Nlmk;% 60;
% remeshN = para.remeshN;%3000;
currentFolder = para.currentFolder;

Mesh_Design = Mesh('off',fullfile(data_folder,data_file1));
vertex1 = Mesh_Design.V';
faces1 = Mesh_Design.F';
[vertex1,faces1] = trimMesh(vertex1,faces1);

Nvertex = size(vertex1,1);
if Nvertex < 1e+5
    remeshN = 3000;
else
    remeshN = Nvertex *0.03;
    remeshN = min(remeshN,5000);
end

tStart = tic;
%% Step2: Feature sensitive remeshing
[~,~,Cmin,Cmax,~,~,~] = compute_curvature(vertex1,faces1);
filter = abs(Cmin)+abs(Cmax); % absolute total curvature

tRemeshS = tic;
[vertexV,facesV] = FeatureRemesh(vertex1,faces1,remeshN,filter,currentFolder);
tRemesh = toc(tRemeshS);
disp(['Time of remeshing is ',num2str(tRemesh/60),'min']) 

[vertexV,facesV] = MeshEnsureManifold(vertexV,facesV);
[vertexV,facesV]= MeshProcess(vertexV,facesV);

%% Step3: Geodesic distance computation
tGeodesicS = tic;
DS = GeodesicDistance(vertexV,facesV);
tGeodesic = toc(tGeodesicS);

%% Step4: Clustering-based segmentation
tFinddcS = tic;
[rho,delta,dc,p] = FindBestDesicionValue(DS);
tFinddc = toc(tFinddcS);

[C_ind,N] = ClusterCenter(rho,delta);

disp(['Number of segments is ',num2str(N)]) 
% assign vertex to each cluster 
label = AssignCluster(C_ind, DS);

%% Step5: Segment projection and reconstruction 

% position of cluster center on the original mesh
vertexC = vertexV(C_ind,:);
[~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);


% project the clustering result to the orignal(designed) shape
label1 = ProjectClustering(vertexV, vertex1, label);

% Reconstruct the segment with boundary cleanned 
lenm = MaxLength(vertex1,faces1);
[V_seg,F_seg] = SegReconstruction(label1,vertex1,N,'boundary',lenm);

%% Step 6: Segment-wise landmarking
N = size(V_seg,2);

% retrieve center index on each segment
CindS = [];
for i = 1:N
[~,index]=ismember(vertex1(IC(i),:),V_seg{i},'rows');
CindS(i) = index;
end

tlmkS = tic;
lmk = SegGPlmk(V_seg, F_seg, CindS, Nlmk,'AGD');
Ind = {};
for i = 1:N
    [~,index]=ismember(V_seg{i}(lmk{i},:),vertex1,'rows');
    Ind{i} = index;
end
lmk_all = cell2mat(Ind');
tlmk = toc(tlmkS);

t_Entire = toc(tStart);

T = [tRemesh/60,tGeodesic/60,tFinddc/60,tlmk/60,t_Entire/60];

% L.V_seg = V_seg;
% L.F_seg = F_seg;
% L.lmk = lmk;
% L.lmk_all = lmk_all;
% L.T = T;
% L.rho = rho;
% L.delta = delta;

disp(['Time to compute the geodesic distance is ',num2str(tGeodesic/60),'min']) 
disp(['Time to determine dc is ',num2str(tFinddc/60),'min']);
disp(['Time to find all landmarks is ',num2str(tlmk/60),'min']);
disp(['Time to run the whole process is ',num2str(t_Entire/60),'min']);

%% Visualization 
% figure()
% plot_mesh(vertexV,facesV);shading faceted;
% title(['Remesh result of ',data_file1])
figure()
subplot(2,2,1)
scatter(rho,delta);hold on
scatter(rho(C_ind),delta(C_ind),'r');
% title([data_file1, ' Decision Graph: number of segments',num2str(N)]);

% show the positions of cluster center on the remeshed mesh 
subplot(2,2,2)
options.face_vertex_color = label;
plot_mesh(vertexV,facesV,options);shading faceted;
colormap jet(256);
hold on;
h = plot3(vertexV(C_ind,1), vertexV(C_ind,2), vertexV(C_ind,3), 'r.');
set(h, 'MarkerSize', 25);
% title([data_file1,'number of segments',num2str(N),'; Size of remesh:',num2str(size(vertexV,1))]);

% clustering result on the original shape
subplot(2,2,3)
options.face_vertex_color = label1;
plot_mesh(vertex1,faces1,options);%shading faceted;
colormap jet(256);
hold on;
h = plot3(vertex1(IC,1), vertex1(IC,2), vertex1(IC,3), 'r.');
set(h, 'MarkerSize', 25);
% title([data_file1,'number of segments',num2str(N)]);


% landmarks 
subplot(2,2,4)
options.face_vertex_color = label1;
plot_mesh(vertex1,faces1,options);%shading faceted;
colormap jet(256);
hold on;
h = plot3(vertex1(lmk_all,1), vertex1(lmk_all,2), vertex1(lmk_all,3), 'r.');
set(h, 'MarkerSize', 25);
title([data_file1,'number of segments',num2str(N)]);

end