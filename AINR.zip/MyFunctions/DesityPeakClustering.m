function M = DesityPeakClustering(vertex1,faces1,filter,para)
%% this function realize the density-based complex shape segmentation
% input: original mesh
% output: data structure M containing both the segmentation results and
% segmented shape 

%% Import data
M = {};

Nvertex = size(vertex1,1);
Nvertex = max(floor(Nvertex *0.03),3000);
remeshN = min(Nvertex,5000);

currentFolder = para.currentFolder;
% 
% [~,~,Cmin,Cmax,~,Cgauss,~] = compute_curvature(vertex1,faces1); %[Umin,Umax,Cmin,Cmax,Cmean,Cgauss,Normal]
% Ctotal = abs(Cmin)+abs(Cmax); % absolute total curvature
% filter = abs(Ctotal.*Cgauss); 

%% Step 1: Feature sensitive remeshing
tRemeshS = tic;
[vertexV,facesV] = FeatureRemesh(vertex1,faces1,remeshN,filter,currentFolder);
tRemesh = toc(tRemeshS);

[vertexV,facesV] = MeshEnsureManifold(vertexV',facesV');
[vertexV,facesV]= MeshProcess(vertexV,facesV);

%% Step 2: Compute geodesic distance 
tGeodesicS = tic;
DS = GeodesicDistance(vertexV,facesV);
tGeodesic = toc(tGeodesicS);

%% Step 3: Density-peak clustering 

[rho,delta,~,~] = FindBestDesicionValue(DS);
[C_ind,N] = ClusterCenter(rho,delta);

vertexC = vertexV(C_ind,:);
[~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);
    
% generate the clustering results on the orignal(designed) shape
[label1,~] = GenerateVoronoiDiagram(vertex1,faces1,IC,para.currentFolder); %Center

%% Step 4: Segmentation 

% Reconstruct the segment with boundary cleanned 
lenm = MaxLength(vertex1,faces1);
[V_seg,F_seg] = SegReconstruction(label1,vertex1,N,'boundary',lenm);   


% retrieve center index on each segment
CindS = []; 
for j = 1:N
    [~,index]=ismember(vertex1(IC,:),V_seg{j},'rows');
    CindS(j) = index(index~=0);
end

% 
% MP.V = vertex1;
% MP.F = faces1;
% MP.V_seg = V_seg;
% MP.F_seg = F_seg;
% MP.C = IC;
% MP.label = label1;
% MP.CindS = CindS;
% MP.T = [tRemesh/60,tGeodesic/60];
% MP.VR = vertexV;
% MP.FR = facesV;


M.Whole.V = vertex1;
M.Whole.F = faces1;
% M.Whole.lmk_all = lmk_all; % landmark index in the whole shape 
M.Whole.label = label1;
M.Whole.Center = IC;

M.Remesh.V = vertexV;
M.Remesh.F = facesV;
M.Remesh.Center = C_ind;

M.Seg.V_seg = V_seg;
M.Seg.F_seg = F_seg;
% M.Seg.lmk = lmk; % landmark index on each segment 
M.Seg.Center = CindS; % center index on each segment

M.Decision.rho = rho;
M.Decision.delta = delta;
% M.Decision.p = p;
M.Decision.DS = DS;
% M.Decision.dc = dc;

M.time = [tRemesh/60,tGeodesic/60];


if(para.display == 1)
    figure()
    subplot(2,2,1)
    plot_mesh(vertex1,faces1);
    colormap white
    shading faceted

    subplot(2,2,2)
    plot_mesh(vertexV,facesV);hold on
    plot3(vertexV(C_ind,1),vertexV(C_ind,2),vertexV(C_ind,3),'.r','MarkerSize',15);
    shading faceted;
    colormap white 
    
    d = log(rho.*delta);
    [B,~] = sortrows([rho,delta,d],3,'descend');
    Nc = 1:length(IC);
    subplot(2,2,3)
    scatter(B(:,1),B(:,2),50); hold on
    scatter(B(Nc,1),B(Nc,2),55,'r');
    xlim([min(rho),max(rho)]);
    ylim([min(delta),max(delta)]);
    xlabel('Local density','FontSize',18);
    ylabel('Local maximun distance','FontSize',18);
    labelpoints(B(1:(length(Nc)+1),1),B(1:(length(Nc)+1),2),[Nc,length(Nc)+1],'N',0.05,'FontSize',10);
    
    subplot(2,2,4)
    options.face_vertex_color = label1;
    plot_mesh(vertex1,faces1,options);hold on
    plot3(vertex1(IC,1),vertex1(IC,2),vertex1(IC,3),'.r','MarkerSize',15);
    colormap jet(256);
end 


if(~isdeployed)
  cd(currentFolder);
end

end 