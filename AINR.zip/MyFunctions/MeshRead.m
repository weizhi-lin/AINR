function [vertex,faces] = MeshRead(M)
vertex = M.V;
faces = M.F;

if size(vertex,2) > size(vertex,1)
    vertex = vertex';
end

if size(faces,2) > size(faces,1)
    faces = faces';
end

end