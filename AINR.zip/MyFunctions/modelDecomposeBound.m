function [yhat,a,BetaA] = modelDecomposeBound(y,B,Ba,lambda,gamma,maxIter,errtol)
%%  model the function with smoothing 
%       -----------------
%       y      :    Signal/image to be decomposed
%       B      :    Basis for mean
%       lambda :    Smoothing Parameter, the algorithm will decide if
%       empty(gcv)
%       -----------------
%  Output:
%       -----------------
%       yhat   :    mean
%       a      :    Anomalies

%% Test & prepare the variables
%---

plus0 = @(x) (x>0).*x;

% default parameters setup
if nargin<7
    errtol = 1e-3;
    if nargin<6
        maxIter = 30;
    end
end
isAutoLambda = isempty(lambda);
isAutoGamma = isempty(gamma);

sizey = size(y);
ndim = sum(sizey~=1);


if numel(lambda) == 1
    lambda = ones(ndim,1)*lambda;
end

if ndim == 1
    Lbs = 2*norm(Ba{1})^2;
    Xbeta = zeros(size(Ba{1},2),1);
    BetaA = zeros(size(Ba{1},2),1);
elseif ndim == 2
    Lbs = 2*norm(Ba{1})^2*norm(Ba{2})^2;
    Xbeta = zeros(size(Ba{1},2),size(Ba{2},2));
    BetaA = zeros(size(Ba{1},2),size(Ba{2},2));
end

SChange = 1e10;
H = cell(ndim,1);
a = zeros(size(y));
C = cell(ndim,1);
Z = cell(ndim,1);

for idim = 1:ndim
    Li = sqrtm(B{idim}'*B{idim});
    Li = Li + 1e-8*eye(size(Li));
    Di = diff(eye(size(B{idim},2)),1);
    [Ui,C{idim},~] =  svd((Li')\(Di'*Di)/(Li));
    Z{idim} = B{idim}/(Li')*Ui;
end

%% Initial solution should use more basis to capture 
[a0,~] = modelSparse(y,Ba,[]);
a = a0;
% threshold_a0 = multithresh(abs(a0),3);
% y_r = LocIdentifier(y,a0,0,threshold_a0(1)); % location of remaining patterns
% upb = max(y_r(:));
% 
% figure()
% mesh(X,Y,a,'FaceColor','interp','LineStyle','none')
% axis tight
% view([-18,15])

% % use gaussian basis to fit the remaining pattern -> find the bounds
% [aR,BetaRe] = modelSparse(y_r,Ba,[]);
% figure()
% mesh(X,Y,aR,'FaceColor','interp','LineStyle','none')
% axis tight
% view([-18,15])

%% preparing for fitting the remaining pattern with L2 penalty
% 
% gcv = @(x) splinegcv(x,y_r,C,Z,0,[]);
% if isAutoLambda %&& iIter==1
%     lambda = fminbnd(gcv,1e-2,1e3);
%     disp(['lambda = ',num2str(lambda)]);
%     lambda = ones(ndim,1)*lambda;
% end
% 
% for idim = 1:ndim
%     H{idim} = Z{idim}*diag(1./(ones(size(C{idim},1),1) + lambda(idim)*diag(C{idim})))*Z{idim}'; 
% end

iIter = 0;
t = 1;
SChange0 = 10;
dSChange = -1;
% stop when the estimation error is not reducing 
while SChange > errtol && iIter < maxIter
    iIter = iIter + 1;
    Sold = a;
    a0 = a;
    BetaSold = BetaA;
    told = t;
    SChange0 = SChange; 
    dSChange0 = dSChange;

%% Determine the bounds for the remaining pattern 

    threshold_a0 = multithresh(abs(a0),3);
    y_r = LocIdentifier(y,a0,0,threshold_a0(2)); % location of remaining patterns
    upb = max(y_r(:));
    % for identifying the bounds for the coefficients 
    [~,BetaRe] = modelSparse(y_r,Ba,[]);


gcv = @(x) splinegcv(x,y_r,C,Z,0,[]);
if isAutoLambda %&& iIter==1
    lambda = fminbnd(gcv,1e-2,1e3);
    disp(['lambda = ',num2str(lambda)]);
    lambda = ones(ndim,1)*lambda;
end

for idim = 1:ndim
    H{idim} = Z{idim}*diag(1./(ones(size(C{idim},1),1) + lambda(idim)*diag(C{idim})))*Z{idim}'; 
end


%% Fit the remaining pattern

    if ndim == 1
        yhat = H{1}*(y-a0);
        yhat(find(yhat>upb)) = upb;
        yhat(find(yhat<-upb)) = -upb;
        BetaSe = Xbeta + 2/Lbs*Ba{1}'*(y -Ba{1}*Xbeta - yhat);
        % weighted by the initial solution 
    elseif ndim == 2
        yhat = H{1}*(y-a0)*H{2};
        yhat(find(yhat>upb)) = upb;
        yhat(find(yhat<-upb)) = -upb;
        % weighted by the initial solution 
        BetaSe = Xbeta + 2/Lbs*Ba{1}'*(y -Ba{1}*Xbeta*Ba{2}' - yhat)*Ba{2};
    end

 %% weight the coefficient of major pattern to be less sensitive to the 
    maxYe = max(abs(BetaSe(:)));

    if isAutoGamma && mod(iIter,5)==1
        gamma = graythresh(abs(BetaSe)/maxYe)*maxYe*Lbs;
    end

    BetaA = wthresh(BetaSe,'h',gamma/Lbs); % change 'h' to 's' for softthresholding

    %% identify isoldated coefficients for the major patterns 
    % temp_up = multithresh(abs(BetaRe),3);
    temp_up = max(BetaRe(:));
    isoLoc = findIsolatedLocations(BetaA);
    Loc = [];
    BetaAT = BetaA;
    for il = 1:size(isoLoc,1)
        if abs(BetaA(isoLoc(il,1),isoLoc(il,2)))<temp_up
            Loc = [Loc;isoLoc(il,:)];
        end
        BetaAT(isoLoc(il,1),isoLoc(il,2)) = 0;
    end
    
    BetaA = BetaAT;

%% Update
    if ndim == 1
        a = Ba{1} *BetaA;
    elseif ndim==2
        a = Ba{1} *BetaA* Ba{2}';
    end

    t = (1+sqrt(1+4*told^2))/2;

    if iIter==1
        Xbeta = BetaA;
    else
        Xbeta = BetaA+(told-1)/t*(BetaA-BetaSold);
    end

    y_m = LocIdentifier(y,a,1);
    y_ri = LocIdentifier(y,a,0);
    SChange = sum(sum(sum((a - y_m).^2)));
    SChangeRe = sum(sum(sum((yhat - y_ri).^2)));
    dSChange = SChange - SChange0;



    disp(['iter:',num2str(iIter),';\n error_major:',num2str(SChange), ...
        '; error_remain:',num2str(SChangeRe), ...
        '\n d(error) = ',num2str(dSChange)]);
    if dSChange0 > 0 && dSChange > 1e-4 && iIter>10
        break
    end
% % 
% p = figure; 
% p.Position = [100, 100, 1200, 400]; 
% subplot(1,4,1)
% mesh(X,Y,y,'FaceColor','interp','LineStyle','none')
% axis tight
% view([-18,15])
% zlim([min(Dev(:)),max(Dev(:))])
% title('Original Deviation Function',FontSize=15)
% 
% subplot(1,4,2)
% mesh(X,Y,a,'FaceColor','interp','LineStyle','none')
% axis tight
% view([-18,15])
% zlim([min(Dev(:)),max(Dev(:))])
% title('Major Pattern',FontSize=15)
% 
% subplot(1,4,3)
% mesh(X,Y,yhat,'FaceColor','interp','LineStyle','none')
% axis tight
% view([-18,15])
% zlim([min(Dev(:)),max(Dev(:))])
% title('Major Pattern',FontSize=15)
% clim([min(Dev(:)),max(Dev(:))])
% 
% subplot(1,4,4)
% mesh(X,Y,y-a-yhat,'FaceColor','interp','LineStyle','none')
% axis tight
% view([-18,15])
% zlim([min(Dev(:)),max(Dev(:))])
% title('Major Pattern',FontSize=15)
% clim([min(Dev(:)),max(Dev(:))])

end

end
% 
% figure()
% heatmap(abs(BetaAT));
% figure()
% heatmap(abs(BetaRe));
% level = multithresh(abs(BetaA),2);
% isoLoc = findIsolatedLocations(BetaA);
% Loc = [];
% BetaAT = BetaA;
% for il = 1:length(isoLoc)
%     if abs(BetaA(isoLoc(il,1),isoLoc(il,2)))<temp_up
%         Loc = [Loc;isoLoc(il,:)];
%     end
%     BetaAT(isoLoc(il,1),isoLoc(il,2)) = 0;
% end


function [ GCVscore ] = splinegcv( lambda,Y,C,Z,nmiss,W )
% Estimate Generalized Cross-validation value

ndim = sum(size(Y)~=1);
H = cell(ndim,1);
dfi = zeros(ndim,1);
for idim = 1:ndim
    %%
    H{idim} = Z{idim}*diag(1./(ones(size(C{idim},1),1) + lambda*diag(C{idim})))*Z{idim}';
    dfi(idim) = sum(1./(1+lambda*diag(C{idim})));
end

df = prod(dfi);
if ndim == 1
    Yhat = H{1}*Y;
elseif ndim == 2
    Yhat = H{1}*Y*H{2};
elseif ndim >= 3
    Yhat = double(ttm(tensor(Y),H));
end

if(isempty(W))
    RSS = sum(sum(sum((Y-Yhat).^2)));
else
    RSS = sum(sum(sum((Y-Yhat).*W.*(Y-Yhat))));
end

n = numel(Y);
GCVscore = RSS/(n-nmiss)/(1-df/n)^2;
end









