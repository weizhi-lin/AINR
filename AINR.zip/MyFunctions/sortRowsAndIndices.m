function [sortedMatrix, originalIndices] = sortRowsAndIndices(matrix)
    % sortRowsAndIndices sorts each row of the matrix and returns the sorted rows
    % along with the original column indices of these elements.

    % Preallocate the output matrix and index matrix
    sortedMatrix = zeros(size(matrix));
    originalIndices = zeros(size(matrix));
    
    % Loop through each row
    for i = 1:size(matrix, 1)
        % Sort each row and preserve original indices
        [sortedMatrix(i, :), originalIndices(i, :)] = sort(matrix(i, :), 'ascend');
    end
end
