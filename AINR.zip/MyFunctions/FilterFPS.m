function landmarks = FilterFPS(vertex,faces,Nlmk,filter,para)
currentFolder = para.currentFolder;
% inpute vertex should be 3*N
if size(vertex,2)<size(vertex,1)
    vertex = vertex';
end

if size(faces,2)<size(faces,1)
    faces = faces';
end

% if size(filter,2)<size(filter,1)
%     filter = filter';
% end

options.verb = 0;
% [Lambda,Cgauss,Cmean,Ctotal] = ComputeWeightFunction(vertex,faces);
% [~,~,~,~,~,Cgauss,~] = compute_curvature(vertex,faces,options);

m = Nlmk;
W = rescale(filter, .001, 1);
options.W = W;
ini_n = find(filter == max(filter(:))); 
landmarks = ini_n;

compile_mex

[D,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks);


for i=2:m
    % select
    [~,landmarks(end+1)] = max(D);
    % update
    options.constraint_map = D;
    [D1,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks,options);
    D = min(D,D1);
end

if(~isdeployed)
  cd(currentFolder);
end

end