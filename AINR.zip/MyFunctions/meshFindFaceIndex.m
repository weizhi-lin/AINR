function indxFace = meshFindFaceIndex(faces1,verInd)

for j = 1:length(verInd)
    idx1 = find(faces1(:,1) == verInd(j));
    idx2 = find(faces1(:,2) == verInd(j));
    idx3 = find(faces1(:,3) == verInd(j));
    idx = [idx1;idx2;idx3];
    idxJ{j} = idx;
end
indxFace = unique(cell2mat(idxJ'));