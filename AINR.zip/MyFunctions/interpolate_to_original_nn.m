function deviation_original = interpolate_to_original_nn(vertex_original, vertex_remeshed, deviation_remeshed)
    % vertex_original: Nx3
    % vertex_remeshed: Mx3
    % deviation_remeshed: Mx1
    % Output: deviation_original: Nx1

    % Ensure correct orientation
    if size(vertex_original,2) ~= 3
        vertex_original = vertex_original';
    end
    if size(vertex_remeshed,2) ~= 3
        vertex_remeshed = vertex_remeshed';
    end

    % Find nearest remeshed vertex for each original vertex
    idx = knnsearch(vertex_remeshed, vertex_original);
    deviation_original = deviation_remeshed(idx);
end