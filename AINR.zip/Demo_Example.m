%% Deviation-aware registraction
% segmentation - landmark selection - segment-wise registraction 


%% import data
clc
clear

addpath(genpath('Toolbox/'));
addpath('MyFunctions');


para.currentFolder = pwd;

n_eigenvalues = 100;
para.md = 6; % needs to be even
para.s = 0.6; % control the step-size of expanding

fttype = 'Times';
ftsize = 15;

mymap = [225 228 235% 218 221 230
    163 182 212
    92 108 161
    67 78 135
    32 97 135]/255; % white blue 
J = customcolormap(linspace(0,1,11), ...
    {'#68011d','#b5172f','#d75f4e','#f7a580','#fedbc9','#f5f9f3', ...
    '#d5e2f0','#93c5dc','#4295c1','#2265ad','#062e61'});

data_folder = 'Data';
data_file_Design = {'Design.off'}; 

data_folder_scan = 'Data';
data_file_Scan = {'Scan.off'}; 


filenames = {'Shape'};

segment_methods = {'DA', 'Kmeans', 'Kmeans15','Kmeans3','None'};
LmkCor_methods = {'Rigid','Feature','None','NA'};
Reg_methods = {'Tmap','ICP'};

results = table;
Error_log = table;


cd("Toolbox/toolbox_graph"); 
compile_mex

%% Segment-based registration 

td = 1; 

Mesh_Design= Mesh('off',fullfile(para.currentFolder,data_folder,data_file_Design{td}));
[vertex1,faces1] = MeshRead(Mesh_Design);
Mesh_Scan = Mesh('off',fullfile(para.currentFolder,data_folder_scan,data_file_Scan{td}));
[vertex2,faces2] = MeshRead(Mesh_Scan);

% Original Differences 
[~, pt2planeDist1] = ComputeEuDev(vertex1,vertex2);


[~,Cgauss1,Cmean1,~] = ComputeWeightFunction(vertex1,faces1);
[~,Cgauss2,Cmean2,~] = ComputeWeightFunction(vertex2,faces2);


% finds the nearest neighbor in X for each query point in Y and returns the 
% indices of the nearest neighbors in Idx, a column vector. 
% Idx has the same number of rows as Y.
[idx, D] = knnsearch(vertex2,vertex1);
Hdiff0 = []; % ground truth curvature differences
for i = 1:length(vertex1)
    Hdiff0(i) = Cmean2(idx(i))-Cmean1(i);
end
Hdiff0 = Hdiff0';

figure()
% pt2planeDist contains the point-to-plane distances
subplot(1,2,1)
options.face_vertex_color =  perform_saturation(pt2planeDist1,1); 
plot_mesh(vertex1,faces1,options);
colormap(J);
shading flat; colorbar
title('Ground Truth Euclidean Distance')
subplot(1,2,2)
options.face_vertex_color =  perform_saturation(Hdiff0,1); 
plot_mesh(vertex1,faces1,options);
colormap(J);
shading flat; colorbar
title('Ground Truth Curvature Differences')


% segment the shape 
MD.vertex = vertex1;
MD.faces = faces1;
MD.Cgauss = Cgauss1;
MD.Cmean = Cmean1;

[MDesign,N_DA] = DA_Segment(MD,para);

MDesign_Km = Kmeans_Segment(MD,N_DA);

MDesign_Km15 = Kmeans_Segment(MD,15);

MDesign_Km3 = Kmeans_Segment(MD,3);


MS.vertex = vertex2;
MS.faces = faces2;
MS.Cgauss = Cgauss2;
MS.Cmean = Cmean2;

%% Proposed Segmentation 

[AdaptPatch_Ori,BC_seg,MeshSeg] = Segment_BCReg(MDesign,MS,para);

[AdaptPatch_Ori_Km,BC_seg_Km,MeshSeg_Km] = Segment_BCReg_irbd(MDesign_Km,MS,para);

[AdaptPatch_Ori_Km3,BC_seg_Km3,MeshSeg_Km3] = Segment_BCReg_irbd(MDesign_Km3,MS,para);

[AdaptPatch_Ori_Km15,BC_seg_Km15,MeshSeg_Km15] = Segment_BCReg_irbd(MDesign_Km15,MS,para);
   
p = figure;
p.Position = [100,100,2000,400];
subplot(1,4,1)
Hdiff = AdaptPatch_Ori.Hdiff_Ft;
options.face_vertex_color = Hdiff;% perform_saturation(Hdiff,1.5);
plot_mesh(vertex1,faces1,options);
colormap(J)
shading flat
clim([quantile(Hdiff0,0.05),quantile(Hdiff0,0.95)]);
title(['DA-Segment Diffeomorphism (',num2str(N_DA),' segments)'],'FontSize',10);

subplot(1,4,2)
Hdiff = AdaptPatch_Ori_Km.Hdiff_Ft;
options.face_vertex_color = Hdiff;% perform_saturation(Hdiff,1.5);
plot_mesh(vertex1,faces1,options);
colormap(J)
shading flat
clim([quantile(Hdiff0,0.05),quantile(Hdiff0,0.95)]);
title(['Kmeans-Segment Diffeomorphism (',num2str(N_DA),' segments)'],'FontSize',10);

subplot(1,4,3)
Hdiff = AdaptPatch_Ori_Km15.Hdiff_Ft;
options.face_vertex_color = Hdiff;% perform_saturation(Hdiff,1.5);
plot_mesh(vertex1,faces1,options);
colormap(J)
shading flat
clim([quantile(Hdiff0,0.05),quantile(Hdiff0,0.95)]);
title('Kmeans-Segment Diffeomorphism (15 segments)','FontSize',10);
sgtitle(['Shape ',filenames{td},' Iter: ',num2str(ri)],'FontSize',10);


subplot(1,4,4)
Hdiff = AdaptPatch_Ori_Km3.Hdiff_Ft;
options.face_vertex_color = Hdiff;% perform_saturation(Hdiff,1.5);
plot_mesh(vertex1,faces1,options);
colormap(J)
shading flat
clim([quantile(Hdiff0,0.05),quantile(Hdiff0,0.95)]);
title('Kmeans-Segment Diffeomorphism (3 segments)','FontSize',10);
sgtitle(['Shape ',filenames{td},' Iter: ',num2str(ri)],'FontSize',10);

 